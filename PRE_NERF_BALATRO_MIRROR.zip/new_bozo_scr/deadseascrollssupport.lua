local mod = BalatroJokers

--For configurating HUD stuff

--Todo: Code Baron, Baseball, F.Teller (High priority)
--Add HUD config,
--Add selling mechanic (Tap drop to choose, Hold Drop to sell)
--So now you can remove jokers by using a Hex spectral card or by selling it
--Sell bar displays sold joker name too
--Inventory HUD: joker sell target becomes yellow

function mod:ChooseCardToSellWhenTappingDrop(player)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if player:GetData().SellingJoker == true then

if BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) then
if not (BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Jokers.Brainstorm) then

Isaac.ExecuteCommand("playsfx 274")
if not BalatroJokers:IsLegendaryJoker(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)) then
player:AnimateCard(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot))
else
player:AnimateCard(BalatroJokers.Enums.SpectralCards.TheSoul)
end
Isaac.GetPlayer():AddCoins(3)

if BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Jokers.Egg
and RPData.EggValue then
Isaac.GetPlayer():AddCoins(RPData.EggValue)
RPData.EggValue = nil
end

Isaac.RunCallbackWithParam(BalatroJokers.Enums.PRE_SELL_JOKER, EntityType.ENTITY_PLAYER, player, BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot))

else

local retard = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Jokers.Brainstorm, Isaac.GetFreeNearPosition(player.Position,30), Vector.Zero, player)

end

BalatroJokers:DestroyJoker(player, RPData.SellJokerSlot)
player:GetData().SellingJoker = nil
end
end
		
if Input.IsActionTriggered(ButtonAction.ACTION_DROP, player.ControllerIndex) then
if not RPData.SellJokerSlot then
RPData.SellJokerSlot = 1
else

if BalatroJokers:MaxValidSlot(player) ~= 0  then
if BalatroJokers:MaxValidSlot(player) == 1 then
RPData.SellJokerSlot = 1
else

if (RPData.SellJokerSlot + 1)%BalatroJokers:MaxValidSlot(player) ~= 0 then
RPData.SellJokerSlot = (RPData.SellJokerSlot + 1)%BalatroJokers:MaxValidSlot(player) 
else
RPData.SellJokerSlot = BalatroJokers:MaxValidSlot(player) 
end

end
end
end
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PLAYER_UPDATE,
    mod.ChooseCardToSellWhenTappingDrop
)

local shoulddisplaytext = false

function mod:onRenderdrop(_)
local PersData = BalatroJokers.SaveShitNow.GetPersistentSave()	
local drop = Sprite()

local selldelay = 220

if PersData and PersData.SellSpeed then
if PersData.SellSpeed == 2 then
selldelay = 165
elseif PersData.SellSpeed == 1 then
selldelay = 220
elseif PersData.SellSpeed == 3 then
selldelay = 330
end
end


	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)	
local f = Font()
f:Load("font/luaminioutlined.fnt")
drop:Load("gfx/chargebarJimbo.anm2")
	  local data = player:GetData()
if RPData and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) then
	  		if data.JokerBalatroDrop == nil then
		data.JokerBalatroDrop = 0
		end
if BalatroJokers:MaxValidSlot(player) ~= 0 then


if player:GetPlayerType() == PlayerType.PLAYER_ESAU then
if Input.IsActionPressed(ButtonAction.ACTION_PILLCARD, player.ControllerIndex) then
data.JokerBalatroDrop = data.JokerBalatroDrop + 1
end
else
if (player:GetPlayerType() == PlayerType.PLAYER_JACOB and not Input.IsActionPressed(ButtonAction.ACTION_PILLCARD, player.ControllerIndex) )
or (player:GetOtherTwin() == nil) then
data.JokerBalatroDrop = data.JokerBalatroDrop + 1
end
end

if data.JokerBalatroDrop < selldelay and data.JokerBalatroDrop ~= 0 and BalatroJokers:MaxValidSlot(player) ~= 0 then

local name = "a"

if BalatroJokers:IsLegendaryJoker(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)) then

if BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Legendaries.PERKEO then
name = "Perkeo"
elseif BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Legendaries.CANIO then
name = "Canio"
elseif BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Legendaries.CHICOT then
name = "Chicot"
elseif BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Legendaries.TRIBOULET then
name = "Triboulet"
elseif BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Legendaries.YORICK then
name = "Yorick"
end

else
if BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) then
name = Isaac.GetItemConfig():GetCard(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)).Name
end
end

local str = "Sell "..name
if BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot) == BalatroJokers.Enums.Jokers.Brainstorm then
str = "Drop "..name
end

f:DrawString(str, Isaac.WorldToScreen(player.Position + Vector(0, 20)).X- f:GetStringWidth(str)*0.5, Isaac.WorldToScreen(player.Position + Vector(-35, -110)).Y, KColor(1,1,1,1,0,0,0),0,true)
drop:SetFrame("Charging", math.floor(data.JokerBalatroDrop * (100/selldelay) + 1 ))

shoulddisplaytext = true

if EID then
if PersData.EIDSwitch == 1 then

local variant = 300
local subtype = 1
if BalatroJokers:IsLegendaryJoker(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)) then
variant = BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)
subtype = 1
else
variant = 300
subtype = BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)
end
local soldcard = EID:getDescriptionObj(5, variant, subtype)
EID:displayPermanentText(soldcard)

end
end

drop:Render(Isaac.WorldToScreen(player.Position + Vector(0, -80)), Vector.Zero, Vector.Zero)
elseif data.JokerBalatroDrop > selldelay and data.JokerBalatroDrop < selldelay*1.1 then
drop:SetFrame("StartCharged", math.floor(data.JokerBalatroDrop * (1/1) - selldelay ))
drop:Render(Isaac.WorldToScreen(player.Position + Vector(0, -80)), Vector.Zero, Vector.Zero)
if not player:GetData().SellingJoker and data.JokerBalatroDrop >= selldelay and data.JokerBalatroDrop <= selldelay+1 then
player:GetData().SellingJoker = true
end
elseif data.JokerBalatroDrop >= selldelay*1.1 then

drop:SetFrame("Disappear", math.floor(data.JokerBalatroDrop * (1/1) - selldelay ))
drop:Render(Isaac.WorldToScreen(player.Position + Vector(0, -80)), Vector.Zero, Vector.Zero)
end
end
else
data.JokerBalatroDrop = 0

if shoulddisplaytext == true then
if EID then
EID:hidePermanentText()
end
shoulddisplaytext = false
end

end
end
end

mod:AddCallback(ModCallbacks.MC_POST_RENDER, mod.onRenderdrop)

--local BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)

--[[


local variant = 300
local subtype = 1
if BalatroJokers:IsLegendaryJoker(BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)) then
variant = BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)
subtype = 1
else
variant = 300
subtype = BalatroJokers:GetIDFromSlotNum(player, RPData.SellJokerSlot)
end
local soldcard = EID:getDescriptionObj(5, variant, subtype)
EID:displayPermanentText(soldcard)

]]