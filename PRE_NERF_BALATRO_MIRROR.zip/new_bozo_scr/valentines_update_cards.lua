local mod = BalatroJokers

function mod:UseSTM(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseSTM, BalatroJokers.Enums.Jokers.ShootTheMoon)

function mod:ShootTheMoonEvalDMG(player,flag)
local fem = BalatroJokers:GetFemaleItems(player)
local count = mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.ShootTheMoon)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.ShootTheMoon) > 0 then
player.Damage = player.Damage + 1.3*(count*fem)^0.5
end
end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.ShootTheMoonEvalDMG,
	CacheFlag.CACHE_DAMAGE
)

function mod:UseSplash(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseSplash, BalatroJokers.Enums.Jokers.Splash)

function mod:SplashEffect(player,flag)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Splash) > 0 then
player.TearFlags = player.TearFlags|TearFlags.TEAR_HYDROBOUNCE
end
end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.SplashEffect,
	CacheFlag.CACHE_TEARFLAG
)

function mod:JugglerEffect(player)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Juggler) > 0 then
mod.HideShitNow:CheckStack(player, CollectibleType.COLLECTIBLE_POLYDACTYLY, 1)
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PEFFECT_UPDATE,
    mod.JugglerEffect
)

function mod:PhotoCardEffect(entity, amt, flags, source, frames)
local player = entity:ToPlayer()
if player then
local FSave = mod.SaveShitNow.GetRoomSave(player)
if FSave then
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Photo) > 0 then
if not FSave.TriggeredPhoto then
if flags & DamageFlag.DAMAGE_CLONES == 0 then
if not Game():GetRoom():IsClear() then
Game():GetRoom():SetClear(false)
FSave.TriggeredPhoto = true
Game():Darken(-5, 9)
player:AddCollectible(677)
player:TakeDamage(0, DamageFlag.DAMAGE_FAKE|DamageFlag.DAMAGE_CLONES, EntityRef(player), 0)
player:TakeDamage(0, DamageFlag.DAMAGE_FAKE|DamageFlag.DAMAGE_CLONES, EntityRef(player), 0)
SFXManager():Stop(SoundEffect.SOUND_ISAAC_HURT_GRUNT)
SFXManager():Play(SoundEffect.SOUND_ISAAC_HURT_GRUNT,0)
SFXManager():Play(SoundEffect.SOUND_DOOR_HEAVY_CLOSE, 0)
SFXManager():Play(615)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.HangingChad) > 0 then
 local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
 RPData.IceCreamMult = RPData.IceCreamMult and RPData.IceCreamMult + 90 or 90
 end
player:RemoveCollectible(677)
player:GetEffects():RemoveCollectibleEffect(677)
end
end
end
end
end
end
end
mod:AddCallback(
    ModCallbacks.MC_ENTITY_TAKE_DMG,
    mod.PhotoCardEffect
)

function mod:HangingChadHurtEffect(entity, amt, flags, source, frames)
local player = entity:ToPlayer()
if player then
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.HangingChad) > 0 then
if flags & DamageFlag.DAMAGE_CLONES == 0 then
player:TakeDamage(0, DamageFlag.DAMAGE_FAKE|DamageFlag.DAMAGE_CLONES, EntityRef(player), 0)
player:TakeDamage(0, DamageFlag.DAMAGE_FAKE|DamageFlag.DAMAGE_CLONES, EntityRef(player), 0)
end
end
end
end
mod:AddCallback(
    ModCallbacks.MC_ENTITY_TAKE_DMG,
    mod.HangingChadHurtEffect
)

function mod:ActivateHangingChad2(ctype, player, flags)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.HangingChad) > 0 then
if not (mod:IsAnyJoker(ctype) or ctype == mod.Enums.SpectralCards.TheSoul) then
local FSave = mod.SaveShitNow.GetFloorSave(player)
if FSave then
if FSave.UsedRepeatCount == nil then
FSave.UsedRepeatCount =  0
end
if FSave.UsedRepeatCount and FSave.UsedRepeatCount < mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.HangingChad) then
if flags & UseFlag.USE_NOANIM ==0 then
player:UseCard(ctype, UseFlag.USE_NOANIM)
player:UseCard(ctype, UseFlag.USE_NOANIM)
FSave.UsedRepeatCount = FSave.UsedRepeatCount  + 1
end
end

end
end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.ActivateHangingChad2)

function BalatroJokers:OnSellSuperPos(player, jokerid)
if jokerid == BalatroJokers.Enums.Jokers.Superposition then
SFXManager():Play(SoundEffect.SOUND_MIRROR_EXIT)

local entities = Isaac.GetRoomEntities()
for i, entity in ipairs(entities) do
	if entity.Type == 5 then
	entity:ToPickup().OptionsPickupIndex = 0
     end
end
print("penis")

end
end
BalatroJokers:AddCallback(BalatroJokers.Enums.PRE_SELL_JOKER, BalatroJokers.OnSellSuperPos)

function mod:HandleChaosClown()
	local roomt = Game():GetRoom():GetType()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.ChaosTheClown) > 0 then
		if Game():GetRoom():IsFirstVisit() == true and (roomt == RoomType.ROOM_SHOP) then
		local card1 = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, 49, Isaac.GetFreeNearPosition(player.Position, 40), Vector.Zero, nil):ToPickup()
		end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandleChaosClown)

function mod:AbstractUse(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.AbstractUse, BalatroJokers.Enums.Jokers.Abstract)

function mod:MadnessUse(card, player, useflags)
mod:DestroyRandomCollectible(player)

player:UseCard(87,UseFlag.USE_OWNED|UseFlag.USE_NOANIM|UseFlag.USE_NOANNOUNCER)

	local heart = Isaac.Spawn(92, 0, 0, player.Position, Vector.Zero, player) 
	heart.SpriteScale = Vector(2,2)
	heart.Visible = false --Make it invisible
	heart:AddEntityFlags(EntityFlag.FLAG_AMBUSH|EntityFlag.FLAG_EXTRA_GORE|EntityFlag.FLAG_FRIENDLY)
	heart:Kill() 
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.MadnessUse, BalatroJokers.Enums.Jokers.Madness)

function mod:MadnessEval()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Madness) > 0 then
		mod:DestroyRandomCollectible(player)

player:UseCard(87,UseFlag.USE_OWNED|UseFlag.USE_NOANIM|UseFlag.USE_NOANNOUNCER)
SFXManager():Stop(650)
SFXManager():Stop(592)
	local heart = Isaac.Spawn(92, 0, 0, player.Position, Vector.Zero, player) 
	heart.SpriteScale = Vector(2,2)
	heart.Visible = false --Make it invisible
	heart:AddEntityFlags(EntityFlag.FLAG_AMBUSH|EntityFlag.FLAG_EXTRA_GORE|EntityFlag.FLAG_FRIENDLY)
	heart:Kill() 
		end
	end	
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.MadnessEval)

function mod:Madness2()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Madness) > 0 and Game():GetRoom():IsFirstVisit() then

player:UseCard(87,UseFlag.USE_OWNED|UseFlag.USE_NOANIM|UseFlag.USE_NOANNOUNCER)
SFXManager():Stop(650)
SFXManager():Stop(592)
		end
	end	
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.Madness2)

function mod:HandlePareidolia()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Pareidolia) > 0 then
		
		local entities = Isaac.GetRoomEntities()
for i, entity in ipairs(entities) do
	if entity:IsVulnerableEnemy() == true then
	entity:ToNPC():MakeChampion(Game():GetFrameCount()+entity.InitSeed, -1, Init)
     end
end

	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandlePareidolia)

function mod:HandleMetalJoker()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.SteelJoker) > 0 then
		
		local entities = Isaac.GetRoomEntities()
for i, entity in ipairs(entities) do
	if entity:IsVulnerableEnemy() == true then
	if mod:RNGOneParam(100) <= 16*BalatroJokers:GetSteelItems(player)  then
	entity:AddEntityFlags(EntityFlag.FLAG_MAGNETIZED)
	end
    end
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandleMetalJoker)

function mod:HandleGoldJoker()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GoldenTicket) > 0 then
		
		local entities = Isaac.GetRoomEntities()
for i, entity in ipairs(entities) do
	if entity:IsVulnerableEnemy() == true then
	if mod:RNGOneParam(100) <= 8*BalatroJokers:GetGoldenItems(player)  then
	entity:AddMidasFreeze(EntityRef(player), mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GoldenTicket)*55)
	end
    end
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandleGoldJoker)

function mod:UseGlassJoker(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseGlassJoker, BalatroJokers.Enums.Jokers.GlassJoker)

function mod:GlassEvalDMG(player,flag)
local glass = BalatroJokers:GetGlassItems(player)
local count = mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GlassJoker)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GlassJoker) > 0 then
player.Damage = player.Damage *(  1 + 0.3*(count*glass))
end
end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.GlassEvalDMG,
	CacheFlag.CACHE_DAMAGE
)

function mod:GlassJokerHurtEffect(entity, amt, flags, source, frames)
local player = entity:ToPlayer()
if player then
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GlassJoker) > 0 and flags & DamageFlag.DAMAGE_FAKE == 0 then
if player:GetHearts() > 1 then
player:AddEntityFlags(EntityFlag.FLAG_BLEED_OUT)
SFXManager():Play(SoundEffect.SOUND_GLASS_BREAK)
player:GetEffects():AddCollectibleEffect(214, true)
player:GetEffects():AddCollectibleEffect(448, true)
else
player:AddEntityFlags(EntityFlag.FLAG_BLEED_OUT)
SFXManager():Play(SoundEffect.SOUND_GLASS_BREAK)
player:GetEffects():AddCollectibleEffect(214, true)
player:GetEffects():AddCollectibleEffect(448, true)
player:AddBrokenHearts(1)
end
end
end
end
mod:AddCallback(
    ModCallbacks.MC_ENTITY_TAKE_DMG,
    mod.GlassJokerHurtEffect
)

function mod:HandleDNA()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.DNA) > 0 and Game():GetRoom():IsFirstVisit() then
		for i =1,mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.DNA) do
local minis = mod.MimicShitNow:AddIncubusAtHome(player)

end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandleDNA)

function BalatroJokers:OnSellCola(player, jokerid)
if jokerid == BalatroJokers.Enums.Jokers.DietCola then
local closestItem = nil
        local closestDist = math.huge
        
        for _, entity in pairs(Isaac.GetRoomEntities()) do
            if entity.Type == 5 and entity.Variant == 100 then
                local dist = player.Position:Distance(entity.Position)
                if dist < closestDist then
                    closestItem = entity
                    closestDist = dist
                end
            end
        end
        
        if closestItem then
		card1 = Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, closestItem.SubType, Isaac.GetFreeNearPosition(closestItem.Position, 40), Vector.Zero, nil):ToPickup()
		end
end
end
BalatroJokers:AddCallback(BalatroJokers.Enums.PRE_SELL_JOKER, BalatroJokers.OnSellCola)

local rockcountlast = 0

function mod:CheckGridRock2()
local rockcount = 0
for i = 1, Game():GetRoom():GetGridSize() do
	local dwayne = Game():GetRoom():GetGridEntity(i)
	if dwayne ~= nil and dwayne:GetType() == 2 and dwayne.State == 2  then
	rockcount = rockcount + 1
	end
end

if rockcountlast ~= rockcount then
rockcountlast = rockcount

for playerNum = 0, Game():GetNumPlayers() - 1 do
local player = Game():GetPlayer(playerNum)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Erosion) > 0 then
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end
end

end
mod:AddCallback(
    ModCallbacks.MC_POST_UPDATE,
    mod.CheckGridRock2
)

function mod:UseErosion(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseErosion, BalatroJokers.Enums.Jokers.Erosion)

function mod:ErosionEvalDMG(player,flag)
local count = mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Erosion)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Erosion) > 0 then
player.Damage = player.Damage + 0.25*(count*rockcountlast)
end
end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.ErosionEvalDMG,
	CacheFlag.CACHE_DAMAGE
)

function mod:SmearedJokerEffectHealthCoin(player)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Smeared) > 0  then
local num = 0
if Isaac.GetPlayer():GetNumCoins() <= 0 then
num = 1
else
num = 0
end
mod.HideShitNow:CheckStack(player, CollectibleType.COLLECTIBLE_POUND_OF_FLESH, num)
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PEFFECT_UPDATE,
    mod.SmearedJokerEffectHealthCoin
)

function mod:BombsAreKeyLiterally(player)
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Smeared) > 0  then
if (player:GetNumBombs() > 0)  then return end
if Input.IsActionTriggered(ButtonAction.ACTION_BOMB, player.ControllerIndex) and 
Isaac.GetPlayer():GetNumBombs() == 0 and not (player:GetNumBombs() == 1) and Isaac.GetPlayer():HasGoldenBomb() == false and
Isaac.GetPlayer():GetNumKeys() > 0 then

SFXManager():Play(40)
local entity = player:FireBomb(player.Position, Vector.Zero)
Isaac.GetPlayer():AddKeys(-1)

end
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PEFFECT_UPDATE,
    mod.BombsAreKeyLiterally
)


function mod:KeyBombs(bomb)
if bomb.SpawnerEntity then
local player = bomb.SpawnerEntity:ToPlayer()
if player then
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Smeared) > 0 then
    if bomb:GetSprite():IsPlaying("Explode") then
      for i = 1, 8 do
		local winedrop = Isaac.Spawn(2, 44, 0, bomb.Position, Vector(0,10):Rotated(45*i), player):ToTear()
		--winedrop.TearFlags = TearFlags.TEAR_SPECTRAL
		end
    end
end
end
end
end

mod:AddCallback(
    ModCallbacks.MC_POST_BOMB_UPDATE,
    mod.KeyBombs
)

function mod:OnItemPickup(player)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if player.QueuedItem.Item and
Isaac.GetItemConfig():GetCollectible(player.QueuedItem.Item.ID):HasTags(ItemConfig.TAG_SUMMONABLE) then
if not RPData.PickedUpLastItemJimbo or player.QueuedItem.Item.ID ~= RPData.PickedUpLastItemJimbo then
RPData.PickedUpLastItemJimbo = player.QueuedItem.Item.ID
end


if not RPData.FirstItemJimbo then
RPData.FirstItemJimbo = player.QueuedItem.Item.ID
end

end
end
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, mod.OnItemPickup)

function mod:BlueprintEffect(player)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Blueprint) > 0 and RPData.PickedUpLastItemJimbo ~= nil then

for i = 1, Isaac.GetItemConfig():GetCollectibles().Size -1 do
if mod.HideShitNow:Has(player, i, BLUEPRINT_BALATRO) and
i ~= RPData.PickedUpLastItemJimbo then
mod.HideShitNow:RemoveAll(player, BLUEPRINT_BALATRO)
end
end

mod.HideShitNow:CheckStack(player, RPData.PickedUpLastItemJimbo, mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Blueprint), BLUEPRINT_BALATRO)
end
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PEFFECT_UPDATE,
    mod.BlueprintEffect
)


function mod:UsePlasma(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
mod.HideShitNow:AddForFloor(player, CollectibleType.COLLECTIBLE_LIBRA)
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UsePlasma, BalatroJokers.Enums.Decks.PlasmaDeck)

function mod:UseAbandoned(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
local RPData = BalatroJokers.SaveShitNow.GetFloorSave()
if RPData then
	RPData.UsedAbandoned = true
end		
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseAbandoned, BalatroJokers.Enums.Decks.AbandonedDeck)

function mod:HandleAbandonedDeck()
local RPData = BalatroJokers.SaveShitNow.GetFloorSave()
if RPData then
		if RPData.UsedAbandoned and RPData.UsedAbandoned == true then
		
		local entities = Isaac.GetRoomEntities()
for i, entity in ipairs(entities) do
	if entity:IsVulnerableEnemy() == true and entity:ToNPC() and entity:ToNPC():IsChampion() == true then
	entity:ToNPC():MakeChampion(Game():GetFrameCount()+entity.InitSeed, ChampionColor.CAMO, true)
     end
end

	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandleAbandonedDeck)

function mod:UseWee(card, player, useflags)
		player:AddCacheFlags(CacheFlag.CACHE_SIZE)
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
end		
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseWee, BalatroJokers.Enums.Jokers.Wee)

function mod:WeeStats(player,flag)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
if RPData and RPData.KillsTotal and mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Wee) > 0 and flag == CacheFlag.CACHE_FIREDELAY then	
player.MaxFireDelay = BalatroJokers:CalculateNewFireDelay(player.MaxFireDelay, 0.02*math.floor(RPData.KillsTotal/2) )
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Wee) > 0  and flag == CacheFlag.CACHE_SIZE then
player.SpriteScale = player.SpriteScale * 0.5
end

end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.WeeStats,
	CacheFlag.CACHE_FIREDELAY
)
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.WeeStats,
	CacheFlag.CACHE_SIZE
)

function mod:FullInventoryWarning(pickup)
if (pickup.Variant == 300 and BalatroJokers:IsValidJoker(pickup.SubType) == true) or (BalatroJokers:IsLegendaryJoker(pickup.Variant) == true) then
local player = Game():GetNearestPlayer(pickup.Position)
if player then
local maxslot = 10
if BalatroJokers:RedeemedBlank(player) then
maxslot = 15
else
maxslot = 10
end

if BalatroJokers:MaxValidSlot(player) >= maxslot then

if Game():GetFrameCount() % 30 == 0 then
pickup:SetColor(Color(1,0.5,0.5,1,1,0,0), 15, 999, true)

local fart = Isaac.Spawn(EntityType.ENTITY_EFFECT, 112, 0, pickup.Position+Vector(0,-3), Vector.Zero, player):ToEffect()
fart.Color = Color(1,0,0,1,1,0,0)
fart.SpriteScale = Vector(0.3,0.3)
fart:GetData().IsWarningMaxInvLimitBalatro = true
end
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.FullInventoryWarning)

function mod:RocketUpdate2(ItSeemsThatMyTurtleHasDiedNoooo)

if not (ItSeemsThatMyTurtleHasDiedNoooo:GetData().IsWarningMaxInvLimitBalatro and ItSeemsThatMyTurtleHasDiedNoooo:GetData().IsWarningMaxInvLimitBalatro == true and ItSeemsThatMyTurtleHasDiedNoooo.Parent) then return end

ItSeemsThatMyTurtleHasDiedNoooo.Velocity = (ItSeemsThatMyTurtleHasDiedNoooo.Parent.Position - ItSeemsThatMyTurtleHasDiedNoooo.Position)

end
mod:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, mod.RocketUpdate2, 112)

local function MachineDeath(slot)
local PersData = BalatroJokers.SaveShitNow.GetPersistentSave()	
        for _, slot in pairs(Isaac.GetRoomEntities()) do

if PersData and PersData.MachineSwapRate then		
if slot.Type == 6 and slot.Variant == 1 then
if (slot.InitSeed % 10) < (PersData.MachineSwapRate-1) then
if slot.FrameCount >0 then
slot:Remove()
local slot2 = Isaac.Spawn(6,BalatroJokers.Enums.Slots.JIMBO_MACHINE,0,slot.Position,Vector.Zero,nil)
slot:AddEntityFlags(EntityFlag.FLAG_APPEAR)
end
end
end		
end
		
if slot.Type == 6 and slot.Variant == BalatroJokers.Enums.Slots.JIMBO_MACHINE then
    if slot.GridCollisionClass == EntityGridCollisionClass.GRIDCOLL_GROUND then
				SFXManager():Play(567, 1, 1, false, 1, 0)
				
				mod:SpawnRandomCard(slot.Position, Vector(0,1):Rotated(mod:RNGTwoParam(0, 360))*mod:RNGTwoParam(3, 8), mod:RNGTwoParam(0, 9), nil)
				
        slot:Remove()
		
    end
	
	if slot:GetSprite():IsFinished("Initiate") then
slot:GetSprite():Play("Prize")
end

if slot:GetSprite():IsFinished("Prize") then
--Game():Fart(slot.Position, 10, Isaac.GetPlayer())
slot:GetSprite():Play("Idle")
local AllBoosters = BalatroJokers.Enums.WeightedBoosters
Isaac.Spawn(EntityType.ENTITY_PICKUP, (AllBoosters[1 +  Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllBoosters)]), 1, slot.Position, Vector.FromAngle(30 + Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(120)) * mod:RNGTwoParam(2,4), nil)		
SFXManager():Play(255, 2)
end
	
	
	end
	end
end
mod:AddCallback(ModCallbacks.MC_POST_UPDATE, MachineDeath)

function mod:OnSlotColl(player, collider, low)
if collider.Type == 6 and collider.Variant == BalatroJokers.Enums.Slots.JIMBO_MACHINE then

if collider:GetSprite():GetAnimation() == "Idle" then
if Isaac.GetPlayer():GetNumCoins() >= 7 then
Isaac.GetPlayer():AddCoins(-7)
collider:GetSprite():Play("Initiate", true)
SFXManager():Play(24)
end
end

end
end
mod:AddCallback(ModCallbacks.MC_PRE_PLAYER_COLLISION, mod.OnSlotColl)