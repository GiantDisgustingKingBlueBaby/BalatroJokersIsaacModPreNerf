local mod = BalatroJokers

local mins = 23

mod.LegendaryJokerMessage = {
[BalatroJokers.Enums.Legendaries.PERKEO] = "Wanna see me do it again?",
[BalatroJokers.Enums.Legendaries.CANIO] = "The comedy is over!",
[BalatroJokers.Enums.Legendaries.TRIBOULET] = "A downer ending",
[BalatroJokers.Enums.Legendaries.CHICOT] = "Weaker bosses",
[BalatroJokers.Enums.Legendaries.YORICK] = "Earthbound for 23 years",
}

mod.LegendaryJokerName = {
[BalatroJokers.Enums.Legendaries.PERKEO] = "Perkeo",
[BalatroJokers.Enums.Legendaries.CANIO] = "Canio",
[BalatroJokers.Enums.Legendaries.TRIBOULET] = "Triboulet",
[BalatroJokers.Enums.Legendaries.CHICOT] = "Chicot",
[BalatroJokers.Enums.Legendaries.YORICK] = "Yorick",
}

function mod:PlayDropSoundLeg(pickup)
if mod:IsLegendaryJoker(pickup.Variant) then
local sprite = pickup:GetSprite()

	if sprite:IsPlaying("Appear") == true and sprite:IsEventTriggered("DropSound") == true then
		SFXManager():Play (249, 1, 0, false, 1)--drop snd
	end
	
	if sprite:IsPlaying("Collect") == true then
		pickup.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
	end
	
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.PlayDropSoundLeg)

--[[
function mod:ReduceSoulWeight(pickup)
if ((pickup:GetSprite():IsPlaying("Appear") or pickup:GetSprite():IsPlaying("AppearFast")) and pickup:GetSprite():GetFrame() == 1) and pickup.SubType == BalatroJokers.Enums.SpectralCards.TheSoul and mod:RNGOneParam(15) ~= 1 
and not (pickup.SpawnerEntity and pickup.SpawnerEntity.Type == 1) then
pickup:ToPickup():Morph(EntityType.ENTITY_PICKUP,300,mod:IDRandomCard(BalatroJokers.Enums.CardGroup.SPECTRAL), true)
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.ReduceSoulWeight)
]]


function mod:AddLegendaryJoker(pickup, collider)
local sprite = pickup:GetSprite()
local player = collider:ToPlayer()
if player and mod:IsLegendaryJoker(pickup.Variant) and not player:IsHoldingItem() then
SFXManager():Play (23, 1, 0, false, 1)
player:AnimatePickup(sprite, HideShadow, AnimName)
BalatroJokers:RefreshJokerInventory(player, pickup.Variant) 
sprite:Play("Collect")
Game():GetHUD():ShowItemText(mod.LegendaryJokerName[pickup.Variant], mod.LegendaryJokerMessage[pickup.Variant])
player:AddCacheFlags(CacheFlag.CACHE_ALL)
player:EvaluateItems()
pickup:Remove()
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.AddLegendaryJoker)

function mod:UseTheSoulCard(card, player, useflags)
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then

SFXManager():Play (80, 1, 0, false, 1)
local dust_bg = Isaac.Spawn(1000, 16, 1, player.Position, Vector.Zero, nil):ToEffect()
dust_bg.DepthOffset = -1000
local dust_fg = Isaac.Spawn(1000, 16, 2, player.Position, Vector.Zero, nil):ToEffect()
dust_fg.DepthOffset = 1000
local blist = BalatroJokers.Enums.LegendariesList
local card = Isaac.Spawn(EntityType.ENTITY_PICKUP, blist[player:GetCollectibleRNG(678):RandomInt(#blist)+1], 1,  Isaac.GetFreeNearPosition(player.Position, 40), Vector.Zero, nil):ToPickup()

end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseTheSoulCard, mod.Enums.SpectralCards.TheSoul)

function mod:HandlePerkeoRoomNew()
	local roomt = Game():GetRoom():GetType()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.PERKEO) > 0 then
		if Game():GetRoom():IsFirstVisit() == true and (roomt ~= RoomType.ROOM_DEFAULT and roomt ~= RoomType.ROOM_DUNGEON and roomt ~= RoomType.ROOM_GREED_EXIT and roomt ~= RoomType.ROOM_SECRET_EXIT) then
		local card = player:GetCard(0)
		
		if card == 0 and player:GetCard(1) ~= 0 then
		card = player:GetCard(1)
		end
		
		if card ~= 0 and not (mod:IsAnyJoker(card) or card == mod.Enums.SpectralCards.TheSoul)
		then

		for i = 1, mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.PERKEO) do
		--Referencing the real life Perkeo drinking a lot of wine (and it was his job to taste it)
		local card1 = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, card, Isaac.GetFreeNearPosition(player.Position, 120), Vector.Zero, nil):ToPickup()
		local wine = Isaac.Spawn(1000, 32, 0, card1.Position, Vector.Zero, nil):ToEffect()
		local barrel =  Isaac.Spawn(292, 0, 0, card1.Position, Vector.Zero, nil)
		barrel:Die()
		Isaac.ExecuteCommand("playsfx 51")
		Isaac.ExecuteCommand("playsfx 481")
		wine.Color = Color(0.6,0.1,0.125,1)
		
		for i = 1, 8 do
		local winedrop = Isaac.Spawn(2, 35, 0, card1.Position, Vector(0,10):Rotated(45*i), nil):ToTear()
		winedrop.TearFlags = TearFlags.TEAR_SPECTRAL
		end
		end
		end
		end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.HandlePerkeoRoomNew)

function mod:PerkeoMyosotis()
	local roomt = Game():GetRoom():GetType()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local Fdata = mod.SaveShitNow.GetFloorSave(player)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.PERKEO) > 0 
		and Fdata and Fdata.HasGulpedMyo == nil then
		if roomt == RoomType.ROOM_BOSS or  roomt == RoomType.ROOM_GREED_EXIT then
		BalatroJokers:GulpSomething(player, 137)
		Fdata.HasGulpedMyo = true
		end
		end
		if Fdata and Fdata.HasGulpedMyo == true then
		if not (roomt == RoomType.ROOM_BOSS or  roomt == RoomType.ROOM_GREED_EXIT) then
		player:TryRemoveTrinket(137)
		Fdata.HasGulpedMyo = nil
		end
		end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.PerkeoMyosotis)

function mod:DestroyLoveItems(player)


if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.YORICK) > 0 and Game():GetFrameCount() >= (mins*60*30) -1 and  Game():GetFrameCount() <= (mins*60*30) +1 then
	player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	player:EvaluateItems()
	player:AnimateCollectible(84)
	SFXManager():Play(SoundEffect.SOUND_SHOVEL_DIG)
	if Game():GetFrameCount() == (mins*60*30) +1 then
	local sans = Isaac.Spawn(5, 350, TrinketType.TRINKET_CURSED_SKULL, player.Position, Vector(0, mod:RNGTwoParam(10,20)):Rotated(mod:RNGTwoParam(0,360)), nil):ToPickup()
	--sans:GetData().YorickSkullShouldSpawnGibs = true
	sans.Timeout = 30
	end
end


local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local itemConfig = Isaac.GetItemConfig()
if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.CANIO) > 0 then
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and BalatroJokers:IsLewdItem(i) and player:IsHoldingItem() ~= true then
    
	player:RemoveCollectible(i)
	
	local heart = Isaac.Spawn(92, 0, 0, player.Position, Vector.Zero, player) --Spawn a heart enemy
	heart.SpriteScale = Vector(2,2)
	heart.Visible = false --Make it invisible
	heart:AddEntityFlags(EntityFlag.FLAG_AMBUSH|EntityFlag.FLAG_EXTRA_GORE) --Make it not collide with Isaac, and make it die a gorier death
	heart:Kill() --Now kill it
	local slash = Isaac.Spawn(1000, 176, 0, player.Position, Vector.Zero, player) --Knife slash
	Isaac.ExecuteCommand("playsfx 540") --Knife sfx
	
	RPData.CanioDestroyed = RPData.CanioDestroyed and RPData.CanioDestroyed + 1 or 1
	player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	player:EvaluateItems()
	player:AnimateSad()
    end
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, mod.DestroyLoveItems)

function mod:EvaluateCanioDMG(player, flag)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData and RPData.CanioDestroyed and RPData.CanioDestroyed > 0 then
player.Damage = player.Damage *(1 + 0.3 * RPData.CanioDestroyed)
end
end
mod:AddPriorityCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    CallbackPriority.LATE+ 999999, --Reason: Soymilk
    mod.EvaluateCanioDMG,
	CacheFlag.CACHE_DAMAGE
)

function mod:EvaluateTribouletFireRate(player, flag)
local itemConfig = Isaac.GetItemConfig()
if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.TRIBOULET) > 0 then
local royalnum = BalatroJokers:GetFemaleItems(player)+ BalatroJokers:GetRoyalItems(player)

player.MaxFireDelay = BalatroJokers:CalculateNewFireDelay(player.MaxFireDelay, (30/(player.MaxFireDelay +1))*((1.3)^(mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.TRIBOULET)*(royalnum)^0.8)-1) )

end
end
mod:AddPriorityCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    CallbackPriority.LATE+ 999999, --Reason: Soymilk
    mod.EvaluateTribouletFireRate,
	CacheFlag.CACHE_FIREDELAY
)

function mod:HandleChicot(entity) -- 'entity' contains a reference to the NPC
local chicotfound = false
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.CHICOT) > 0 then
		chicotfound = true
		break
		end
   end
 
if chicotfound == true and entity:IsVulnerableEnemy() and not entity:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) and entity:IsBoss() and not entity:HasEntityFlags(EntityFlag.FLAG_WEAKNESS) then
entity:AddEntityFlags(EntityFlag.FLAG_WEAKNESS)
end
 
end
mod:AddCallback(ModCallbacks.MC_NPC_UPDATE, mod.HandleChicot)

function mod:EvaluateYorickDMG(player, flag)
if mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.YORICK) > 0 and Game():GetFrameCount() >= (mins*60*30) then
player.Damage = player.Damage *(2.3^mod:GetJokerCount(player, BalatroJokers.Enums.Legendaries.YORICK))
end
end
mod:AddPriorityCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    CallbackPriority.LATE+ 999999, --Reason: Soymilk
    mod.EvaluateYorickDMG,
	CacheFlag.CACHE_DAMAGE
)