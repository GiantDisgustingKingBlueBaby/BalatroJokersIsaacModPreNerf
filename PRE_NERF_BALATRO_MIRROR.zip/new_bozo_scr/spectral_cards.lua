local mod = BalatroJokers
--!!! Don't include this file yet

function mod:IsSpectralCard(joker_id)

local valid = false

for _, value in pairs(mod.Enums.SpectralCardList) do
    if value == joker_id then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

--When adding spectral cards, edit helpers.lua and inventory_manager.lua to add spectral cards and packs to enum tables

function mod:PreventDupingSpectralCards(card, player, useflags)

			local entities = Isaac.GetRoomEntities()
			for i, entity in ipairs(entities) do
				if entity.Type == 5 and (entity.Variant == 300 and mod:IsSpectralCard(entity.SubType) or (entity.Variant >= mod.Enums.Boosters.spectral and entity.Variant <= mod.Enums.Boosters.spectral_big) or mod:IsLegendaryJoker(entity.Variant)) then
				entity:GetSprite():Play("Collect")
				entity:Die()
				--local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, entity.Position, Vector.Zero, nil):ToEffect()
				entity.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				player:AnimateSad()
				end
			end

end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.PreventDupingSpectralCards, 33)
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.PreventDupingSpectralCards, 80)

function mod:PreventDupingSpectralCards2(collectibleID, rngObj, player, useFlags, activeSlot, varData)

			local entities = Isaac.GetRoomEntities()
			for i, entity in ipairs(entities) do
				if entity.Type == 5 and (entity.Variant == 300 and mod:IsSpectralCard(entity.SubType) or (entity.Variant >= mod.Enums.Boosters.spectral and entity.Variant <= mod.Enums.Boosters.spectral_big) or mod:IsLegendaryJoker(entity.Variant)) then
				entity:GetSprite():Play("Collect")
				entity:Die()
				--local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, entity.Position, Vector.Zero, nil):ToEffect()
				entity.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				player:AnimateSad()
				end
			end

end
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.PreventDupingSpectralCards2, 347)
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.PreventDupingSpectralCards2, 476)


function mod:UseWraithCard(card, player, useflags)
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
if Isaac.GetPlayer():GetNumCoins() > 0 then
Isaac.GetPlayer():AddCoins(-Isaac.GetPlayer():GetNumCoins())
end

local itemConfig = Isaac.GetItemConfig()
local starItems = {}
for i = 1, itemConfig:GetCollectibles().Size - 1 do
    local item = itemConfig:GetCollectible(i)
    if item and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and item.Quality == 4 then
        table.insert(starItems, i)
    end
end
local randomStarItem = starItems[player:GetCollectibleRNG(678):RandomInt(#starItems) + 1]
local card = Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, randomStarItem, Isaac.GetFreeNearPosition(player.Position, 40), Vector.Zero, nil):ToPickup()
player:AnimateSad()
player:UsePill(PillEffect.PILLEFFECT_TEARS_DOWN, PillColor.PILL_NULL, UseFlag.USE_NOANIM|UseFlag.USE_NOHUD|UseFlag.USE_NOANNOUNCER)
Isaac.ExecuteCommand("playsfx 582")
player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
player:EvaluateItems()
else
player:AnimateSad()
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseWraithCard, mod.Enums.SpectralCards.Wraith)

function mod:UseHexCard(card, player, useflags)
local RPData = mod.SaveShitNow.GetRunSave(player)

if RPData.S1 then
for i = 1, 15 do
if RPData.S1 then
--[[
local card = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, RPData.S1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(mod.Enums.Items.jimbos_collection):RandomInt(361)) * 10, nil):ToPickup()
card.Timeout = 30 + mod:RNGOneParam(18)
card:GetData().BalatroJokerDestroyedJokerTimeout = card.Timeout
card.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
]]
mod:DestroyJoker(player, 1)
end
end
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
Isaac.ExecuteCommand("playsfx 582")
RPData.PolychromeUseCount = RPData.PolychromeUseCount and RPData.PolychromeUseCount + 1 or 1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
player:AnimateSad()
else
player:AnimateSad()
end
else
player:AnimateSad()
end

end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseHexCard, mod.Enums.SpectralCards.Hex)

--[[
function mod:PlayDropSound3333(pickup)
if pickup:GetData().BalatroJokerDestroyedJokerTimeout then
pickup:GetData().BalatroJokerDestroyedJokerTimeout = pickup:GetData().BalatroJokerDestroyedJokerTimeout -1
if pickup:GetData().BalatroJokerDestroyedJokerTimeout == 1 then
local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, pickup.Position, Vector.Zero, nil):ToEffect()
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.PlayDropSound3333)
]]

function mod:DestroyRandomCollectible(player)
local starItems = {}
local itemConfig = Isaac.GetItemConfig()
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:HasCollectible(i, true)
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i then
        table.insert(starItems, i)
    end
end
end
local randomStarItem = starItems[player:GetCollectibleRNG(678):RandomInt(#starItems) + 1]
if randomStarItem then
player:RemoveCollectible(randomStarItem)
end
end

function mod:DestroyStrongestRandomCollectible(player)

local qmax = 0
local itemConfig = Isaac.GetItemConfig()

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and player:HasCollectible(i, true) then
        qmax = math.max(item.Quality, qmax)
    end
end
end

local starItems = {}
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and item.Quality == qmax then
        table.insert(starItems, i)
    end
end
end

local randomStarItem = starItems[player:GetCollectibleRNG(678):RandomInt(#starItems) + 1]

if randomStarItem then
player:RemoveCollectible(randomStarItem)

local RPData = mod.SaveShitNow.GetRunSave(player)

if not RPData.LuigiTableOn then
RPData.LuigiTable = {}
table.insert(RPData.LuigiTable, randomStarItem)
RPData.LuigiTableOn = true
else
table.insert(RPData.LuigiTable, randomStarItem)
end
end

end

function mod:PostLuigiTable(player, num)
local RPData = mod.SaveShitNow.GetRunSave(player)
if not RPData.LuigiTableOn then return end
local randomlychosenitem = RPData.LuigiTable[player:GetCollectibleRNG(678):RandomInt(#RPData.LuigiTable) + 1]

for i = 1, num do
Isaac.Spawn(5,100, randomlychosenitem, Isaac.GetFreeNearPosition(player.Position, 55),Vector.Zero,nil)
end

RPData.LuigiTable = {}
RPData.LuigiTableOn = nil

end

function mod:UseLuigiCard(card, player, useflags)
player:AddBrokenHearts(2)
local collectiblecount = 0
local itemConfig = Isaac.GetItemConfig()
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i then
        collectiblecount = collectiblecount + 1
    end
end
end

if collectiblecount >= 1 then
for i=1 , math.min(3, collectiblecount) do
mod:DestroyStrongestRandomCollectible(player)
end
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
mod:PostLuigiTable(player, math.min(3, collectiblecount))--gives items
SFXManager():Play(582,2)
SFXManager():Play(316,2)
else
local RPData = mod.SaveShitNow.GetRunSave(player)
RPData.LuigiTable = {}
RPData.LuigiTableOn = nil
player:AnimateSad() --mimicking is punishing
end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseLuigiCard, mod.Enums.SpectralCards.Ouija)

function mod:UseGrimCard(card, player, useflags)

local collectiblecount = 0
local itemConfig = Isaac.GetItemConfig()
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i then
        collectiblecount = collectiblecount + 1
    end
end
end

if collectiblecount >= 1 then
mod:DestroyRandomCollectible(player)

if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
for v=1,2 do
local itemConfig = Isaac.GetItemConfig()
local starItems = {}
for i = 1, itemConfig:GetCollectibles().Size - 1 do
    local item = itemConfig:GetCollectible(i)
    if item and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and item.Quality == 3 then
        table.insert(starItems, i)
    end
end
local randomStarItem = starItems[player:GetCollectibleRNG(678):RandomInt(#starItems) + 1]

local card = Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, randomStarItem, Isaac.GetFreeNearPosition(player.Position + Vector(-210+140*v,-50), 1), Vector.Zero, nil):ToPickup()
card.OptionsPickupIndex = 8475+Game():GetFrameCount()
end

SFXManager():Play(582,2)
SFXManager():Play(316,2)
else
player:AnimateSad() --mimicking is punishing
end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseGrimCard, mod.Enums.SpectralCards.Grim)

mod.CrashingIDList = {43,59,61235263587,613,620,630,648,656,662,666,718,BalatroJokers.Enums.Items.jimbos_collection} --Fuck you Edmund Fuck you Kilburn Fuck you Nicalis

function mod:Blacklist(joker_id)

local valid = false

for _, value in ipairs(mod.CrashingIDList) do
    if value == joker_id then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function mod:UseCryptidCard(card, player, useflags)

local qmax = 0
local itemConfig = Isaac.GetItemConfig()

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true)and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
		and item:HasTags(ItemConfig.TAG_SUMMONABLE)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i then
        qmax = math.max(item.Quality, qmax)
    end
end
end

local starItems = {}
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and item:HasTags(ItemConfig.TAG_SUMMONABLE)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and item.Quality == qmax then
        table.insert(starItems, i)
    end
end
end

local randomStarItem = starItems[player:GetCollectibleRNG(678):RandomInt(#starItems) + 1]

local collectiblecount = 0
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if player:HasCollectible(i, true) and not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_SECONDARY) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i then
        collectiblecount = collectiblecount + 1
    end
end
end

if collectiblecount >= 1 then
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then

mod.HideShitNow:AddForFloor(player, randomStarItem, 5328)
mod.HideShitNow:AddForFloor(player, randomStarItem, 5328)

end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseCryptidCard, mod.Enums.SpectralCards.Cryptid)