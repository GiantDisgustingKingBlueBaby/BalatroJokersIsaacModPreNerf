local mod = BalatroJokers

--Todo:

function mod:UseTurtleBeanCard(card, player, useflags)
local HasGlasses = false
if player:HasCollectible(245) then
HasGlasses = true
end

player:UseActiveItem(111,UseFlag.USE_NOANIM,-1,0)
 for i = 1, 5 do
 BalatroJokers.HideShitNow:Add(player, 245, 30 * 6 * i) 
 end
 if HasGlasses == false then
 player:RemoveCostume(Isaac.GetItemConfig():GetCollectible(245))
 end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseTurtleBeanCard, mod.Enums.Jokers.TurtleBean)


function mod:UseIceCream(card, player, useflags)
 local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local HasGlasses = false

 BalatroJokers.HideShitNow:Add(player, 596, 300) 

RPData.IceCreamMult = RPData.IceCreamMult and RPData.IceCreamMult + 900 or 900
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
 
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseIceCream, mod.Enums.Jokers.IceCream)

function mod:IceCreamUpdate(player)
 local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

if RPData.IceCreamMult then
if RPData.IceCreamMult > 0 then
RPData.IceCreamMult = RPData.IceCreamMult -1
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
else
RPData.IceCreamMult = nil
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
end		
end
end
mod:AddCallback(
    ModCallbacks.MC_POST_PEFFECT_UPDATE,
    mod.IceCreamUpdate
)

function mod:CheckTearsMult(player,flag)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

if RPData.IceCreamMult then
player.MaxFireDelay = BalatroJokers:CalculateNewFireDelay(player.MaxFireDelay, (2.5)*(RPData.IceCreamMult/900))
else
player.MaxFireDelay = BalatroJokers:CalculateNewFireDelay(player.MaxFireDelay, (30/1+player.MaxFireDelay)*0)
end

end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.CheckTearsMult,
	CacheFlag.CACHE_FIREDELAY
)
--BalatroJokers:CalculateNewFireDelay(currentTearRate, offsetBy)

function mod:UseCardBonusArcana(card, player, useflags)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	if (useflags & UseFlag.USE_NOANIM == 0) then
	if Isaac.GetItemConfig():GetCard(card):IsCard() 
	and (mod:CardTypeBoolean(card, BalatroJokers.Enums.CardGroup.TAROT)
	or mod:CardTypeBoolean(card, BalatroJokers.Enums.CardGroup.TAROT_REVERSED) )
	then
		RPData.Arcana = RPData.Arcana and RPData.Arcana+1 or 1
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
end
end
mod:AddPriorityCallback(
    ModCallbacks.MC_USE_CARD,
   CallbackPriority.LATE + 999999,
   mod.UseCardBonusArcana
)

function mod:UseFortuneTeller(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseFortuneTeller, BalatroJokers.Enums.Jokers.FortuneTeller)

function mod:BabeRuth(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.BabeRuth, BalatroJokers.Enums.Jokers.Baseball)

function mod:BaronUse(card, player, useflags)
--SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.BaronUse, BalatroJokers.Enums.Jokers.Baron)

function mod:BaronEvalDMG(player,flag)
local itemConfig = Isaac.GetItemConfig()

local starItems = 0
for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not mod:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and item.Quality == 4
	and player:HasCollectible(i, true) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Baron) > 0  then
player.Damage = player.Damage * 1.3^((starItems*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Baron))^(1/2.5))
end

end
mod:AddCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    mod.BaronEvalDMG,
	CacheFlag.CACHE_DAMAGE
)

function mod:PostLoadGameStart(iscontinued)
if Diepio then
Diepio:AddPocketcatItemMidRange(BalatroJokers.Enums.Items.jimbos_collection)
end
end
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, mod.PostLoadGameStart)