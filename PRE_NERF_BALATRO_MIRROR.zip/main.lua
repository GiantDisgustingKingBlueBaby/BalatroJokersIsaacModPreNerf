BalatroJokers = RegisterMod("Balatro Jokers", 1)
local mod = BalatroJokers --Added global modref

include("hamburger_helper.helper")
--Stores tables and enumerated types, and some helper functions
--Also stores English EID descriptions too
include("hamburger_helper.random_number_helpers")
--No more "math.random()". Everything is seeded now.

mod.SaveShitNow = include("hamburger_helper.save_manager")
--We're using Catinsurance's Savemanager for easier save file management (Developed by Catinsurance and Benny)
mod.SaveShitNow.Init(mod)
mod.HideShitNow = include("hamburger_helper.hidden_item_manager"):Init(mod)
--For handling hidden items; Library developed by Ghostbroster Connor (Samael mod guy)
mod.MimicShitNow = include("hamburger_helper.incubus_at_home")
--My stupid fucking minisaac library that left a lot of people on MoI confused. I'm sorry.

function BalatroJokers:PreSave(data)
	BalatroJokers.SaveShitNow.DEFAULT_SAVE.HIDDEN_ITEM_DATA = BalatroJokers.HideShitNow:GetSaveData()
end
BalatroJokers.SaveShitNow.AddCallback(BalatroJokers.SaveShitNow.Utility.CustomCallback.PRE_DATA_SAVE, BalatroJokers.PreSave)
function BalatroJokers:PostLoad(data)
	BalatroJokers.HideShitNow:LoadData(BalatroJokers.SaveShitNow.DEFAULT_SAVE.HIDDEN_ITEM_DATA)
end
BalatroJokers.SaveShitNow.AddCallback(BalatroJokers.SaveShitNow.Utility.CustomCallback.POST_DATA_LOAD, BalatroJokers.PostLoad)
--For saving and loading save data

include("bozo_scr.basic_jokers")
--Handles Jimbo, Wrathful, Lusty, Gluttonous, Greedy, Misprint
include("bozo_scr.room_jokers")
--Handles Jolly, Wily, and some more jokers
include("bozo_scr.stencil_jokers")
--Handles the rest of the jokers
include("bozo_scr.do_you_suck_decks")
--Handles deck cards
include("bozo_scr.planet_cards")
--Handles planet cards
include("bozo_scr.inventory_manager")
--Handles inventory logic, Blank Voucher and HUD
include("bozo_scr.evaluate_joker_stats")
--Handles stat changes
include("bozo_scr.effects")
--Handles Jimbo particles and "Nope!" feedback effect (They were not removed properly when their animations were finished before the bug fix)
include("bozo_scr.booster_packs")
--Handles Booster Packs; No longer relies on save data; Also handles Seed Money and Overstock.
include("bozo_scr.balatro_vouchers")
--Handles vouchers' general function and most of the vouchers' abilities, except Blank.
include("bozo_scr.jimbos_collection")
--Handles Jimbo's Collection logic
include("bozo_scr.misc_trinkets")
--Handles miscellaneous trinkets
include("new_bozo_scr.spectral_cards")
--Spectral Cards
include("new_bozo_scr.february_update_jokers")
--Turtle Bean, Baron, Baseball, Fortune Teller, Ice Cream
include("hamburger_helper.deadseacrolls_but_really")
--DSS mod config
include("new_bozo_scr.deadseascrollssupport")
--DSS and sell mechanic
include("new_bozo_scr.legendary_jokers")
--Legendary Jokers & Soul Card
include("new_bozo_scr.valentines_update_cards")
--Valentines update (20 jokers, 2 decks)
include("hamburger_helper.minisaac_mimic_library")

if EID then
include("translations_eid.eid_kr")
--Korean translation, done by me
include("translations_eid.eid_cn")
--Chinese translation, courtesy of OucalGarlin
include("translations_eid.eid_spa")
--Spanish translation, courtesy of yaz_dako
include("translations_eid.eid_it")
--Italian translation, courtesy of stracto
end

--Will add more stuff in the future, like Jimbo character, challenges, more cards or collectibles

