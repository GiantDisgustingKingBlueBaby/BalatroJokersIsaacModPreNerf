function BalatroJokers:CalculateNewFireDelay(currentTearRate, offsetBy)
    local currentTears = 30 / (currentTearRate + 1)
    local newTears = currentTears + offsetBy
    return math.max((30 / newTears) - 1, -0.9999)
end

BalatroJokers.Enums = {}

BalatroJokers.Enums.CardGroup = {
SUIT = 0,
PLANET = 1,
TAROT = 2,
TAROT_REVERSED = 3,
JOKER = 4,
RUNE = 5,
SOUL = 6,
SPECIAL = 7,
DECK = 8,
SPECTRAL = 9,
}

----------------------------------------- ITEMS/TRINKETS
BalatroJokers.Enums.Trinkets = {
torn_voucher = Isaac.GetTrinketIdByName("Torn Voucher"),
wasteful_voucher = Isaac.GetTrinketIdByName("Wasteful Voucher"),
tarot_voucher = Isaac.GetTrinketIdByName("Tarot Voucher"),
planet_voucher = Isaac.GetTrinketIdByName("Planet Voucher"),
seed_voucher = Isaac.GetTrinketIdByName("Seed Voucher"),
directors_voucher = Isaac.GetTrinketIdByName("Director's Voucher"),
hone_voucher = Isaac.GetTrinketIdByName("Hone Voucher"),
overstock_voucher = Isaac.GetTrinketIdByName("Overstock Voucher"),
magic_voucher = Isaac.GetTrinketIdByName("Magic Voucher"),
clearance_voucher = Isaac.GetTrinketIdByName("Clearance Voucher"),
reroll_voucher = Isaac.GetTrinketIdByName("Reroll Voucher"),
hieroglyph_voucher = Isaac.GetTrinketIdByName("Hieroglyph Voucher"),

Blank = Isaac.GetTrinketIdByName("Blank Voucher"),

card_house = Isaac.GetTrinketIdByName("Card House"),
cheap_suit = Isaac.GetTrinketIdByName("Cheap Suit"),
first_edition = Isaac.GetTrinketIdByName("First Edition"),
stone_card = Isaac.GetTrinketIdByName("Stone Card"),
double_stakes = Isaac.GetTrinketIdByName("Double Stakes"),
}

BalatroJokers.Enums.Items = {
jimbos_collection = Isaac.GetItemIdByName("Jimbo's Collection"),
}

BalatroJokers.Enums.Slots = {
JIMBO_MACHINE = Isaac.GetEntityVariantByName("Balatro Booster Vending Machine"),
}

----------------------------------------- Booster PackS

BalatroJokers.Enums.Boosters = {
standard_pack = Isaac.GetEntityVariantByName("Standard Pack"),
standard_packj = Isaac.GetEntityVariantByName("Standard Pack (Jumbo)"),
standard_packm = Isaac.GetEntityVariantByName("Standard Pack (Mega)"),
arcana_pack = Isaac.GetEntityVariantByName("Arcana Pack"),
arcana_packj = Isaac.GetEntityVariantByName("Arcana Pack (Jumbo)"),
arcana_packm = Isaac.GetEntityVariantByName("Arcana Pack (Mega)"),
planet_pack = Isaac.GetEntityVariantByName("Planet Pack"),
planet_packj = Isaac.GetEntityVariantByName("Planet Pack (Jumbo)"),
planet_packm = Isaac.GetEntityVariantByName("Planet Pack (Mega)"),
buffoon_pack = Isaac.GetEntityVariantByName("Buffoon Pack"),
buffoon_packj = Isaac.GetEntityVariantByName("Buffoon Pack (Jumbo)"),
buffoon_packm = Isaac.GetEntityVariantByName("Buffoon Pack (Mega)"),
spectral = Isaac.GetEntityVariantByName("Spectral Pack"),
spectral_medium = Isaac.GetEntityVariantByName("Spectral Pack (Jumbo)"),
spectral_big = Isaac.GetEntityVariantByName("Spectral Pack (Mega)"),
}

----------------------------------------- MISC PACKS
BalatroJokers.Enums.ExtraPacks = {
deck_pack = Isaac.GetEntityVariantByName("Deck Pack (Torn)"),
fun_pack = Isaac.GetEntityVariantByName("Fun Pack (Torn)"),
}

----------------------------------------- DECK CARDS

BalatroJokers.Enums.Decks = {
RedDeck = Isaac.GetCardIdByName("RedDeck"),
BlueDeck = Isaac.GetCardIdByName("BlueDeck"),
YellowDeck = Isaac.GetCardIdByName("YellowDeck"),
GreenDeck = Isaac.GetCardIdByName("GreenDeck"),
BlackDeck = Isaac.GetCardIdByName("BlackDeck"),
PlasmaDeck = Isaac.GetCardIdByName("PlasmaDeck"),
AbandonedDeck = Isaac.GetCardIdByName("AbandonedDeck"),
}

----------------------------------------- EFFECTS
BalatroJokers.Enums.Effects = {
Nope_Effect = Isaac.GetEntityVariantByName("Nope"),
Jimbo_Effect = Isaac.GetEntityVariantByName("Jimbo Effect"),
}

--Misc. Constants
BalatroJokers.Enums.Constants = {
SpawnedPickupTimeout = 99999,
}
----------------------------------------- PLANET CARDS

BalatroJokers.Enums.Planets = {
Pluto = Isaac.GetCardIdByName("Pluto"),
Mercury = Isaac.GetCardIdByName("Mercury"),
Uranus = Isaac.GetCardIdByName("Uranus"),
Venus = Isaac.GetCardIdByName("Venus"),
Saturn = Isaac.GetCardIdByName("Saturn"),
Jupiter = Isaac.GetCardIdByName("Jupiter"),
Earth = Isaac.GetCardIdByName("Earth"),
Mars = Isaac.GetCardIdByName("Mars"),
Neptune = Isaac.GetCardIdByName("Neptune"),
}

----------------------------------------- JOKERS

BalatroJokers.Enums.Jokers = {
BJoker = Isaac.GetCardIdByName("Joker_Jimbo"), --Added ZWSP in case other mods mess with this
GreedyJoker = Isaac.GetCardIdByName("Greedy Joker"),
LustyJoker = Isaac.GetCardIdByName("Lusty Joker"),
WrathfulJoker = Isaac.GetCardIdByName("Wrathful Joker"),
GluttonousJoker = Isaac.GetCardIdByName("Gluttonous Joker"),
JollyJoker = Isaac.GetCardIdByName("Jolly Joker"),
WilyJoker = Isaac.GetCardIdByName("Wily Joker"),
HalfJoker = Isaac.GetCardIdByName("Half Joker"),
JokerStencil = Isaac.GetCardIdByName("Joker Stencil"),
Mime = Isaac.GetCardIdByName("Mime"),
MarbleJoker = Isaac.GetCardIdByName("Marble Joker"),
EightBall = Isaac.GetCardIdByName("8 Ball"),
Misprint = Isaac.GetCardIdByName("Misprint"),
RaisedFist = Isaac.GetCardIdByName("Raised Fist"),
Fibonacci = Isaac.GetCardIdByName("Fibonacci"),
ScaryFace = Isaac.GetCardIdByName("Scary Face"),
Hack = Isaac.GetCardIdByName("Hack"),
GrosMichel = Isaac.GetCardIdByName("Gros Michel"),
Supernova = Isaac.GetCardIdByName("Supernova"),
SpaceJoker = Isaac.GetCardIdByName("Space Joker"),
Egg = Isaac.GetCardIdByName("Egg"),
Blackboard = Isaac.GetCardIdByName("Blackboard"),
BlueJoker = Isaac.GetCardIdByName("Blue Joker"),
SquareJoker = Isaac.GetCardIdByName("Square Joker"),
RiffRaff = Isaac.GetCardIdByName("Riff-Raff"),
Vampire = Isaac.GetCardIdByName("Vampire"),
Vagabond = Isaac.GetCardIdByName("Vagabond"),
Rocket = Isaac.GetCardIdByName("Rocket"),
Hologram = Isaac.GetCardIdByName("Hologram"),
TurtleBean = Isaac.GetCardIdByName("TurtleBean"),
IceCream = Isaac.GetCardIdByName("IceCreamJoker"),
Baron = Isaac.GetCardIdByName("BaronJoker"),
Baseball = Isaac.GetCardIdByName("Baseball Card"),
FortuneTeller =  Isaac.GetCardIdByName("FortuneTeller"),
--Val.update
ShootTheMoon = Isaac.GetCardIdByName("ShootTheMoon"),
Juggler = Isaac.GetCardIdByName("JugglerBalatro"),
Splash = Isaac.GetCardIdByName("SplashBalatro"),
Photo = Isaac.GetCardIdByName("PhotoBalatro"),
HangingChad = Isaac.GetCardIdByName("HangingChadBalatro"),
Superposition = Isaac.GetCardIdByName("SuperpositionBalatro"),
ChaosTheClown = Isaac.GetCardIdByName("ChaosTheClown"),
Abstract = Isaac.GetCardIdByName("AbstractJoker"),
Madness = Isaac.GetCardIdByName("MadnessJoker"),
Pareidolia =  Isaac.GetCardIdByName("PareidoliaJoker"),
SteelJoker = Isaac.GetCardIdByName("SteelJoker"),
GoldenTicket = Isaac.GetCardIdByName("GoldenTicketBalatro"),
DNA = Isaac.GetCardIdByName("DNABalatro"),
GlassJoker = Isaac.GetCardIdByName("GlassJoker"),
DietCola = Isaac.GetCardIdByName("DietColaBalatro"),
OopsAll6s = Isaac.GetCardIdByName("OopsAll6sBalatro"),
Smeared = Isaac.GetCardIdByName("SmearedJoker"),
Blueprint = Isaac.GetCardIdByName("BlueprintBalatro"),
Erosion = Isaac.GetCardIdByName("ErosionBalatro"),
Wee =  Isaac.GetCardIdByName("WeeJoker"),
Brainstorm =  Isaac.GetCardIdByName("BrainstormBalatro"),
}

BalatroJokers.AllJokers = {
	BalatroJokers.Enums.Jokers.BJoker,
	BalatroJokers.Enums.Jokers.GreedyJoker,
	BalatroJokers.Enums.Jokers.LustyJoker,
	BalatroJokers.Enums.Jokers.WrathfulJoker,
	BalatroJokers.Enums.Jokers.GluttonousJoker,
	BalatroJokers.Enums.Jokers.JollyJoker,
	BalatroJokers.Enums.Jokers.WilyJoker,
	BalatroJokers.Enums.Jokers.HalfJoker,
	BalatroJokers.Enums.Jokers.JokerStencil,
	BalatroJokers.Enums.Jokers.Mime,
	BalatroJokers.Enums.Jokers.MarbleJoker,
	BalatroJokers.Enums.Jokers.EightBall,
	BalatroJokers.Enums.Jokers.Misprint,
	BalatroJokers.Enums.Jokers.RaisedFist,
	BalatroJokers.Enums.Jokers.Fibonacci,
	BalatroJokers.Enums.Jokers.ScaryFace,
	BalatroJokers.Enums.Jokers.Hack,
	BalatroJokers.Enums.Jokers.GrosMichel,
	BalatroJokers.Enums.Jokers.Supernova,
	BalatroJokers.Enums.Jokers.SpaceJoker,
	BalatroJokers.Enums.Jokers.Egg,
	BalatroJokers.Enums.Jokers.Blackboard,
	BalatroJokers.Enums.Jokers.BlueJoker,
	BalatroJokers.Enums.Jokers.SquareJoker,
	BalatroJokers.Enums.Jokers.RiffRaff,
	BalatroJokers.Enums.Jokers.Vampire,
	BalatroJokers.Enums.Jokers.Vagabond,
	BalatroJokers.Enums.Jokers.Rocket,
	BalatroJokers.Enums.Jokers.Hologram,
	BalatroJokers.Enums.Jokers.Baron,
	BalatroJokers.Enums.Jokers.Baseball,
	BalatroJokers.Enums.Jokers.IceCream,
	BalatroJokers.Enums.Jokers.FortuneTeller,
	BalatroJokers.Enums.Jokers.TurtleBean,
	BalatroJokers.Enums.Jokers.ShootTheMoon,
	BalatroJokers.Enums.Jokers.Juggler,
	BalatroJokers.Enums.Jokers.Splash,
	BalatroJokers.Enums.Jokers.Photo,
	BalatroJokers.Enums.Jokers.HangingChad,
	BalatroJokers.Enums.Jokers.Superposition,
	BalatroJokers.Enums.Jokers.ChaosTheClown,
	BalatroJokers.Enums.Jokers.Abstract,
	BalatroJokers.Enums.Jokers.Madness,
	BalatroJokers.Enums.Jokers.Pareidolia,
	BalatroJokers.Enums.Jokers.SteelJoker,
	BalatroJokers.Enums.Jokers.GoldenTicket,
	BalatroJokers.Enums.Jokers.DNA,
	BalatroJokers.Enums.Jokers.GlassJoker,
	BalatroJokers.Enums.Jokers.DietCola,
	BalatroJokers.Enums.Jokers.OopsAll6s,
	BalatroJokers.Enums.Jokers.Smeared,
	BalatroJokers.Enums.Jokers.Blueprint,
	BalatroJokers.Enums.Jokers.Erosion,
	BalatroJokers.Enums.Jokers.Wee,
	BalatroJokers.Enums.Jokers.Brainstorm,
	43
}   

BalatroJokers.Enums.RiffRaffTable = {
Isaac.GetCardIdByName("Joker_Jimbo"), --Added ZWSP in case other mods mess with this
Isaac.GetCardIdByName("Greedy Joker"),
Isaac.GetCardIdByName("Lusty Joker"),
Isaac.GetCardIdByName("Wrathful Joker"),
Isaac.GetCardIdByName("Gluttonous Joker"),
Isaac.GetCardIdByName("Jolly Joker"),
Isaac.GetCardIdByName("Wily Joker"),
Isaac.GetCardIdByName("Half Joker"),
Isaac.GetCardIdByName("8 Ball"),
 Isaac.GetCardIdByName("Misprint"),
Isaac.GetCardIdByName("Raised Fist"),
Isaac.GetCardIdByName("Scary Face"),
Isaac.GetCardIdByName("Gros Michel"),
Isaac.GetCardIdByName("Supernova"),
Isaac.GetCardIdByName("Egg"),
Isaac.GetCardIdByName("Blue Joker"), 
Isaac.GetCardIdByName("Square Joker"),
Isaac.GetCardIdByName("IceCreamJoker"),
Isaac.GetCardIdByName("FortuneTeller"),
Isaac.GetCardIdByName("GoldenTicketBalatro"),
Isaac.GetCardIdByName("AbstractJoker"),
Isaac.GetCardIdByName("ShootTheMoon"),
Isaac.GetCardIdByName("JugglerBalatro"),
Isaac.GetCardIdByName("SplashBalatro"),
Isaac.GetCardIdByName("PhotoBalatro"),
Isaac.GetCardIdByName("HangingChadBalatro"),
Isaac.GetCardIdByName("SuperpositionBalatro"),
Isaac.GetCardIdByName("ChaosTheClown"),
43
}

----------------------------------------- SFX

BalatroJokers.Enums.SFX = {
RedCardSFX = Isaac.GetSoundIdByName("redcard_VO"),
BlueCardSFX = Isaac.GetSoundIdByName("bluecard_VO"),
YellowCardSFX = Isaac.GetSoundIdByName("yellowcard_VO"),
GreenCardSFX = Isaac.GetSoundIdByName("greencard_VO"),
BlackCardSFX = Isaac.GetSoundIdByName("blackcard_VO"),
PlutoSFX = Isaac.GetSoundIdByName("pluto_VO"),
MercurySFX = Isaac.GetSoundIdByName("mercury_VO"),
UranusSFX = Isaac.GetSoundIdByName("uranus_VO"),
VenusSFX = Isaac.GetSoundIdByName("venus_VO"),
SaturnSFX = Isaac.GetSoundIdByName("saturn_VO"),
JupiterSFX = Isaac.GetSoundIdByName("jupiter_VO"),
EarthSFX = Isaac.GetSoundIdByName("earth_VO"),
MarsSFX = Isaac.GetSoundIdByName("mars_VO"),
NeptuneSFX = Isaac.GetSoundIdByName("neptune_VO"),
JimboSFX = Isaac.GetSoundIdByName("jimbo_SFX"),
NopeSFX = Isaac.GetSoundIdByName("nope_SFX"),
BJokerSFX = Isaac.GetSoundIdByName("bjoker_VO"),
GreedyJokerSFX = Isaac.GetSoundIdByName("greedyjoker_VO"),
LustyJokerSFX = Isaac.GetSoundIdByName("lustyjoker_VO"),
WrathfulJokerSFX = Isaac.GetSoundIdByName("wrathfuljoker_VO"),
GluttonousJokerSFX = Isaac.GetSoundIdByName("gluttonousjoker_VO"),
JollyJokerSFX = Isaac.GetSoundIdByName("jollyjoker_VO"),
WilyJokerSFX = Isaac.GetSoundIdByName("wilyjoker_VO"),
HalfJokerSFX = Isaac.GetSoundIdByName("halfjoker_VO"),
JokerStencilSFX = Isaac.GetSoundIdByName("jokerstencil_VO"),
MimeSFX = Isaac.GetSoundIdByName("mime_VO"),
MarbleJokerSFX = Isaac.GetSoundIdByName("marblejoker_VO"),
EightBallSFX = Isaac.GetSoundIdByName("eightball_VO"),
MisprintSFX = Isaac.GetSoundIdByName("misprint_VO"),
RaisedFistSFX = Isaac.GetSoundIdByName("raisedfist_VO"),
FibonacciSFX = Isaac.GetSoundIdByName("fibonacci_VO"),
ScaryFaceSFX = Isaac.GetSoundIdByName("scaryface_VO"),
HackSFX = Isaac.GetSoundIdByName("hack_VO"),
GrosMichelSFX = Isaac.GetSoundIdByName("grosmichel_VO"),
SupernovaSFX = Isaac.GetSoundIdByName("supernova_VO"),
SpaceJokerSFX = Isaac.GetSoundIdByName("spacejoker_VO"),
EggSFX = Isaac.GetSoundIdByName("egg_VO"),
BlackboardSFX = Isaac.GetSoundIdByName("blackboard_VO"),
BlueJokerSFX = Isaac.GetSoundIdByName("bluejoker_VO"),
SquareJokerSFX = Isaac.GetSoundIdByName("squarejoker_VO"),
RiffRaffSFX = Isaac.GetSoundIdByName("riffraff_VO"),
VampireSFX = Isaac.GetSoundIdByName("vampire_VO"),
VagabondSFX = Isaac.GetSoundIdByName("vagabond_VO"),
RocketSFX = Isaac.GetSoundIdByName("rocket_VO"),
HologramSFX = Isaac.GetSoundIdByName("hologram_VO"),
}
--Spectral CARDS
BalatroJokers.Enums.SpectralCards = {
Grim = Isaac.GetCardIdByName("GrimBalatro"),
Ouija = Isaac.GetCardIdByName("OuijaBalatro"),
Hex = Isaac.GetCardIdByName("HexBalatro"),
Wraith = Isaac.GetCardIdByName("WraithBalatro"),
Cryptid = Isaac.GetCardIdByName("CryptidBalatro"),
TheSoul = Isaac.GetCardIdByName("TheSoulBalatro"),
}

BalatroJokers.Enums.SpectralCardList = { 
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("GrimBalatro"),
Isaac.GetCardIdByName("OuijaBalatro"),
Isaac.GetCardIdByName("HexBalatro"),
Isaac.GetCardIdByName("WraithBalatro"),
Isaac.GetCardIdByName("CryptidBalatro"),
Isaac.GetCardIdByName("TheSoulBalatro"),
}


BalatroJokers.Enums.Legendaries = {
PERKEO = Isaac.GetEntityVariantByName("Perkeo Joker Card"),
CANIO = Isaac.GetEntityVariantByName("Canio Joker Card"),
TRIBOULET = Isaac.GetEntityVariantByName("Triboulet Joker Card"),
CHICOT = Isaac.GetEntityVariantByName("Chicot Joker Card"),
YORICK = Isaac.GetEntityVariantByName("Yorick Joker Card"),
}
BalatroJokers.Enums.LegendariesList = {
BalatroJokers.Enums.Legendaries.PERKEO,
BalatroJokers.Enums.Legendaries.CANIO,
BalatroJokers.Enums.Legendaries.TRIBOULET,
BalatroJokers.Enums.Legendaries.CHICOT,
BalatroJokers.Enums.Legendaries.YORICK,
}


----------------------------------------- EID

if not __eidItemDescriptions then
  __eidItemDescriptions = {}
end

if EID ~= nil then

EID:addColor("ColorMint", KColor(0.36, 0.87, 0.51, 1))

eidSprite = Sprite()
eidSprite:Load("gfx/eid_icons.anm2", true)

EID:addIcon("bjokercard", "1", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("planetcard", "2", -1, 9, 12, 4, 5, eidSprite)
--
EID:addIcon("standardpack", "3", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("standardpackj", "8", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("standardpackm", "12", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("planetpack", "4", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("planetpackj", "9", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("planetpackm", "13", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("arcanapack", "5", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("arcanapackj", "10", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("arcanapackm", "14", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("buffoonpack", "34", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("buffoonpackj", "35", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("buffoonpackm", "36", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("randompackthree", "6", -1, 9, 12, 4, 5.5, eidSprite)
EID:addIcon("randomvoucherthree", "11", -1, 9, 12, 4, 5.5, eidSprite)
EID:addIcon("randomvouchersingle", "7", -1, 9, 12, 4, 5.5, eidSprite)
--
EID:addIcon("voucher", "15", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("packbonusglowing", "16", -1, 9, 12, 4, 5.5, eidSprite)
EID:addIcon("packbonus", "17", -1, 9, 12, 4, 5.5, eidSprite)
--
EID:addIcon("reversecard", "18", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("randomspecial", "19", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("tarotcard", "20", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("playingcard", "21", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("dshard", "22", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("rune", "23", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("soulstone", "24", -1, 9, 12, 4, 6, eidSprite)
--
EID:addIcon("deckpackt", "25", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("funpackt", "32", -1, 9, 12, 4, 4, eidSprite)
--
EID:addIcon("reddcard", "26", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("bluedcard", "27", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("yellowdcard", "28", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("greendcard", "29", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("blackdcard", "30", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("randomdcard", "31", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("funcard", "33", -1, 9, 12, 4, 4, eidSprite)

EID:addIcon("spectralcard", "speccard", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("spectralpack", "specpack", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("spectralpackmid", "specj", -1, 9, 12, 4, 4, eidSprite)
EID:addIcon("spectralpackbig", "specm", -1, 9, 12, 4, 4, eidSprite)

-- EID CARD ICON --

EID:addIcon("Card"..BalatroJokers.Enums.Planets.Pluto, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Mercury, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Uranus, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Venus, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Saturn, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Jupiter, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Earth, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Mars, "2", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Planets.Neptune, "2", -1, 9, 12, 4, 5, eidSprite)
--
EID:addIcon("Card"..BalatroJokers.Enums.Decks.RedDeck, "26", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.BlueDeck, "27", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.YellowDeck, "28", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.GreenDeck, "29", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.BlackDeck, "30", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.PlasmaDeck, "plasma", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.Decks.AbandonedDeck, "abandoned", -1, 9, 12, 4, 5, eidSprite)
--

for i = BalatroJokers.Enums.Jokers.BJoker, BalatroJokers.AllJokers[#BalatroJokers.AllJokers] do
EID:addIcon("Card"..i, "1", -1, 9, 12, 4, 5, eidSprite)
end

--spec
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.Wraith, "speccard", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.Grim, "speccard", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.Ouija, "speccard", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.Cryptid, "speccard", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.Hex, "speccard", -1, 9, 12, 4, 5, eidSprite)
EID:addIcon("Card"..BalatroJokers.Enums.SpectralCards.TheSoul, "speccard", -1, 9, 12, 4, 5, eidSprite)

	-- STANDARD PACKS
	EID:addEntity(5, BalatroJokers.Enums.Boosters.standard_pack, 1, "{{standardpack}} Standard Pack", "Spawns 3x {{playingcard}} Playing Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.standard_packj, 1, "{{standardpackj}} Jumbo Standard Pack", "Spawns 3x {{playingcard}} Playing Cards 1x {{rune}} Rune on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.standard_packm, 1, "{{standardpackm}} Mega Standard Pack", "Spawns 3x {{playingcard}} Playing Cards 1x {{rune}} Rune 1x {{soulstone}} Soulstone on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	-- ARCANA PACKS
	EID:addEntity(5, BalatroJokers.Enums.Boosters.arcana_pack, 1, "{{arcanapack}} Arcana Pack", "Spawns 3x {{tarotcard}} Tarot Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.arcana_packj, 1, "{{arcanapackj}} Jumbo Arcana Pack", "Spawns 3x {{tarotcard}} Tarot Cards 1x {{reversecard}} Reversed Tarot Card on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.arcana_packm, 1, "{{arcanapackm}} Mega Arcana Pack", "Spawns 3x {{tarotcard}} Tarot Cards 1x {{reversecard}} Reversed Tarot Card 1x {{randomspecial}} Special Card on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	-- PLANET PACKS
	EID:addEntity(5, BalatroJokers.Enums.Boosters.planet_pack, 1, "{{planetpack}} Planet Pack", "Spawns 3x {{planetcard}} Planet Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.planet_packj, 1, "{{planetpackj}} Jumbo Planet Pack", "Spawns 4x {{planetcard}} Planet Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.planet_packm, 1, "{{planetpackm}} Mega Planet Pack", "Spawns 5x {{planetcard}} Planet Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	-- BUFFOON PACKS
	EID:addEntity(5, BalatroJokers.Enums.Boosters.buffoon_pack, 1, "{{buffoonpack}} Buffoon Pack", "Spawns 3x {{bjokercard}} Joker Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.buffoon_packj, 1, "{{buffoonpackj}} Jumbo Buffoon Pack", "Spawns 4x {{bjokercard}} Joker Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.buffoon_packm, 1, "{{buffoonpackm}} Mega Buffoon Pack", "Spawns 5x {{bjokercard}} Joker Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	-- MISC PACKS
	EID:addEntity(5, BalatroJokers.Enums.ExtraPacks.deck_pack, 1, "{{deckpackt}} Torn Deck Pack", "Spawns 2x {{randomdcard}} Deck Cards on pick up#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.ExtraPacks.fun_pack, 1, "{{funpackt}} Torn Fun Pack", "Spawns 2x {{funcard}} Fun Cards on pick up (:#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	--Add spectral packs later
	-- VOUCHERS
	EID:addTrinket(BalatroJokers.Enums.Trinkets.torn_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.wasteful_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#{{ColorMint}}1 in 3 chance{{CR}} of despawning cards from Booster Packs to become a {{Coin}} Penny")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.tarot_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#{{ColorMint}}1 in 10 chance{{CR}} of despawning cards from Booster Packs to become a {{tarotcard}} Tarot Card")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.planet_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#{{ColorMint}}1 in 10 chance{{CR}} of despawning cards from Booster Packs to become a {{planetcard}} Planet Card")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.seed_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#Opening a Booster Pack also drops a random {{Coin}} Coin")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.directors_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a Booster Pack pack from chests#{{ColorMint}}1 in 10 chance{{CR}} of despawning cards from Booster Packs to become a {{dshard}} Dice Shard")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.hone_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#{{ColorMint}}1 in 4 chance{{CR}} to get jumbo or mega Booster Packs from {{BossRoom}} Bosses and {{MiniBoss}} Minibosses")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.overstock_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#Opening a Booster Pack drops 1-2 random pickups")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.magic_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#{{ColorMint}}1 in 4 chance{{CR}} buying a shop item spawns a {{deckpackt}} Torn Deck Pack")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.clearance_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#All Booster Packs are discounted in the shop")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.reroll_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#Spawns a reroll machine in the shop")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.hieroglyph_voucher, "{{ColorMint}}1 in 10 chance{{CR}} for the room clear reward to be a {{randompackthree}} Booster Pack#{{ColorMint}}1 in 3 chance{{CR}} for a bonus Booster Pack from chests#!!! Entering a {{BossRoom}} Boss Room with this voucher kills the boss, removes the item reward and destroys itself")
	-- MISC TRINKETS
	EID:addTrinket(BalatroJokers.Enums.Trinkets.card_house, "{{ColorMint}}1 in 4 chance{{CR}} to turn any dropped {{tarotcard}} Tarot Card, {{rune}} Rune or {{soulstone}} Soulstone into a {{bjokercard}} Joker Card")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.cheap_suit, "Triggers a random {{bjokercard}} Joker Card effect upon moving to a new floor")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.first_edition, "Entering a secret room will spawn 3x {{bjokercard}} Joker Cards on the ground#!!! Picking up one card removes other spawned cards#!!! Leaving the room despawns all spawned cards")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.stone_card, "Destroying tinted rocks have {{ColorMint}}1 in 3 chance{{CR}} to spawn a {{deckpackt}} Torn Deck Pack or a random {{randomvouchersingle}} Voucher#!!! Dropping this trinket will destroy it after it stays on the ground for a short time or when leaving the room")
	EID:addTrinket(BalatroJokers.Enums.Trinkets.double_stakes, "Each devil and angel deal room will have 2 random cards for sale#!!! Devil rooms require taking damage for the cards, angel rooms require money instead")
	-- ITEMS
	EID:addCollectible(BalatroJokers.Enums.Items.jimbos_collection, "Spawns 2x {{randomvouchersingle}} Vouchers, a {{randompackthree}} Booster Pack and a random pickup#{{ColorMint}}1 in 15 chance{{CR}} for champion enemies to drop a Booster Pack or a Voucher#Bosses drop a random {{bjokercard}} Joker Card or a Booster Pack#!!! All {{tarotcard}} / {{playingcard}} Cards sold in shops become Booster Packs", "Jimbo's Collection")
	--EID:addCollectible(jimbos_collection, "Spawns two vouchers, one Booster Pack and a random pickup#{{voucher}} {{ColorMint}}1 in 20 chance{{CR}} to turn other trinkets into vouchers#{{ColorMint}}1 in 15 chance{{CR}} for champion enemies to drop Booster Packs#!!! All cards sold in shops become Booster Packs", "Jimbo's Collection")
	--EID:addCollectible(jimbos_collection, "Spawns two vouchers, one Booster Pack and a random pickup#{{voucher}} {{ColorMint}}1 in 20 chance{{CR}} to turn other trinkets into vouchers#{{ColorMint}}1 in 15 chance{{CR}} for champion enemies to drop Booster Packs#{{packbonusglowing}} {{ColorMint}}1 in 5 chance{{CR}} of dropped Booster Packs being Jumbo or Mega variants#!!! All cards sold in shops become Booster Packs", "Jimbo's Collection")
	--Adds all voucher types to the trinket pool,
	-- PLANET CARDS
	EID:addCard(BalatroJokers.Enums.Planets.Pluto, "{{Collectible598}} Spawns a Pluto wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Pluto pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Mercury, "{{Collectible590}} Spawns a Mercurius wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Mercurius pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Uranus, "{{Collectible596}} Spawns a Uranus wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Uranus pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Venus, "{{Collectible591}} Spawns a Venus wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Venus pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Saturn, "{{Collectible595}} Spawns a Saturnus wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Saturnus pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Jupiter, "{{Collectible594}} Spawns a Jupiter wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Jupiter pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Earth, "{{Collectible592}} Spawns a Terra wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Terra pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Mars, "{{Collectible593}} Spawns a Mars wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Mars pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	EID:addCard(BalatroJokers.Enums.Planets.Neptune, "{{Collectible597}} Spawns a Neptunus wisp familiar#{{ColorMint}}1 in 10 chance{{CR}} to spawn the Neptunus pedestal item instead#!!! Item effect is lost if the wisp takes too much damage")
	-- DECK CARDS
	EID:addCard(BalatroJokers.Enums.Decks.RedDeck, "For this floor, last enemy in the room is instantly killed#{{ColorMint}}1 in 2 chance{{CR}} to remove the floor curse#Additional uses increase the enemy kill treshold")
	EID:addCard(BalatroJokers.Enums.Decks.BlueDeck, "{{Collectible245}} Gives the 20/20 item effect for the room#{{ColorMint}}1 in 2 chance{{CR}} to duplicate a pickup in the room")
	EID:addCard(BalatroJokers.Enums.Decks.YellowDeck, "Spawns 10 {{Coin}} Coins#{{ColorMint}}1 in 2 chance{{CR}} to spawn a money related pedestal item")
	EID:addCard(BalatroJokers.Enums.Decks.GreenDeck, "For this floor, clearing a room spawns a {{Coin}} Penny#{{ColorMint}}1 in 2 chance{{CR}} to double your coins after clearing the {{BossRoom}} Boss Room")
	EID:addCard(BalatroJokers.Enums.Decks.BlackDeck, "{{ColorMint}}1 in 2 chance{{CR}} to replace any pickup on the ground with a random {{bjokercard}} Joker Card#!!! Destroys the pickup if the conversion fails")
	-- JOKER CARDS
	EID:addCard(BalatroJokers.Enums.Jokers.BJoker, "↑ +0.7 Damage#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough", "Joker")
	EID:addCard(BalatroJokers.Enums.Jokers.GreedyJoker, "↑ +0.35 Damage for  the floor per each picked up {{Coin}} Coin#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.LustyJoker, "↑ +0.35 Damage for the floor per each picked up {{HalfHeart}} / {{HalfSoulHeart}} Half Heart#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.WrathfulJoker, "↑ +0.525 Damage for the floor for each picked up {{Key}} Key#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.GluttonousJoker, "↑ +0.525 Damage for the floor per each picked up {{Bomb}} Bomb#Additional uses increase current bonus#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.JollyJoker, "↑ +0.3 Damage for the room per every 2 enemies killed#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.WilyJoker, "↑ +0.2 Tears for the room per every 3 enemies killed#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.HalfJoker, "↑ +1.3 Damage if there are 3 or less enemies in the room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.JokerStencil, "↑ +0.4 Damage per charge when held active item is not fully charged#Doesn't work on timed charges#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Mime, "Triggers the held active item effect without depleting its charge#{{ColorMint}}1 in 3 chance{{CR}} to spawn another Mime card when used")
	EID:addCard(BalatroJokers.Enums.Jokers.MarbleJoker, "Entering a new room petrifies all enemies for a short time#Additional uses apply the effect again for the room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.EightBall, "{{ColorMint}}1 in 3 chance{{CR}} to spawn 8x {{tarotcard}} Tarot Cards#Additional {{ColorMint}}1 in 3 chance{{CR}} to spawn a {{Collectible451}} Tarot Cloth pedestal item")
	EID:addCard(BalatroJokers.Enums.Jokers.Misprint, "↑ +0-1.4 Random damage up when moving to a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.RaisedFist, "↑ +0.1 Damage multiplied by the lowest {{Bomb}} Bomb, {{Key}} Key or {{Coin}} Coin amount on entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Fibonacci, "↑ +2 Damage if all of the pickup amounts are either 1,2,3,5 or 8 when entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.ScaryFace, "↑ +0.03 Tears for each killed champion enemy#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Hack, "If there are 2,3,4 or 5 enemies in the room damage is shared between all of them#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.GrosMichel, "↑ +3 Damage while in the inventory#{{Warning}} 1/10  chance to randomly destroy itself upon room clear#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Supernova, "Turns all {{Bomb}} Bombs, {{Key}} Keys, {{Coin}} Coins and {{Heart}} Hearts turn into random {{planetcard}} Planet Cards#Pedestal items have a chance to turn into a planet item or a {{randompackthree}} Celestial Pack#+25% conversion chance for each quality level)")
	EID:addCard(BalatroJokers.Enums.Jokers.SpaceJoker, "Turns held trinkets and all trinkets on the ground to golden versions")
	EID:addCard(BalatroJokers.Enums.Jokers.Egg, "While in the inventory, each visited special room ({{Shop}} Shops, {{TreasureRoom}} Treasure Rooms etc.) adds 2 cents to its sell value#{{Shop}} Can be sold for a higher sell value by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Blackboard, "↑ x1.4 Damage multiplier if amount of held {{Bomb}} Bombs, {{Key}} Keys and {{Coin}} Coins are equal#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.BlueJoker, "Consumes all cards on the ground#↑ +0.15 Permanent tears up per card consumed")
	EID:addCard(BalatroJokers.Enums.Jokers.SquareJoker, "↑ +4 Tears when there are exactly 4 enemies in the room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.RiffRaff, "Spawns 2x {{bjokercard}} Joker Cards#As long as Riff-Raff remains in the inventory, this effect may trigger again if the current room is a {{BossRoom}} Boss, {{MiniBoss}} Miniboss or a {{BossRushRoom}} Boss Rush Room.#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Vampire, "↑ x0.005 Damage multiplier increase for each killed enemy#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Vagabond, "While in the inventory, if Isaac's {{Coin}} Coin amount is 3 or less, spawns a random {{tarotcard}} Tarot Card on entering a new hostile room and gives 3 cents#Using the card spawns a {{Coin}} Lucky Coin#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Rocket, "While in the inventory, adds +1 {{Coin}} Coin when clearing a room#Clearing a boss room increases the coin amount by +2#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Hologram, "↑ +4% damage multiplier increase for each used card(including itself)#{{Warning}} Mimicked or evoked card uses do not count#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	--Add more descriptions
	EID:addTrinket(BalatroJokers.Enums.Trinkets.Blank, "{{bjokercard}} Permanently grants 5 additional Joker inventory slots")
	--More jokers
	EID:addCard(BalatroJokers.Enums.Jokers.Baseball, "↑ x105% Damage mult per {{bjokercard}} Joker in inventory#Does not stack with itself#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Baron, "↑ Up to x130% Damage mult per held {{Quality4}} item#Each bonus becomes less potent with more items#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.FortuneTeller, "+0.07 Damage per used Major Arcana Card in current run#{{Collectible286}} Mimicked card effects also count#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.TurtleBean, "{{Collectible111}} Isaac farts#{{Collectible245}} Grants 5 copies of 20/20#!!! The multi-shot effect gradually wears off over 30 seconds")
	EID:addCard(BalatroJokers.Enums.Jokers.IceCream, "{{TearsSmall}} +2.5 Fire Rate#{{Freezing}} Grants ice tears for 10 seconds#{{Timer}} Fire rate bonus granted by this joker gradually fades over 30 seconds")
	--Spectral Packs
	EID:addEntity(5, BalatroJokers.Enums.Boosters.spectral, 1, "{{spectralpack}} Spectral Pack", "Spawns 2x {{spectralcard}} Spectral Cards on pickup#!!! Only one card can be chosen#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.spectral_medium, 1, "{{spectralpackmid}} Jumbo Spectral Pack", "Spawns 3x {{spectralcard}} Spectral Cards on pickup#!!! Only one card can be chosen#!!! Leaving the room despawns all spawned cards")
	EID:addEntity(5, BalatroJokers.Enums.Boosters.spectral_big, 1, "{{spectralpackbig}} Mega Spectral Pack", "Spawns 4x {{spectralcard}} Spectral Cards on pickup#!!! Only one card can be chosen#!!! Leaving the room despawns all spawned cards")
	--Spectral Cards
	EID:addCard(BalatroJokers.Enums.SpectralCards.Grim, "{{Warning}} {{ColorRed}}Removes a random item#Spawns 2 random {{Quality3}} items from random pools to choose from#!!! {{ColorRed}}Only its negative effects activate when mimicked")
	EID:addCard(BalatroJokers.Enums.SpectralCards.Cryptid, "{{Collectible347}} Grants two copies of a random passive item of the highest quality possible#{{Timer}} The effect wears off after 66.6 seconds#!!! This card can't be mimicked")
	EID:addCard(BalatroJokers.Enums.SpectralCards.Ouija, "{{Warning}} {{ColorRed}}+2{{BrokenHeart}} Broken hearts#{{Warning}} {{ColorRed}}Removes up to three different items of the highest quality possible# Spawns 3 copies of one of the removed items#!!! {{ColorRed}}Only its negative effects activate when mimicked")
	EID:addCard(BalatroJokers.Enums.SpectralCards.Wraith, "{{ColorRed}}↓ {{ColorRed}}-0.28 Tears#{{Warning}} {{ColorRed}}Sets money to 0 cents# Spawns a random {{Quality4}} item from a random pool#!!! {{ColorRed}}Only its negative effects activate when mimicked")
	EID:addCard(BalatroJokers.Enums.SpectralCards.Hex, "{{Warning}} {{ColorRed}}Destroys all {{bjokercard}} jokers in the inventory#{{Damage}} {{ColorRainbow}}Permanent x1.5 Damage Mult if at least 1 joker has been destroyed#!!! {{ColorRed}}Only its negative effects activate when mimicked")

	--Golden Trinkets
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.torn_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.wasteful_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.tarot_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.planet_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.seed_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.directors_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.hone_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.overstock_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.magic_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.clearance_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.reroll_voucher, "Effects duplicated, except the reroll machine spawns", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.hieroglyph_voucher, "All listed probabilities are doubled", numbersToMultiply, maxMultiplier, "en_us")
	EID:addGoldenTrinketMetadata(BalatroJokers.Enums.Trinkets.Blank, "Does not grant additional inventory slots", numbersToMultiply, maxMultiplier, "en_us")
	
	
EID:addCard(BalatroJokers.Enums.SpectralCards.TheSoul, "!!! Spawns a  {{bjokercard}}{{ColorYellow}}Legendary{{CR}} joker#!!! This card can't be {{Collectible286}}mimicked", "The Soul")
EID:addEntity(5, BalatroJokers.Enums.Legendaries.PERKEO, 1, "{{bjokercard}}{{ColorRainbow}} Perkeo","{{Shop}} Spawns a copy of your held consumable in special rooms#!!! {{bjokercard}} Jokers or certain types of cards won't be copied#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
EID:addEntity(5, BalatroJokers.Enums.Legendaries.CANIO, 1, "{{bjokercard}}{{ColorRainbow}} Canio","{{Warning}} Destroys all {{Collectible669}} \"love-related\" items while in the inventory#{{Damage}} Permanently grants +30% damage per destroyed item#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
--Referencing Canio's backstory of being cucked, and getting pissed at his wife and eventually stabbing his wife and the guy who fucked his wife. This is why his card depicts him as a sad pierrot instead of a smiling generic clown.
EID:addEntity(5, BalatroJokers.Enums.Legendaries.TRIBOULET, 1, "{{bjokercard}}{{ColorRainbow}} Triboulet", "↑ Grants up to x130% {{Tears}} Fire Rate mult per held {{Collectible472}} \"royal\" item or {{Collectible591}} \"female\" item#Each bonus becomes less potent with more items#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
--Triboulet's original effect references Victor Hugo's play about him, his hidden daughter Blanche, and King Francis I's bullshit. This is why Kings and Queens give mults in the original game.
EID:addEntity(5, BalatroJokers.Enums.Legendaries.CHICOT, 1, "{{bjokercard}}{{ColorRainbow}} Chicot","{{Weakness}} While in the inventory, all bosses are {{ColorMint}}permanently{{CR}} weakened#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
--Wish he was this good in Balatro....
EID:addEntity(5, BalatroJokers.Enums.Legendaries.YORICK, 1, "{{bjokercard}}{{ColorRainbow}} Yorick","{{Timer}} 2.3x Damage multiplier when the in-game timer exceeds 23 minutes#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
--That skull from Hamlet

--Valentines eve update jokers
	EID:addCard(BalatroJokers.Enums.Jokers.ShootTheMoon, "↑ +Up to 1.3 damage per held {{Collectible591}}\"female\" item#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Juggler, "↑ +1 consumable slot#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Splash, "Grants skipping tears#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Photo, "Once per room, taking damage briefly slows time#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.HangingChad, "Once per floor, retriggers whatever consumable Isaac uses twice more#On-damage effects trigger twice more#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Superposition, "#{{Shop}} Can be sold to make all choice pedestals to be freely taken by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.ChaosTheClown, "Spawns a Dice Shard inside shops#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Abstract, "+0.3 Damage per held {{bjokercard}} joker#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Madness, "!!! Immediately destroys a random item and activates {{Collectible704}} Berserk!#!!! Destroys a random passive item every floor but activates {{Collectible704}}Berserk! every room upon entering it for the first time#x150% damage mult when held")
	EID:addCard(BalatroJokers.Enums.Jokers.Pareidolia, "All enemies turn into champions when entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.SteelJoker, "{{Collectible617}} +16% chance per held metal item for each enemy to become magnetized upon entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.GoldenTicket, "{{Collectible202}} +8% chance per held golden item for each enemy to become briefly turned into gold statues upon entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.DNA, "+1 Minisaacs when entering a new room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.GlassJoker, "↑ +22.5% damage mult per held glass item#!!! Applies bleeding or adds a broken heart when hurt#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.DietCola, "#{{Shop}} Can be sold to clone the closest item pedestal by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.OopsAll6s, "All {{ColorMint}}chance-based effects from {{bjokercard}} jokers and vouchers{{CR}} are twice as likely to happen, {{ColorYellow}}including negative ones#Does not stack with itself#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Smeared, "Activates A Pound of Flesh if Isaac has no money#Bombs fire key tears in 8 directions when they explode#Isaac can spend keys to place bombs if he has no bombs#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Blueprint, "Acts as an invisible copy of the last picked up passive item#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Erosion, "↑ +0.25 damage per crushed rock in the room#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Wee, "{{TearsSmall}} +0.02 Fire Rate per every two enemy kills#↓ -50% size#{{Shop}} Can be sold by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	EID:addCard(BalatroJokers.Enums.Jokers.Brainstorm, "Copies the effect of the leftmost {{bjokercard}} joker#{{Warning}} Can't be sold, but instead can be dropped by pressing and holding the {{ButtonRT}} Ctrl key for long enough")
	
	EID:addCard(BalatroJokers.Enums.Decks.PlasmaDeck, "Balances all stats for the current floor")
	EID:addCard(BalatroJokers.Enums.Decks.AbandonedDeck, "For the current floor, turns champions into camouflaged champions that drop runes when they die")
	EID:addEntity(6, BalatroJokers.Enums.Slots.JIMBO_MACHINE, 0, "{{Slotmachine}} Booster Pack Vending Machine", "{{Coin}} Costs 7 cents to play#{{randompackthree}} Pays out with a random Booster Pack")

end

----------------------------------------- SET DIRECTIONS

BalatroJokers.Enums.CommonA = {
	Vector(2,-2),
	Vector(2.5,-2.5),
	Vector(3,-3.5),
}

BalatroJokers.Enums.CommonB = {
	Vector(-2,-2),
	Vector(-2.5,-2.5),	
	Vector(-3,-3),
}

BalatroJokers.Enums.CommonC = {
	Vector(0,2),
	Vector(0,2.5),
	Vector(0,3),
}

--

BalatroJokers.Enums.JumboA = {
	Vector(2,-2),
	Vector(2.5,-2.5),
	Vector(3,-3.5),
}

BalatroJokers.Enums.JumboB = {
	Vector(-2,-2),
	Vector(-2.5,-2.5),	
	Vector(-3,-3),
}

BalatroJokers.Enums.JumboC = {
	Vector(2,-2)*-1,
	Vector(2.5,-2.5)*-1,
	Vector(3,-3.5)*-1,
}

BalatroJokers.Enums.JumboD = {
	Vector(-2,-2)*-1,
	Vector(-2.5,-2.5)*-1,	
	Vector(-3,-3)*-1,
}

--

BalatroJokers.Enums.MegaA = {
	Vector(2,-2),
	Vector(2.5,-2.5),
	Vector(3,-3.5),
}

BalatroJokers.Enums.MegaB = {
	Vector(-2,-2),
	Vector(-2.5,-2.5),	
	Vector(-3,-3),
}

BalatroJokers.Enums.MegaC = {
	Vector(2.3,-2)*-1,
	Vector(2.8,-2.5)*-1,
	Vector(3.3,-3.5)*-1,
}

BalatroJokers.Enums.MegaD = {
	Vector(-2.3,-2)*-1,
	Vector(-2.8,-2.5)*-1,	
	Vector(-3.3,-3)*-1,
}

BalatroJokers.Enums.MegaE = {
	Vector(0,2),
	Vector(0,2.5),
	Vector(0,3),
}

----------------------------------------- LISTS
--[[
AllPacks = {
	standard_pack,
	standard_packj,
	standard_packm,
	arcana_pack,
	arcana_packj,
	arcana_packm,
	planet_pack,
	planet_packj,
	planet_packm,
	buffoon_pack,
	buffoon_packj,
	buffoon_packm,
}
]]
--We'll be using BalatroJokers.Enums.Boosters instead

BalatroJokers.Enums.WeightedBoosters = { --Replaces AllPacksWeighted global table (Just why...?)
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_packj,
	BalatroJokers.Enums.Boosters.standard_packj,
	BalatroJokers.Enums.Boosters.standard_packm,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_packj,
	BalatroJokers.Enums.Boosters.arcana_packj,
	BalatroJokers.Enums.Boosters.arcana_packm,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packm,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_packj,
	BalatroJokers.Enums.Boosters.buffoon_packj,
	BalatroJokers.Enums.Boosters.buffoon_packm,
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_pack,
	BalatroJokers.Enums.Boosters.standard_packj,
	BalatroJokers.Enums.Boosters.standard_packj,
	BalatroJokers.Enums.Boosters.standard_packm,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_pack,
	BalatroJokers.Enums.Boosters.arcana_packj,
	BalatroJokers.Enums.Boosters.arcana_packj,
	BalatroJokers.Enums.Boosters.arcana_packm,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packm,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_pack,
	BalatroJokers.Enums.Boosters.buffoon_packj,
	BalatroJokers.Enums.Boosters.buffoon_packj,
	BalatroJokers.Enums.Boosters.buffoon_packm,
	BalatroJokers.Enums.Boosters.spectral,
	BalatroJokers.Enums.Boosters.spectral,
	BalatroJokers.Enums.Boosters.spectral,	
	BalatroJokers.Enums.Boosters.spectral_medium,
	BalatroJokers.Enums.Boosters.spectral_medium,
	BalatroJokers.Enums.Boosters.spectral_big,
}

--[[
JimboPacks = {
	standard_packj,
	standard_packm,
	arcana_packj,
	arcana_packm,
	planet_packj,
	planet_packm,
	buffoon_packj,
	buffoon_packm,
}
]]

BalatroJokers.Enums.BigBoosters = { --Replaces JimboPacks table
	BalatroJokers.Enums.Boosters.standard_packj,
	BalatroJokers.Enums.Boosters.standard_packm,
	BalatroJokers.Enums.Boosters.arcana_packj,
	BalatroJokers.Enums.Boosters.arcana_packm,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packm,
	BalatroJokers.Enums.Boosters.buffoon_packj,
	BalatroJokers.Enums.Boosters.buffoon_packm,
}

BalatroJokers.Enums.PlanetPacks = { --Replaces CelestPacks table
	BalatroJokers.Enums.Boosters.planet_pack,
	BalatroJokers.Enums.Boosters.planet_packj,
	BalatroJokers.Enums.Boosters.planet_packm,
}

BalatroJokers.Enums.Vouchers = { --Replaces AllVouchers
	BalatroJokers.Enums.Trinkets.torn_voucher,
	BalatroJokers.Enums.Trinkets.wasteful_voucher,
	BalatroJokers.Enums.Trinkets.tarot_voucher,
	BalatroJokers.Enums.Trinkets.planet_voucher,
	BalatroJokers.Enums.Trinkets.seed_voucher,
	BalatroJokers.Enums.Trinkets.directors_voucher,
	BalatroJokers.Enums.Trinkets.hone_voucher,
	BalatroJokers.Enums.Trinkets.overstock_voucher,
	BalatroJokers.Enums.Trinkets.magic_voucher,
	BalatroJokers.Enums.Trinkets.clearance_voucher,
	BalatroJokers.Enums.Trinkets.reroll_voucher,
	BalatroJokers.Enums.Trinkets.hieroglyph_voucher,
}
--Do not add blank voucher here

BalatroJokers.Enums.SPVouchers = {
	BalatroJokers.Enums.Trinkets.wasteful_voucher,
	BalatroJokers.Enums.Trinkets.tarot_voucher,
	BalatroJokers.Enums.Trinkets.planet_voucher,
	BalatroJokers.Enums.Trinkets.seed_voucher,
	BalatroJokers.Enums.Trinkets.directors_voucher,
	BalatroJokers.Enums.Trinkets.hone_voucher,
	BalatroJokers.Enums.Trinkets.overstock_voucher,
	BalatroJokers.Enums.Trinkets.magic_voucher,
	BalatroJokers.Enums.Trinkets.clearance_voucher,
	BalatroJokers.Enums.Trinkets.reroll_voucher,
	BalatroJokers.Enums.Trinkets.hieroglyph_voucher,
}

BalatroJokers.Enums.PCards = {
	23,
	24,
	25,
	26,
	27,
	28,
	29,
	30,
	31,
	46,
	79,
}

BalatroJokers.Enums.PickupTypes = {
	10,
	20,
	30,
	40,
	69,
}

BalatroJokers.Enums.SeedCoins = {
	1,
	1,
	4,
	4,
	2,
	3,
	5,
	6,
	7,
}

--[[
DeckCards = {
	RedDeck,
	BlueDeck,
	YellowDeck,
	GreenDeck,
	BlackDeck,
}
]]
-- BalatroJokers.Enums.Decks

BalatroJokers.Enums.YellowDeckItems = {
	94, --sack of pennies
	380, --pay to play
	416, --deep pockets
	109, --money eq power
	18, --a dollar
	501, --greeds gullet
	74, --a quarter
	602, --members card
	202, --midas touch
	227, --piggy bank
	295, --magic fingers
	141, --pageant boy
	177, --portable slot
	429, --head of the keeper
	349, --wooden nickel
	450, --eye of greed
	455, --dads lost coin
	485, --crooked penny
	555, --golden razor
	376, --restock
	385, --bumbo
	521, --coupon
	144, --bum friend
}

BalatroJokers.InventoryBlacklisted = {
BalatroJokers.Enums.Jokers.Mime,
BalatroJokers.Enums.Jokers.EightBall,
--BalatroJokers.Enums.Jokers.GrosMichel,
BalatroJokers.Enums.Jokers.Supernova,
BalatroJokers.Enums.Jokers.SpaceJoker,
--BalatroJokers.Enums.Jokers.Egg, --Reason: Selling mechanic
BalatroJokers.Enums.Jokers.BlueJoker,
--BalatroJokers.Enums.Jokers.Vagabond,
--BalatroJokers.Enums.Jokers.Rocket,
--Add more jokers here
BalatroJokers.Enums.Jokers.IceCream,
BalatroJokers.Enums.Jokers.TurtleBean,
43
}

BalatroJokers.Enums.GlassItems = { --Used for Glass joker
313, 178, 691, 352, 474, 578, 436, 5, 245, 66, 422, 448, 337, 290, 434, 583, 685, 720, 730
}

BalatroJokers.Enums.SteelItems = { --Used for Steel joker
201, 449, 53, 114, 126, 186, 487, 569, 692, 486, 670, 708, 380, 74, 2, 172, 206, 255, 315, 617, 107, 325, 339, 359, 396, 455
}

BalatroJokers.Enums.GoldenItems = { --Used for Golden Ticket
602, 202, 429, 450, 555, 199, 732, 689, 691, 414, 387, 574, 546, 604
}

BalatroJokers.Enums.FemaleItemsEdgeCase = { --Used for Shoot The Moon & Triboulet
591, 303, 312, 707, 92, 407, 381, 226, 156, 417, 412, 413, 483, 67, 678
}

BalatroJokers.Enums.RoyalItems = { --Used for Triboulet
472, 577, 656, 689, 415, 442, 7, 691, 141, 181, 243, 202, 619, 625, 12, 
}

BalatroJokers.Enums.LewdItems = { --Used for Canio, the protagonist of the Pagliacci opera. He got cucked, and killed his wife and the guy who fucked her. No seriously.
671, 412, 413, 360, 417, 15, 9, 247, 669, 716, 393, 225, 165, 96, 122, 157, 193, 28, 256, 272, 276, 411, 447, 443, 498, 539, 565, 576,591, 678,697,541,223,546,732
}
--ONLY INCLUDE PASSIVE ITEMS HERE!

function BalatroJokers:IsSteelItem(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.SteelItems) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsGlassItem(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.GlassItems) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsGoldenItem(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.GoldenItems) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsRoyalItem(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.RoyalItems) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsLewdItem(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.LewdItems) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsFemaleItemEdgecase(itemid)

local valid = false

for _, value in pairs(BalatroJokers.Enums.FemaleItemsEdgeCase) do
    if value == itemid then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:GetLewdItems(player) --Misleading name. I had to change it a bit because otherwise Canio fucking sucks.
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true)
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and (BalatroJokers:IsLewdItem(i))  then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems

end

function BalatroJokers:GetFemaleItems(player)
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true)
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and (BalatroJokers:IsFemaleItemEdgecase(i) or item:HasTags(ItemConfig.TAG_MOM) ) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems

end

function BalatroJokers:GetSteelItems(player)
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true) 
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and BalatroJokers:IsSteelItem(i) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems

end

function BalatroJokers:GetGlassItems(player)
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if  not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true) 
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and BalatroJokers:IsGlassItem(i) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems

end

function BalatroJokers:GetGoldenItems(player)
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if  not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true) 
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and BalatroJokers:IsGoldenItem(i) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems

end

function BalatroJokers:GetRoyalItems(player)
local itemConfig = Isaac.GetItemConfig()
local starItems = 0

for i = 1, itemConfig:GetCollectibles().Size - 1 do
if  not BalatroJokers:Blacklist(i) then
    local item = itemConfig:GetCollectible(i)
    if item
	and player:HasCollectible(i, true) 
	and not item:HasTags(ItemConfig.TAG_QUEST)
	and not item.Hidden == true
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET) ~= i
	and player:GetActiveItem(ActiveSlot.SLOT_POCKET2) ~= i
	and BalatroJokers:IsRoyalItem(i) then
        starItems = starItems + player:GetCollectibleNum(i, true)
    end
end
end

return starItems + player:GetCollectibleNum(656, true) 

end

BalatroJokers.Enums.PRE_SELL_JOKER = {}

function BalatroJokers:HasJoker(EntityPlayer, JokerID)
    return BalatroJokers:GetJokerCount(EntityPlayer, JokerID) > 0
end

function BalatroJokers:AnyPlayerHasJoker(JokerID)
local bool = false
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		if BalatroJokers:HasJoker(player, JokerID) then
		bool = true
		end
	end
    return bool
end