local mod = BalatroJokers
local DSSModName = "Dead Sea Scrolls (Balatro Jokers)"

local dssCoreVersion = 7

local MenuProvider = {}

function MenuProvider.SaveSaveData()
    mod.SaveShitNow.GetDeadSeaScrollsSave()
end

function MenuProvider.GetPaletteSetting()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenuPalette
end

function MenuProvider.SavePaletteSetting(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenuPalette = var
end

function MenuProvider.GetHudOffsetSetting()
	if not REPENTANCE then
		return mod.SaveShitNow.GetDeadSeaScrollsSave().HudOffset
	else
		return Options.HUDOffset * 10
	end
end

function MenuProvider.SaveHudOffsetSetting(var)
	if not REPENTANCE then
		mod.SaveShitNow.GetDeadSeaScrollsSave().HudOffset = var
	end
end

function MenuProvider.GetGamepadToggleSetting()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().GamepadToggle
end

function MenuProvider.SaveGamepadToggleSetting(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().GamepadToggle = var
end

function MenuProvider.GetMenuKeybindSetting()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenuKeybind
end

function MenuProvider.SaveMenuKeybindSetting(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenuKeybind = var
end

function MenuProvider.GetMenuHintSetting()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenuHint
end

function MenuProvider.SaveMenuHintSetting(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenuHint = var
end

function MenuProvider.GetMenuBuzzerSetting()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenuBuzzer
end

function MenuProvider.SaveMenuBuzzerSetting(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenuBuzzer = var
end

function MenuProvider.GetMenusNotified()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenusNotified
end

function MenuProvider.SaveMenusNotified(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenusNotified = var
end

function MenuProvider.GetMenusPoppedUp()
	return mod.SaveShitNow.GetDeadSeaScrollsSave().MenusPoppedUp
end

function MenuProvider.SaveMenusPoppedUp(var)
	mod.SaveShitNow.GetDeadSeaScrollsSave().MenusPoppedUp = var
end

local DSSInitializerFunction = include("hamburger_helper.dssmenucore")
local dssMod = DSSInitializerFunction.init(DSSModName, MenuProvider)
--Not documented correctly; had to look at K&G instead

local directory = {}
directory.main = {
    title = "balatro jokers mod",
	buttons = {
	    {
            str = "resume game",
            action = "resume"
        }, --resume button
	    {
            str = "ui config",
            dest = "uiconfig"
        }, --UI button
		{
            str = "sell settings",
            dest = "sellconfig"
        }, --Sell config button
		{
            str = "sold joker desc",
            dest = "eidselldescconfig"
        }, --Sell config button		
		{
            str = "jimbo start",
            dest = "jimboconfig"
        }, --UI button
				{
            str = "machine config",
            dest = "machineconfig"
        }, --UI button
		dssMod.changelogsButton,
					},
	    tooltip = dssMod.menuOpenToolTip
}		

directory.jimboconfig = {
    title = "jimbo start",

    buttons = {
        {
            str = "starting room jimbo",
            choices = {"off", "on"},
            setting = 1,
            variable = "jimbostartswitch",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch or 1
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch = var
            end,

            tooltip = {strset = {"spawns a", "jimbo's","collection","if enabled"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}

directory.uiconfig = {
    title = "inventory ui",

    buttons = {
        {
            str = "joker inventory ui",
            choices = {"default", "high", "higher"},
            setting = 1,
            variable = "jimbouipos",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI or 1
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI = var
            end,

            tooltip = {strset = {"choose","inventory ui","position"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}

directory.jimboconfig = {
    title = "jimbo start",

    buttons = {
        {
            str = "starting room jimbo",
            choices = {"off", "on"},
            setting = 1,
            variable = "jimbostartswitch",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch or 1
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch = var
            end,

            tooltip = {strset = {"spawns a", "jimbo's","collection","in first room","if enabled"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}

directory.sellconfig = {
    title = "joker sell settings",

    buttons = {
        {
            str = "joker sell delay",
            choices = {"default", "faster", "slow"},
            setting = 1,
            variable = "selleped",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().SellSpeed or 1
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().SellSpeed = var
            end,

            tooltip = {strset = {"choose how", "quickly you'd","like to sell","jokers"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}

directory.eidselldescconfig = {
    title = "sold joker setting",

    buttons = {
        {
            str = "show description",
            choices = {"on", "off"},
            setting = 1,
            variable = "eidjimbodescsoldswitch",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().EIDSwitch or 1
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().EIDSwitch = var
            end,

            tooltip = {strset = {"display desc","before selling","requires eid"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}

directory.machineconfig = {
    title = "machine config",

    buttons = {
        {
            str = "replace rate",
            choices = {"never", "10%","20%","30%","40%","50%","60%","70%","80%","90%","always",},
            setting = 4,
            variable = "machineswapratejimbo",
            load = function ()
			--print("It's not our mod's fault! Apparently the restored Monsters pack uses global variables everywhere for some reason(like this mod's old version!).")
                return BalatroJokers.SaveShitNow.GetPersistentSave().MachineSwapRate or 4
            end,
            store = function (var)
                BalatroJokers.SaveShitNow.GetPersistentSave().MachineSwapRate = var
            end,

            tooltip = {strset = {"default: 30%"}}
        },
        dssMod.gamepadToggleButton,
        dssMod.menuKeybindButton,
        dssMod.paletteButton,
        dssMod.menuHintButton,
        dssMod.menuBuzzerButton,
    }
}


local directoryKey = {
    Item = directory.main, -- This is the initial item of the menu, generally you want to set it to your main item
    Main = 'main', -- The main item of the menu is the item that gets opened first when opening your mod's menu.

    -- These are default state variables for the menu; they're important to have in here, but you don't need to change them at all.
    Idle = false,
    MaskAlpha = 1,
    Settings = {},
    SettingsChanged = false,
    Path = {},
}

DeadSeaScrollsMenu.AddMenu("Balatro Jokers", {
    -- The Run, Close, and Open functions define the core loop of your menu
    -- Once your menu is opened, all the work is shifted off to your mod running these function
    -- This allows each mod to have its own independently functioning menu.

    -- The DSSInitializerFunction returns a table with defaults defined for each function
    -- These default functions are good enough for most mods
    -- If you do want a completely custom menu, making own functions is the way to do it
    
    -- This function runs every render frame while your menu is open
    -- It handles everything
    Run = dssMod.runMenu,

    -- This function runs when the menu is opened
    -- Generally it initializes the menu
    Open = dssMod.openMenu,

    -- This function runs when the menu is closed
    -- Generally it handles the storing of save data and general shutdown logic.
    Close = dssMod.closeMenu,

    -- This will hide your mod behind an "other mods" button if enabled
    -- It only activates if other mods with DSS are enabled
    -- It's a good idea to enable this if you don't expect players to use your menu often
    UseSubMenu = false,

    Directory = directory,
    DirectoryKey = directoryKey
})

--BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch == 2 means jimbo mode is on (1 means off)

function mod:JimboStart(isc)
if not isc then
if BalatroJokers.SaveShitNow.GetPersistentSave() and BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch and BalatroJokers.SaveShitNow.GetPersistentSave().JimboSwitch == 2 then
Isaac.ExecuteCommand("spawn 5.100."..BalatroJokers.Enums.Items.jimbos_collection)
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, mod.JimboStart)