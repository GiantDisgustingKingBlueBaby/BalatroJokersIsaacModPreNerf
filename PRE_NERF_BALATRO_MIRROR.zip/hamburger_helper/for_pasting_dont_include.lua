---Parameters: EntityPlayer, Integer
BalatroJokers:DestroyJoker(EntityPlayer, JokerSlotNum)
--Destroys the joker in the (JokerSlotNum)th joker slot.
--Automatically removes empty spaces between jokers.
--Returns nothing.

---Parameters: EntityPlayer
BalatroJokers:MaxValidSlot(EntityPlayer)
--Gets the highest slot number in the player's joker inventory.
--Returns an integer.

---Parameters: EntityPlayer, Integer
BalatroJokers:GetJokerCount(EntityPlayer, JokerID) 
--Gets number of Jokers in the player's inventory.
--Returns an integer.
--Most of the time, JokerID is the Joker's consumable ID, and thus, is an integer.
--Legendary Jokers use unique, static IDs. (2^20 + 0,~4)

---Parameters: EntityPlayer
BalatroJokers:RedeemedBlank(EntityPlayer)
--Return value: Boolean
--Returns true if the player entity has redeemed a Blank Voucher, and has access to 5 more joker slots.
--Returns nil otherwise.

---Parameters: CardType integer
BalatroJokers:IDRandomCard(CardType)
--Return type: Integer
--Returns a random consumable ID of the chosen CardType.
--Accepts BalatroJokers.Enums.CardGroup table entries as parameters.
--Currently supports suit, tarot, planets, jokers, special cards, decks, runes, soulstones, and reversed tarots.
--Legendary jokers aren't even entities, so you cannot spawn them.
--They can only be randomly granted as an effect from The Soul Spectral card.

---Parameters: Integer, Integer
BalatroJokers:RNGTwoParam(low, high)
--Return type: Integer
--Returns a seeded random value between low and high.
--Inclusive on both ends. Use this instead of "math.random(low, high)".

---Parameters: Integer, Integer
BalatroJokers:RNGOneParam(num)
--Return type: Integer
--Returns a seeded random value between 1 and num.
--Inclusive on both ends. Use this instead of "math.random(num)".
--!!! Max number is halved, then rounded (ceiling function) if any player has Oops! all 6s.

---Parameters: Position (Vector), Velocity (Vector), Card Type (Integer), Choiceindex (Optional, Integer)
BalatroJokers:SpawnRandomCard(Position, Velocity, CardType, Choiceindex)
--Return type: Doesn't return anything (void)
--Choiceindex is for simulating OptionsPickupIndex.
--It exists for the purpose of correctly displaying EID descriptions, and some vouchers.
--It also makes pickups despawn upon quitting or leaving the room.
--CardType is not to be confused with vanilla card type enums

---Parameters: EntityPlayer
BalatroJokers:GetRoyalItems(EntityPlayer)
BalatroJokers:GetGoldenItems(EntityPlayer)
BalatroJokers:GetGlassItems(EntityPlayer)
BalatroJokers:GetSteelItems(EntityPlayer)
BalatroJokers:GetFemaleItems(EntityPlayer)
--Return value: Integer
--Returns the number of "king", "golden", "glass", "steel", "queen" items held by the player.
--"Queen" is used for Shoot the Moon and Triboulet.
--"King" is used for Triboulet's Fire Rate mults.
--"Golden", "Steel", and "Glass" items are used for Golden Ticket, Steel Joker, and Glass Joker respectively.

---Parameters: CollectibleID (Integer)
BalatroJokers:IsLewdItem(CollectibleID)
--Return value: Boolean
--Returns true if this item belongs in the "lewd" item group and should be destroyed by Canio.

---Parameters: JokerID (Integer)
BalatroJokers:HasJoker(EntityPlayer, JokerID)
--Return value: Boolean
--Returns true if EntityPlayer has at least one joker of the specified ID.

---Parameters: EntityPlayer, TrinketID (Integer)
BalatroJokers:GulpSomething(EntityPlayer, TrinketID)
--Returns nothing.
--Self-explanatory.

---Parameters: EntityPlayer, SlotNum (Integer)
BalatroJokers:GetIDFromSlotNum(EntityPlayer, SlotNum) 
--Returns type: Integer
--Returns the Joker ID in the specified inventory slot.
--Returns nil if empty.

---Custom Callback
BalatroJokers.Enums.PRE_SELL_JOKER
--Function arguments: (EntityPlayer, JokerID)
--Optional arguments: None
--Return type: Doesn't return anything (void)

--Use it like this:
function BalatroJokers:PreSellCallbackTest(EntityPlayer, JokerID)
local name = "a"
if BalatroJokers:IsLegendaryJoker(JokerID) then
if JokerID == BalatroJokers.Enums.Legendaries.PERKEO then
name = "Perkeo"
elseif JokerID == BalatroJokers.Enums.Legendaries.CANIO then
name = "Canio"
elseif JokerID == BalatroJokers.Enums.Legendaries.CHICOT then
name = "Chicot"
elseif JokerID == BalatroJokers.Enums.Legendaries.TRIBOULET then
name = "Triboulet"
elseif JokerID == BalatroJokers.Enums.Legendaries.YORICK then
name = "Yorick"
end
else
if JokerID then
name = Isaac.GetItemConfig():GetCard(JokerID).Name
end
end
    print(EntityPlayer:GetName().." just sold "..name)
end
BalatroJokers:AddCallback(BalatroJokers.Enums.PRE_SELL_JOKER, BalatroJokers.PreSellCallbackTest)

--Prints "Azazel just sold Perkeo" when Azazel sells Perkeo (Not sure why the fuck would anyone do that... Is he stupid?)