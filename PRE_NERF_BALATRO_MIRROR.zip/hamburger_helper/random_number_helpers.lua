--Fuck off
local mod = BalatroJokers

BalatroJokers.PlayingCardEdgeCase = {
46, 79
}

function BalatroJokers:IsPlayingCard(joker_id)

local valid = false

for _, value in ipairs(BalatroJokers.PlayingCardEdgeCase) do
    if value == joker_id then
        valid = true --Man I miss TSIL
        break
    end
end


if valid or Isaac.GetItemConfig():GetCard(joker_id).CardType == ItemConfig.CARDTYPE_SUIT then
return true

else
return false
end

end

function BalatroJokers:IsSpecialCard(joker_id)

if Isaac.GetItemConfig():GetCard(joker_id).CardType == ItemConfig.CARDTYPE_SPECIAL
and Isaac.GetItemConfig():GetCard(joker_id):IsCard()
and not BalatroJokers:IsPlayingCard(joker_id)
and not mod:IsAnyJoker(joker_id)
and not (joker_id >= BalatroJokers.Enums.Decks.PlasmaDeck and joker_id <= BalatroJokers.Enums.Decks.BlackDeck)
and not (joker_id >= BalatroJokers.Enums.Planets.Pluto and joker_id <= BalatroJokers.Enums.Planets.Neptune)
and not mod:IsSpectralCard(joker_id)
then
return true

else
return false
end

end

function mod:RNGTwoParam(low, high)
local player = Isaac.GetPlayer()
return low + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(high+1 - low)
end

function mod:RNGOneParam(num)
local player = Isaac.GetPlayer()
local value =  player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(num) + 1


if BalatroJokers:AnyPlayerHasJoker(BalatroJokers.Enums.Jokers.OopsAll6s) == true then
value = math.ceil(value*0.5)
end


return value
end

function mod:CardTypeBoolean(joker_id, cardtype)
if cardtype == BalatroJokers.Enums.CardGroup.SUIT then --playing cards
return BalatroJokers:IsPlayingCard(joker_id)
elseif cardtype == BalatroJokers.Enums.CardGroup.PLANET then --planet cards
return joker_id >= BalatroJokers.Enums.Planets.Pluto and joker_id <= BalatroJokers.Enums.Planets.Neptune
elseif cardtype == BalatroJokers.Enums.CardGroup.TAROT then --Major Arcana (Vanilla)
return joker_id >= 1 and joker_id <= 22
elseif cardtype == BalatroJokers.Enums.CardGroup.TAROT_REVERSED then --Major Arcana (Reversed, vanilla)
return joker_id >= 56 and joker_id <= 77
elseif cardtype == BalatroJokers.Enums.CardGroup.JOKER then --buffoon packs
return mod:IsAnyJoker(joker_id)
elseif cardtype == BalatroJokers.Enums.CardGroup.RUNE then
return joker_id >= 32 and joker_id <= 41
elseif cardtype == BalatroJokers.Enums.CardGroup.SOUL then
return joker_id >= 81 and joker_id <= 97
elseif cardtype == BalatroJokers.Enums.CardGroup.SPECIAL then
return BalatroJokers:IsSpecialCard(joker_id)
elseif cardtype == BalatroJokers.Enums.CardGroup.DECK then
return (joker_id >= BalatroJokers.Enums.Decks.PlasmaDeck and joker_id <= BalatroJokers.Enums.Decks.BlackDeck)
elseif cardtype == BalatroJokers.Enums.CardGroup.SPECTRAL then
return BalatroJokers:IsSpectralCard(joker_id)
end
end

function mod:SpawnRandomCard(pos, vel, cardtype, choiceindex)
local randomcard = 0

if cardtype ~= BalatroJokers.Enums.CardGroup.SPECTRAL then

local itemConfig = Isaac.GetItemConfig()
local cardgroup = {}
for i = 1, itemConfig:GetCards().Size - 1 do
    local item = itemConfig:GetCard(i)
    if item and mod:CardTypeBoolean(i, cardtype)	
	then
        table.insert(cardgroup, i)
    end
end
randomcard = cardgroup[Isaac.GetPlayer():GetCollectibleRNG(678):RandomInt(#cardgroup) + 1]
else

randomcard = BalatroJokers.Enums.SpectralCardList[Isaac.GetPlayer():GetCollectibleRNG(678):RandomInt(#BalatroJokers.Enums.SpectralCardList) + 1]

end

local card = Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TAROTCARD, randomcard, pos, vel, nil):ToPickup()
card:AppearFast()
card:GetData().FAILSAFEBALATRO = true

if choiceindex then
--card.OptionsPickupIndex = choiceindex
card:GetData().ChooseIndex = choiceindex
card.Timeout = 8414750
end
end

function mod:IDRandomCard(cardtype)
local itemConfig = Isaac.GetItemConfig()
local cardgroup = {}
for i = 1, itemConfig:GetCards().Size - 1 do
    local item = itemConfig:GetCard(i)
    if item and mod:CardTypeBoolean(i, cardtype)	
	then
        table.insert(cardgroup, i)
    end
end
local randomcard = cardgroup[Isaac.GetPlayer():GetCollectibleRNG(678):RandomInt(#cardgroup) + 1]
return randomcard
end

function BalatroJokers:GulpSomething(player, trinket)
local firsttrinket = 0
local secondtrinket = 0

firsttrinket = player:GetTrinket(0)
secondtrinket = player:GetTrinket(1)

if firsttrinket ~= 0 and firsttrinket ~= trinket then
player:TryRemoveTrinket(firsttrinket)
end

if secondtrinket ~= 0 and secondtrinket ~= trinket then
player:TryRemoveTrinket(secondtrinket)
end

player:AddTrinket(trinket, false)
player:UseActiveItem(CollectibleType.COLLECTIBLE_SMELTER, UseFlag.USE_NOANIM)

if firsttrinket ~= 0 and firsttrinket ~= trinket then
player:AddTrinket(firsttrinket, false)
firsttrinket = 0
end
if secondtrinket ~= 0 and secondtrinket ~= trinket  then
player:AddTrinket(secondtrinket, false)
secondtrinket = 0
end

end
