local mod = BalatroJokers

local function JimboEffectUpdate(_, effect, collider) --hehehe im a super stah warriah
local sp = effect:GetSprite()
local anm = sp:GetAnimation()
	if (sp:IsFinished(anm)) then 
        effect:Remove()
	end --were gonna get rid of the effect here.
end	
mod:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, JimboEffectUpdate, BalatroJokers.Enums.Effects.Jimbo_Effect)

local function NopeEffectUpdate(_, effect, collider) --hehehe im a super stah warriah
local sp = effect:GetSprite()
local anm = sp:GetAnimation()
	if (sp:IsFinished(anm)) then 
        effect:Remove()
	end --were gonna get rid of the effect here.
end	
mod:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, JimboEffectUpdate, BalatroJokers.Enums.Effects.Nope_Effect)