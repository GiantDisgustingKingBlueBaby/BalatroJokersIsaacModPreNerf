local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()

function mod:UseRedDeckCard(card, player, useflags)
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()
		SFXManager():Play(BalatroJokers.Enums.SFX.RedCardSFX, 1, 0, false, 1)
		FloorData.IsRedDeckActive = true
		if BalatroJokers:RNGOneParam(2) == 1 then
				Game():GetLevel():RemoveCurses(LevelCurse.CURSE_OF_DARKNESS | LevelCurse.CURSE_OF_THE_LOST | LevelCurse.CURSE_OF_THE_UNKNOWN | LevelCurse.CURSE_OF_MAZE | LevelCurse.CURSE_OF_BLIND)
				SFXManager():Play(268, 0.6, 0, false, 1)
				player:AnimateHappy()
			end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseRedDeckCard, BalatroJokers.Enums.Decks.RedDeck)

function mod:RedDeckFunc(enemy)
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()
local RedDeckActive = FloorData.IsRedDeckActive
		if RedDeckActive and Isaac.CountEnemies() <= 1 and Isaac.CountBosses() == 0 then
			if enemy:IsVulnerableEnemy() then
				enemy:Die()
				Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), nil)
				--SFXManager():Play(169, 0.8, 0, false, 0.8)
				SFXManager():Play(BalatroJokers.Enums.SFX.JimboSFX, 0.8, 0, false, Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5)*0.1 + 0.9)
			end
		end
	end
mod:AddCallback(ModCallbacks.MC_NPC_UPDATE, mod.RedDeckFunc)
--Modern problems require modern solutions

function mod:UseBlueDeckCard(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.BlueCardSFX, 1, 0, false, 1)
		player:GetEffects():AddCollectibleEffect(CollectibleType.COLLECTIBLE_20_20, false, 1)
		if BalatroJokers:RNGOneParam(2) == 1 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D1, false, false, true, false, -1, 0)
			SFXManager():Play(268, 0.6, 0, false, 1)
			player:AnimateHappy()
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseBlueDeckCard, BalatroJokers.Enums.Decks.BlueDeck)

-- for i = 1, 5 do ; BalatroJokers.HideShitNow:Add(Isaac.GetPlayer(), 245, 90 * i) ; end ; Isaac.GetPlayer():RemoveCostume(Isaac.GetItemConfig():GetCollectible(245))
--Turtle Bean test
-- for i = 1, 5 do ; BalatroJokers.HideShitNow:Add(player, 245, 90 * i) ; end ;  player:RemoveCostume(Isaac.GetItemConfig():GetCollectible(245))
--Turtle bean code

function mod:UsePissDeckCard(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.YellowCardSFX, 1, 0, false, 1)
		if BalatroJokers:RNGOneParam(2) == 1 then
		local YellowDeckItems = BalatroJokers.Enums.YellowDeckItems 
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, (YellowDeckItems[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#YellowDeckItems) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
			SFXManager():Play(268, 0.6, 0, false, 1)
			player:AnimateHappy()
		end
		for i = 1, 10 do
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UsePissDeckCard, BalatroJokers.Enums.Decks.YellowDeck)

function mod:UseGreenDeckCard(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.GreenCardSFX, 1, 0, false, 1)
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()
		FloorData.IsGreenDeckActive = true
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseGreenDeckCard, BalatroJokers.Enums.Decks.GreenDeck)

function mod:GreenDeckFunc()
local roomt = Game():GetRoom():GetType()
	local player = Isaac.GetPlayer()
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()
local GreenDeckActive = FloorData.IsGreenDeckActive
	if GreenDeckActive then
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		if roomt == RoomType.ROOM_BOSS then
			if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
				for i = 1, (player:GetNumCoins()-1) do
					Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,300),0,true,false), Vector(0,0), nil)
					SFXManager():Play (268, 0.6, 0, false, 1)
					player:AnimateHappy()
				end
				GreenDeckActive = nil
			end
		end
	end
end	
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.GreenDeckFunc)

function mod:UseBlackDeck(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.BlackCardSFX, 1, 0, false, 1)
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity.Type == EntityType.ENTITY_PICKUP and ((entity.Variant >= 10 and entity.Variant <= 40) or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300) then
				if BalatroJokers:RNGOneParam(2) == 1 then
					entity:ToPickup().Timeout = -1
					local AllJokers = BalatroJokers.AllJokers
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, (AllJokers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), true)
					Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
					player:AnimateHappy()
				else
					entity:Remove()
					Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Nope_Effect , 0, entity.Position, Vector(0, 0), player)
					--player:AnimateSad()
				end
			end
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseBlackDeck, BalatroJokers.Enums.Decks.BlackDeck)