local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()

function mod:UseJollyJoker(card, player, useflags) 

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.JollyJokerSFX, 1, 0, false, 1)
RPData.UsedJollyCount = RPData.UsedJollyCount and RPData.UsedJollyCount + 1 or 1 --UsedJokerAmount is not a Joker slot function; The mod had no Joker limits to begin with
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseJollyJoker, BalatroJokers.Enums.Jokers.JollyJoker)

function mod:UseWilyJoker(card, player, useflags) 

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.WilyJokerSFX, 1, 0, false, 1)
RPData.UsedWilyCount = RPData.UsedWilyCount and RPData.UsedWilyCount + 1 or 1 --UsedJokerAmount is not a Joker slot function; The mod had no Joker limits to begin with
player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseWilyJoker, BalatroJokers.Enums.Jokers.WilyJoker)

function mod:UseHalfJoker(card, player, useflags) 

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.HalfJokerSFX, 1, 0, false, 1)
RPData.UsedHalfCount = RPData.UsedHalfCount and RPData.UsedHalfCount + 1 or 1 --UsedJokerAmount is not a Joker slot function; The mod had no Joker limits to begin with
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseHalfJoker, BalatroJokers.Enums.Jokers.HalfJoker)

function mod:CountKills(enemy)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if enemy:IsEnemy() then
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	 BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom = BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom and BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom + 1 or 1
	 
	 if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.JollyJoker) > 0 and BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom % 2 == 0 and BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom > 0 then
	 player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	 Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
	 			--Isaac.ExecuteCommand("playsfx 274")
			Isaac.ExecuteCommand("playsfx 491")
	 player:EvaluateItems()
	 end
	 if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.WilyJoker) > 0 and BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom%3 == 0 and BalatroJokers.SaveShitNow.GetRoomSave(player).KillsInRoom > 0 then
	 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
	 Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
	 			--Isaac.ExecuteCommand("playsfx 274")
			Isaac.ExecuteCommand("playsfx 491")
	 player:EvaluateItems()
	 end
	 --Wily and Jolly jokers
	 
	 if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Vampire) > 0 or mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Wee) > 0 then
	 RPData.KillsTotal = RPData.KillsTotal and RPData.KillsTotal + 1 or 1
	 player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
	 player:EvaluateItems()
	 --Vamp Joker
	 end
	 
	 if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.ScaryFace) > 0 and enemy:IsChampion() then
	 RPData.KillsTotalC = RPData.KillsTotalC and RPData.KillsTotalC + 1 or 1
	 Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
	 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
	 			--Isaac.ExecuteCommand("playsfx 274")
			Isaac.ExecuteCommand("playsfx 491")
	 player:EvaluateItems()
	 --Scaryface
	 end	 
	 
	end	
	end
end
mod:AddCallback(ModCallbacks.MC_POST_NPC_DEATH, mod.CountKills)

--Using Isaac.CountEnemies() directly to check Hack joker

local LastEnemyCount = Isaac.CountEnemies() 

function mod:PostEnemyCountChanged()

if LastEnemyCount ~= Isaac.CountEnemies() and not Game():GetRoom():IsClear() then
LastEnemyCount = Isaac.CountEnemies() 
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local RmData = BalatroJokers.SaveShitNow.GetRoomSave(player)
	
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.HalfJoker) > 0 then
	if LastEnemyCount <= 3 and LastEnemyCount > 0 then
	RmData.ShouldProcHalf = true
	 player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	 player:EvaluateItems()
	 else
	RmData.ShouldProcHalf = nil
	 player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
	 player:EvaluateItems()
	end
 end
 
 	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.SquareJoker) > 0 then
	if LastEnemyCount == 4 then
	RmData.ShouldProcSquare = true
	 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
	 player:EvaluateItems()
	 else
	RmData.ShouldProcSquare = nil
	 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
	 player:EvaluateItems()
	end
 end
 
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_UPDATE, mod.PostEnemyCountChanged)

