local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()

function mod:ForceEvalCacheStencil()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	if RPData.StencilCount then
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.ForceEvalCacheStencil)
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.ForceEvalCacheStencil)
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.ForceEvalCacheStencil)

function mod:UseStencilJoker(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.JokerStencilSFX, 1, 0, false, 1)
RPData.StencilCount = RPData.StencilCount and RPData.StencilCount+ 1 or 1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseStencilJoker, BalatroJokers.Enums.Jokers.JokerStencil)

function mod:UseMimeJoker(card, player, useflags)

		SFXManager():Play(BalatroJokers.Enums.SFX.MimeSFX, 1, 0, false, 1)
		if player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= 0 and player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= CollectibleType.COLLECTIBLE_BLANK_CARD then
			player:UseActiveItem(player:GetActiveItem(ActiveSlot.SLOT_PRIMARY), UseFlag.USE_NOANIM|UseFlag.USE_OWNED, ActiveSlot.SLOT_PRIMARY)
		end
		
		if player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) == CollectibleType.COLLECTIBLE_BLANK_CARD then --Funny synergy to make this thing differ from ? card
			player:UseActiveItem(CollectibleType.COLLECTIBLE_DATAMINER, UseFlag.USE_NOANIM)
			SFXManager():Play(SoundEffect.SOUND_EDEN_GLITCH, 1, 0, false, 1)
		end
		
		if BalatroJokers:RNGOneParam(3) == 1 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Jokers.Mime, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMimeJoker, BalatroJokers.Enums.Jokers.Mime)

function mod:UseMarbleJoker(card, player, useflags)

		SFXManager():Play(BalatroJokers.Enums.SFX.MarbleJokerSFX, 1, 0, false, 1)

			local entities = Isaac.GetRoomEntities()
			for i, entity in ipairs(entities) do
				if entity:IsVulnerableEnemy() then
				entity:AddFreeze(EntityRef(player), 30)
				end
			end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMarbleJoker, BalatroJokers.Enums.Jokers.MarbleJoker)

function mod:FreezeFoes()
for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		
		
if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.MarbleJoker) > 0 and not Game():GetRoom():IsClear() then
        for _, entity in pairs(Isaac.GetRoomEntities()) do
if entity:IsVulnerableEnemy() then
entity:AddFreeze(EntityRef(Isaac.GetPlayer()), 25*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.MarbleJoker))

end
end
end
end

end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.FreezeFoes)

function mod:UseEightJoker(card, player, useflags)

		SFXManager():Play(BalatroJokers.Enums.SFX.EightBallSFX, 1, 0, false, 1)
		
		if BalatroJokers:RNGOneParam(3) == 1 then
			for i = 1, 8 do
				Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22)+1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
			end
		end
		
		if BalatroJokers:RNGOneParam(3) == 1 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_TAROT_CLOTH, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
		
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseEightJoker, BalatroJokers.Enums.Jokers.EightBall)

function mod:UseFistJoker(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		SFXManager():Play(BalatroJokers.Enums.SFX.RaisedFistSFX, 1, 0, false, 1)
		RPData.UsedFist = RPData.UsedFist and RPData.UsedFist+ 1 or 1
		RPData.RaisedFistBonus = math.min(player:GetNumCoins(), player:GetNumBombs(), player:GetNumKeys())*0.1
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseFistJoker, BalatroJokers.Enums.Jokers.RaisedFist)

function mod:ReEvalFist()

	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		
if RPData.UsedFist then
RPData.RaisedFistBonus = math.min(player:GetNumCoins(), player:GetNumBombs(), player:GetNumKeys())*0.1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.ReEvalFist)

function mod:UseFibonacci(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		SFXManager():Play(BalatroJokers.Enums.SFX.FibonacciSFX, 1, 0, false, 1)
		RPData.UsedFibonacci = RPData.UsedFibonacci and RPData.UsedFibonacci+ 1 or 1
		
			if ((player:GetNumBombs() >= 1 and player:GetNumBombs() <= 3) or player:GetNumBombs() == 5 or player:GetNumBombs() == 8) and 
			((player:GetNumKeys() >= 1 and player:GetNumKeys() <= 3) or player:GetNumKeys() == 5 or player:GetNumKeys() == 8) and 
			((player:GetNumCoins() >= 1 and player:GetNumCoins() <= 3) or player:GetNumCoins() == 5 or player:GetNumCoins() == 8) then
			RPData.FibProc = 1
			else 
			RPData.FibProc = 0
			end
		
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseFibonacci, BalatroJokers.Enums.Jokers.Fibonacci)

function mod:ReEvalFibo()

	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		
if RPData.UsedFibonacci then
			if ((player:GetNumBombs() >= 1 and player:GetNumBombs() <= 3) or player:GetNumBombs() == 5 or player:GetNumBombs() == 8) and 
			((player:GetNumKeys() >= 1 and player:GetNumKeys() <= 3) or player:GetNumKeys() == 5 or player:GetNumKeys() == 8) and 
			((player:GetNumCoins() >= 1 and player:GetNumCoins() <= 3) or player:GetNumCoins() == 5 or player:GetNumCoins() == 8) then
			RPData.FibProc = 1
			else 
			RPData.FibProc = 0
			end
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.ReEvalFibo)

function mod:UseScaryFace(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		SFXManager():Play(BalatroJokers.Enums.SFX.ScaryFaceSFX, 1, 0, false, 1)
		RPData.UsedScary = RPData.UsedScary and RPData.UsedScary+ 1 or 1
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseScaryFace, BalatroJokers.Enums.Jokers.ScaryFace)

function mod:UseHack(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.HackSFX, 1, 0, false, 1)
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseHack, BalatroJokers.Enums.Jokers.Hack)

function mod:FTakeDamage2(enemy, amount, flags, source, countdown)
    if enemy.Type ~= EntityType.ENTITY_PLAYER
    then
        local player = nil
        if
            (source ~= nil
            and source.Entity ~= nil
            and source.Entity.SpawnerEntity ~= nil
            and source.Entity.SpawnerEntity.Type == EntityType.ENTITY_PLAYER )
        then
            player = source.Entity.SpawnerEntity:ToPlayer()
        elseif
            (source ~= nil
            and source.Type == EntityType.ENTITY_PLAYER)
        then
            player = source.Entity:ToPlayer()
        end
        if player and mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Hack) > 0 then
            -- do it
			
if Isaac.CountEnemies() <= 5 and Isaac.CountEnemies() >= 2 then
	

	
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity:IsVulnerableEnemy() and flags & DamageFlag.DAMAGE_CLONES == 0 and entity ~= enemy then
			entity:TakeDamage(amount,DamageFlag.DAMAGE_CLONES,EntityRef(player),0)
			Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, entity.Position, Vector(0, 0), player)
						Isaac.ExecuteCommand("playsfx 274")
			Isaac.ExecuteCommand("playsfx 491")
			--Insert toy piano sfx here
			end
		end

			
        end
    end
end
end
mod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, mod.FTakeDamage2)


function mod:UseBanana(card, player, useflags)
if useflags & UseFlag.USE_NOANIM == 0 then
SFXManager():Play(BalatroJokers.Enums.SFX.GrosMichelSFX, 1, 0, false, 1)
end

end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseBanana, BalatroJokers.Enums.Jokers.GrosMichel)

function mod:UseSupernova(card, player, useflags)
	SFXManager():Play(BalatroJokers.Enums.SFX.SupernovaSFX, 1, 0, false, 1)
		for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, -1, -1, false, false)) do
			if entity.Variant == PickupVariant.PICKUP_COLLECTIBLE and Isaac.GetItemConfig():GetCollectible(entity.SubType) and Isaac.GetItemConfig():GetCollectible(entity.SubType):HasTags(ItemConfig.TAG_QUEST) ~= true then
					local ItemQual = Isaac.GetItemConfig():GetCollectible(entity.SubType).Quality
				if BalatroJokers:RNGOneParam(10) <= math.ceil(ItemQual*2.5) then
				--math.random(588,598) should be now changed to include all planetarium items. Treat modded Planetarium items as Planet X lmao perhaps :troll:
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 100, 588+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11), true)
					Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
					player:AnimateHappy()
				else
					for i = 1, ItemQual do
						Isaac.Spawn(EntityType.ENTITY_PICKUP, (BalatroJokers.Enums.PlanetPacks[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.PlanetPacks) ]), 1, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
					end
					entity:Remove()
					player:AnimateHappy()
				end
			elseif entity.Variant == 10 or entity.Variant == 20 or entity.Variant == 30 or entity.Variant == 40 or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300 then
				entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), true)
				player:AnimateHappy()
			end
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseSupernova, BalatroJokers.Enums.Jokers.Supernova)

function mod:SeeYouSpaceJoker(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.SpaceJokerSFX, 1, 0, false, 1)
		local HeldTrinketA = player:GetTrinket(0)
		local HeldTrinketB = player:GetTrinket(1)
		for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, 350, -1, false, false)) do
			if entity.SubType < TrinketType.TRINKET_GOLDEN_FLAG then
				entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 350, entity.SubType + TrinketType.TRINKET_GOLDEN_FLAG, true, true)
				player:AnimateHappy()
			end
		end
		
			if HeldTrinketA ~= 0 and player:GetTrinket(0) < TrinketType.TRINKET_GOLDEN_FLAG then
			player:TryRemoveTrinket(HeldTrinketA)
			player:AddTrinket(HeldTrinketA | TrinketType.TRINKET_GOLDEN_FLAG)
			player:AnimateHappy()
		end
		if HeldTrinketB ~= 0 and player:GetTrinket(0) < TrinketType.TRINKET_GOLDEN_FLAG then
			player:TryRemoveTrinket(HeldTrinketB)
			player:AddTrinket(HeldTrinketB | TrinketType.TRINKET_GOLDEN_FLAG)
			player:AnimateHappy()
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.SeeYouSpaceJoker, BalatroJokers.Enums.Jokers.SpaceJoker)

function mod:UseEgg(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.EggSFX, 1, 0, false, 1)

end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseEgg, BalatroJokers.Enums.Jokers.Egg)

function mod:UseBlackBoard(card, player, useflags)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
SFXManager():Play(BalatroJokers.Enums.SFX.BlackboardSFX, 1, 0, false, 1)
		if player:GetNumKeys() == player:GetNumBombs() and player:GetNumKeys() == player:GetNumCoins() and 
		player:GetNumBombs() == player:GetNumKeys() and player:GetNumBombs() == player:GetNumCoins() then
		RPData.ShouldProcBBoard = 1
		else
		RPData.ShouldProcBBoard = 0
		end
		RPData.UsedBlackboard = RPData.UsedBlackboard and RPData.UsedBlackboard+ 1 or 1
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseBlackBoard, BalatroJokers.Enums.Jokers.Blackboard)			

function mod:ReEvalBBoard()

	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		
if RPData.UsedBlackboard then
		if player:GetNumKeys() == player:GetNumBombs() and player:GetNumKeys() == player:GetNumCoins() and 
		player:GetNumBombs() == player:GetNumKeys() and player:GetNumBombs() == player:GetNumCoins() then
		RPData.ShouldProcBBoard = 1
		else
		RPData.ShouldProcBBoard = 0
		end
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end

end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.ReEvalBBoard)

function mod:UseBlueJoker(card, player, useflags)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
SFXManager():Play(BalatroJokers.Enums.SFX.BlueJokerSFX, 1, 0, false, 1)
		if RPData.BlueAmount == nil then
			RPData.BlueAmount = 0
		end
		if RPData.BlueAmount >= 0 then
			for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, 300, -1, false, false)) do
				Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
				entity:Remove()
				RPData.BlueAmount = RPData.BlueAmount + 1
				player:AnimateHappy()
				player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
				player:EvaluateItems()
			end
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseBlueJoker, BalatroJokers.Enums.Jokers.BlueJoker)			

function mod:SoFuckingRetro(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.SquareJokerSFX, 1, 0, false, 1)
player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.SoFuckingRetro, BalatroJokers.Enums.Jokers.SquareJoker)

function mod:RiffRaffReworked(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.RiffRaffSFX, 1, 0, false, 1)

for i = 1, 2 do
local AllJokers = BalatroJokers.Enums.RiffRaffTable
Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (AllJokers[1+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers)]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
end

end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.RiffRaffReworked, BalatroJokers.Enums.Jokers.RiffRaff)
--Sounds too OP? Wait until you find out this thing now has an inventory limit. Fuck you.

function mod:HandleRiffRaff()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
    if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.RiffRaff) > 0 then
for i = 1, 2*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.RiffRaff) do
local AllJokers = BalatroJokers.Enums.RiffRaffTable
Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (AllJokers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.HandleRiffRaff)

function mod:SoFuckingVampire(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.VampireSFX, 1, 0, false, 1)
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.SoFuckingVampire, BalatroJokers.Enums.Jokers.Vampire)

function mod:GetAJobYouFuckingBum(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.VagabondSFX, 1, 0, false, 1)
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 5, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.GetAJobYouFuckingBum, BalatroJokers.Enums.Jokers.Vagabond)

function mod:VagabondUse()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	local Vagabond = BalatroJokers.Enums.Jokers.Vagabond
	
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Vagabond) > 0 and Isaac.CountEnemies() >= 1 and roomt ~= RoomType.ROOM_TREASURE and roomt ~= RoomType.ROOM_ERROR and roomt ~= RoomType.ROOM_SHOP and roomt ~= RoomType.ROOM_SECRET and roomt ~= RoomType.ROOM_SECRET_EXIT and roomt ~= RoomType.ROOM_LIBRARY and roomt ~= RoomType.ROOM_BLACK_MARKET and roomt ~= RoomType.ROOM_ULTRASECRET and roomt ~= RoomType.ROOM_DEVIL and roomt ~= RoomType.ROOM_ANGEL and roomt ~= RoomType.ROOM_DUNGEON then
		if player:GetNumCoins() <= 3 and room:IsFirstVisit() == true then
			BalatroJokers:SpawnRandomCard(player.Position, Vector.Zero, BalatroJokers.Enums.CardGroup.TAROT, nil)
			Isaac.GetPlayer():AddCoins(3)
		end
	end
	
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.VagabondUse)

function mod:RocketUp()
local RunData = BalatroJokers.SaveShitNow.GetRunSave()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	local Rocket = BalatroJokers.Enums.Jokers.Rocket
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	local RocketBonus = RunData.RocketBonus 
	
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Rocket) > 0 and roomt == RoomType.ROOM_BOSS then
		BalatroJokers.SaveShitNow.GetRunSave().RocketBonus = BalatroJokers.SaveShitNow.GetRunSave().RocketBonus and BalatroJokers.SaveShitNow.GetRunSave().RocketBonus + 2 or 2
	if RunData.RocketBonus then
		player:AddCoins(RunData.RocketBonus* mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Rocket))
		SFXManager():Play(234, 0.6, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
		end
		SFXManager():Play(274, 1, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
	elseif mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Rocket) > 0 then --room:IsFirstVisit() == true
	if RunData.RocketBonus then
		player:AddCoins(RunData.RocketBonus* mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Rocket))
		SFXManager():Play(234, 0.6, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
		end
	end
	
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Rocket) > 0 then
	player:AddCoins(1)
	SFXManager():Play(234, 0.6, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.RocketUp)

function mod:RocketDown(card, player, useflags)
		SFXManager():Play(BalatroJokers.Enums.SFX.RocketSFX, 1, 0, false, 1)
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.RocketDown, BalatroJokers.Enums.Jokers.Rocket)

function mod:SoFuckingHologram(card, player, useflags)
SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.SoFuckingHologram, BalatroJokers.Enums.Jokers.Hologram)

function mod:UseCardBonus22(card, player, useflags)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Hologram) > 0 then
	if Isaac.GetItemConfig():GetCard(card):IsCard() == true then
		RPData.HoloBonusArc = RPData.HoloBonusArc and RPData.HoloBonusArc+1 or 1
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
		end
	end
end
end

mod:AddPriorityCallback(
    ModCallbacks.MC_USE_CARD,
   CallbackPriority.LATE + 999999,
   mod.UseCardBonus22
)

function mod:CockAndBallsJokers()
local GrosMichel = BalatroJokers.Enums.Jokers.GrosMichel
local Egg = BalatroJokers.Enums.Jokers.Egg
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
		
	if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Egg) > 0 and room:IsFirstVisit() == true and (roomt ~= RoomType.ROOM_DEFAULT and roomt ~= RoomType.ROOM_DUNGEON and roomt ~= RoomType.ROOM_GREED_EXIT and roomt ~= RoomType.ROOM_SECRET_EXIT) then	
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	RPData.EggValue = RPData.EggValue and RPData.EggValue + 2*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Egg) or 2*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Egg)
	end
		
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:EvaluateItems()

end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.CockAndBallsJokers)

function mod:GrosMichelDisappear(rng)
local GrosMichel = BalatroJokers.Enums.Jokers.GrosMichel
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)

for i = 1, BalatroJokers:MaxValidSlot(player) do
				--Bye Banana man
if BalatroJokers:GetIDFromSlotNum(player, i) == GrosMichel then
		local groschance = 0
		if player:HasCollectible(CollectibleType.COLLECTIBLE_TAROT_CLOTH) == true then
			groschance = BalatroJokers:RNGOneParam(20)
		else
			groschance = BalatroJokers:RNGOneParam(10)
		end
if groschance == 5 then
Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.BLOOD_SPLAT, 0, player.Position, Vector(0, 0), player):ToEffect():SetColor(Color(0.85,0.75,0.05,0.35,0.85,0.75,0.05,0.25),0,1,false,false)
BalatroJokers:DestroyJoker(player, i)
Game():GetHUD():ShowItemText("Extinct!", "", false)
player:AnimateSad()
else
Game():GetHUD():ShowItemText("Safe!", "", false)
end
		
end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.GrosMichelDisappear)