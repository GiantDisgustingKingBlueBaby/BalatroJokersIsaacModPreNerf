local mod = BalatroJokers

function mod:UsePluto(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.PlutoSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_PLUTO, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_PLUTO, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UsePluto, BalatroJokers.Enums.Planets.Pluto)

function mod:UseMercury(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.MercurySFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_MERCURIUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_MERCURIUS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMercury, BalatroJokers.Enums.Planets.Mercury)

function mod:UseVenus(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.VenusSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_VENUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_VENUS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseVenus, BalatroJokers.Enums.Planets.Venus)

function mod:UseEarth(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.EarthSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_TERRA, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_TERRA, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseEarth, BalatroJokers.Enums.Planets.Earth)

function mod:UseMars(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.MarsSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_MARS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_MARS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMars, BalatroJokers.Enums.Planets.Mars)

function mod:UseJupiter(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.JupiterSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_JUPITER, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_JUPITER, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseJupiter, BalatroJokers.Enums.Planets.Jupiter)

function mod:UseSaturn(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.SaturnSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_SATURNUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_SATURNUS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseSaturn, BalatroJokers.Enums.Planets.Saturn)

function mod:UseUranus(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.UranusSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_URANUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_URANUS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseUranus, BalatroJokers.Enums.Planets.Uranus)

function mod:UseNeptune(card, player, useflags)
	local ChancePlanetariumItem = BalatroJokers:RNGOneParam(11)
SFXManager():Play(BalatroJokers.Enums.SFX.NeptuneSFX, 1, 0, false, 1)
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_NEPTUNUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_NEPTUNUS, player.Position, false) 
		end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseNeptune, BalatroJokers.Enums.Planets.Neptune)