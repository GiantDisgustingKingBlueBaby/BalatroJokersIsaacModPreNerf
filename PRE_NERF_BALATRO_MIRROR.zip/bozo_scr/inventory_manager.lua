
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()

function BalatroJokers:IsAnyJoker(joker_id)

local valid = false

for _, value in ipairs(BalatroJokers.AllJokers) do --Legends are excluded for obvious reasons
    if value == joker_id then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsLegendaryJoker(joker_id)

local valid = false
for _, v in ipairs(BalatroJokers.Enums.LegendariesList) do
    if v == joker_id then
        valid = true 
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:IsValidJoker(joker_id)

local valid = false

for _, value in ipairs(BalatroJokers.AllJokers) do
    if value == joker_id then
        valid = true --Man I miss TSIL
        break
    end
end

for _, value2 in ipairs(BalatroJokers.InventoryBlacklisted) do
    if value2 == joker_id then
        valid = false --Man I miss TSIL
        break
    end
end

for _, value3 in ipairs(BalatroJokers.Enums.LegendariesList) do
    if value3 == joker_id then
        valid = true 
        break
    end
end

if valid then
return true

else
return false
end

end

function BalatroJokers:RefreshJokerInventory(player, joker_id) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

if BalatroJokers:IsValidJoker(joker_id) then

--Remove empty slots

if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
RPData.S15 = RPData.S14
RPData.S14 = RPData.S13
RPData.S13 = RPData.S12
RPData.S12 = RPData.S11
RPData.S11 = RPData.S10
end

RPData.S10 = RPData.S9
RPData.S9 = RPData.S8
RPData.S8 = RPData.S7
RPData.S7 = RPData.S6
RPData.S6 = RPData.S5
RPData.S5 = RPData.S4
RPData.S4 = RPData.S3
RPData.S3 = RPData.S2
RPData.S2 = RPData.S1

RPData.S1 = joker_id

--Overwrite old jokers

end
end

function BalatroJokers:GetLatestNilSlot(player) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local slot = 1

if RPData.S1 then
slot = slot + 1
else return slot
end
if RPData.S2 then
slot = slot + 1
else return slot
end
if RPData.S3 then
slot = slot + 1
else return slot
end
if RPData.S4 then
slot = slot + 1
else return slot
end
if RPData.S5 then
slot = slot + 1
else return slot
end
if RPData.S6 then
slot = slot + 1
else return slot
end
if RPData.S7 then
slot = slot + 1
else return slot
end
if RPData.S8 then
slot = slot + 1
else return slot
end
if RPData.S9 then
slot = slot + 1
else return slot
end
if RPData.S10 then
slot = slot + 1
else return slot
end

if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
if RPData.S11 then
slot = slot + 1
else return slot
end
if RPData.S12 then
slot = slot + 1
else return slot
end
if RPData.S13 then
slot = slot + 1
else return slot
end
if RPData.S14 then
slot = slot + 1
else return slot
end
if RPData.S15 then
slot = slot + 1
else return slot
end
end


return slot
end

function BalatroJokers:MaxValidSlot(player)
return BalatroJokers:GetLatestNilSlot(player) - 1
end

function BalatroJokers:IsNilSlot(player, oldslot) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

local replacevalue = nil

if oldslot == 1 then
replacevalue = RPData.S1
elseif oldslot == 2 then
replacevalue = RPData.S2
elseif oldslot == 3 then
replacevalue = RPData.S3
elseif oldslot == 4 then
replacevalue = RPData.S4
elseif oldslot == 5 then
replacevalue = RPData.S5
elseif oldslot == 6 then
replacevalue = RPData.S6
elseif oldslot == 7 then
replacevalue = RPData.S7
elseif oldslot == 8 then
replacevalue = RPData.S8
elseif oldslot == 9 then
replacevalue = RPData.S9
elseif oldslot == 10 then
replacevalue = RPData.S10
elseif oldslot == 11 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S11
elseif oldslot == 12 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S12
elseif oldslot == 13 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S13
elseif oldslot == 14 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S14
elseif oldslot == 15 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S15
end

if replacevalue then
return false
else
return true
end 

end

--l print(BalatroJokers:GetLatestNilSlot(Isaac.GetPlayer()))
--l BalatroJokers:MoveJoker(Isaac.GetPlayer(),  10,  1)

--Parameters: EntityPlayer, Player's Old
function BalatroJokers:MoveJoker(player, oldslot, newslot)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

local replacevalue = 1

if oldslot == 1 then
replacevalue = RPData.S1
elseif oldslot == 2 then
replacevalue = RPData.S2
elseif oldslot == 3 then
replacevalue = RPData.S3
elseif oldslot == 4 then
replacevalue = RPData.S4
elseif oldslot == 5 then
replacevalue = RPData.S5
elseif oldslot == 6 then
replacevalue = RPData.S6
elseif oldslot == 7 then
replacevalue = RPData.S7
elseif oldslot == 8 then
replacevalue = RPData.S8
elseif oldslot == 9 then
replacevalue = RPData.S9
elseif oldslot == 10 then
replacevalue = RPData.S10
elseif oldslot == 11 then
replacevalue = RPData.S11
elseif oldslot == 12 then
replacevalue = RPData.S12
elseif oldslot == 13 then
replacevalue = RPData.S13
elseif oldslot == 14 then
replacevalue = RPData.S14
elseif oldslot == 15 then
replacevalue = RPData.S15
end

if newslot == 1 then
RPData.S1 = replacevalue
elseif newslot == 2 then
RPData.S2 = replacevalue
elseif newslot == 3 then
RPData.S3 = replacevalue
elseif newslot == 4 then
RPData.S4 = replacevalue
elseif newslot == 5 then
RPData.S5 = replacevalue
elseif newslot == 6 then
RPData.S6 = replacevalue
elseif newslot == 7 then
RPData.S7 = replacevalue
elseif newslot == 8 then
RPData.S8 = replacevalue
elseif newslot == 9 then
RPData.S9 = replacevalue
elseif newslot == 10 then
RPData.S10 = replacevalue
elseif newslot == 11 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
RPData.S11 = replacevalue
elseif newslot == 12 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
RPData.S12 = replacevalue
elseif newslot == 13 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
RPData.S13 = replacevalue
elseif newslot == 14 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
RPData.S14 = replacevalue
elseif newslot == 15 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
RPData.S15 = replacevalue
end

if oldslot == 1 then
RPData.S1 = nil
elseif oldslot == 2 then
RPData.S2 = nil
elseif oldslot == 3 then
RPData.S3 = nil
elseif oldslot == 4 then
RPData.S4 = nil
elseif oldslot == 5 then
RPData.S5 = nil
elseif oldslot == 6 then
RPData.S6 = nil
elseif oldslot == 7 then
RPData.S7 = nil
elseif oldslot == 8 then
RPData.S8 = nil
elseif oldslot == 9 then
RPData.S9 = nil
elseif oldslot == 10 then
RPData.S10 = nil
elseif oldslot == 11 then
RPData.S11 = nil
elseif oldslot == 12 then
RPData.S12 = nil
elseif oldslot == 13 then
RPData.S13 = nil
elseif oldslot == 14 then
RPData.S14 = nil
elseif oldslot == 15 then
RPData.S15 = nil
end

end

--l BalatroJokers:DestroyJoker(Isaac.GetPlayer(), n)

function BalatroJokers:DestroyJoker(player, oldslot)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

if oldslot == 1 then
RPData.S1 = nil
elseif oldslot == 2 then
RPData.S2 = nil
elseif oldslot == 3 then
RPData.S3 = nil
elseif oldslot == 4 then
RPData.S4 = nil
elseif oldslot == 5 then
RPData.S5 = nil
elseif oldslot == 6 then
RPData.S6 = nil
elseif oldslot == 7 then
RPData.S7 = nil
elseif oldslot == 8 then
RPData.S8 = nil
elseif oldslot == 9 then
RPData.S9 = nil
elseif oldslot == 10 then
RPData.S10 = nil
elseif oldslot == 11 then
RPData.S11 = nil
elseif oldslot == 12 then
RPData.S12 = nil
elseif oldslot == 13 then
RPData.S13 = nil
elseif oldslot == 14 then
RPData.S14 = nil
elseif oldslot == 15 then
RPData.S15 = nil
end

local num = 10

if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
num = 15
else
num = 10
end

for i = 1, num do
if not BalatroJokers:IsNilSlot(player, i)  then
BalatroJokers:MoveJoker(player, i, BalatroJokers:GetLatestNilSlot(player) )
end
end
player:AddCacheFlags(CacheFlag.CACHE_ALL)
player:EvaluateItems()

end

function BalatroJokers:PreUseJokerInventoryRefresh(joker_id, player, useflags)
if BalatroJokers:IsValidJoker(joker_id) == true then
if (useflags & UseFlag.USE_NOANIM == 0) and (useflags & UseFlag.USE_MIMIC == 0) then
BalatroJokers:RefreshJokerInventory(player, joker_id) 
player:AddCacheFlags(CacheFlag.CACHE_ALL)
player:EvaluateItems()
end
end
end
BalatroJokers:AddPriorityCallback(
    ModCallbacks.MC_USE_CARD,
   CallbackPriority.EARLY, --Reason: Poly
   BalatroJokers.PreUseJokerInventoryRefresh
)

function BalatroJokers:GetBrainstormJokerCount(player) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local count = 0

if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
if RPData.S15 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S14 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S13 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S12 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S11 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
end


if RPData.S10 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S9 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S8 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S7 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S6 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S5 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S4 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S3 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S2 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end
if RPData.S1 == BalatroJokers.Enums.Jokers.Brainstorm then
count = count + 1
end

return count

end


function BalatroJokers:GetJokerCount(player, joker_id) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local count = 0

if BalatroJokers:IsValidJoker(joker_id) == true then


if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
if RPData.S15 == joker_id then
count = count + 1
end
if RPData.S14 == joker_id then
count = count + 1
end
if RPData.S13 == joker_id then
count = count + 1
end
if RPData.S12 == joker_id then
count = count + 1
end
if RPData.S11 == joker_id then
count = count + 1
end
end


if RPData.S10 == joker_id then
count = count + 1
end
if RPData.S9 == joker_id then
count = count + 1
end
if RPData.S8 == joker_id then
count = count + 1
end
if RPData.S7 == joker_id then
count = count + 1
end
if RPData.S6 == joker_id then
count = count + 1
end
if RPData.S5 == joker_id then
count = count + 1
end
if RPData.S4 == joker_id then
count = count + 1
end
if RPData.S3 == joker_id then
count = count + 1
end
if RPData.S2 == joker_id then
count = count + 1
end
if RPData.S1 == joker_id then
count = count + 1
end

if BalatroJokers:GetBrainstormJokerCount(player)  > 0 and BalatroJokers:GetIDFromSlotNum(player, BalatroJokers:MaxValidSlot(player)) == joker_id then
count = count + BalatroJokers:GetBrainstormJokerCount(player) 
end

return count

else
print("Error: Attempt to fetch an invalid consumable's Joker inventory data!")

return 0
end
end

function BalatroJokers:RenderCards()
local JokerHUD = Sprite()
local PersData = BalatroJokers.SaveShitNow.GetPersistentSave()	

local persx = 55
local persy = 225

if BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI then
if BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI == 1 then
persx = 55
persy = 225
elseif BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI == 2 then
persx = 55
persy = 155
elseif BalatroJokers.SaveShitNow.GetPersistentSave().JimboUI == 3 then
persx = 55
persy = 65
end
end

JokerHUD:Load("gfx/ui/cardfronts.anm2", true)
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)	
if RPData and PersData then		


if BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
if RPData.S15 then
if BalatroJokers:IsLegendaryJoker(RPData.S15) then
JokerHUD:SetFrame("leg", RPData.S15 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S15 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 15 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx,persy + 12*playerNum), Vector.Zero, Vector.Zero)
end
if RPData.S14 then
if BalatroJokers:IsLegendaryJoker(RPData.S14) then
JokerHUD:SetFrame("leg", RPData.S14 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S14 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 14 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+3,persy + 12*playerNum), Vector.Zero, Vector.Zero)
end
if RPData.S13 then
if BalatroJokers:IsLegendaryJoker(RPData.S13) then
JokerHUD:SetFrame("leg", RPData.S13 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S13 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 13 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+6,persy + 12*playerNum), Vector.Zero, Vector.Zero)
end
if RPData.S12 then
if BalatroJokers:IsLegendaryJoker(RPData.S12) then
JokerHUD:SetFrame("leg", RPData.S12 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S12 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 12 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+9,persy + 12*playerNum), Vector.Zero, Vector.Zero)
end
if RPData.S11 then
if BalatroJokers:IsLegendaryJoker(RPData.S11) then
JokerHUD:SetFrame("leg", RPData.S11 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S11 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 11 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+12,persy + 12*playerNum), Vector.Zero, Vector.Zero)
end
end


		if RPData.S10 then
if BalatroJokers:IsLegendaryJoker(RPData.S10) then
JokerHUD:SetFrame("leg", RPData.S10 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S10 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 10 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+15,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end	
		
		if RPData.S9 then
if BalatroJokers:IsLegendaryJoker(RPData.S9) then
JokerHUD:SetFrame("leg", RPData.S9 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S9 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 9 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+18,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end		
		
		if RPData.S8 then
if BalatroJokers:IsLegendaryJoker(RPData.S8) then
JokerHUD:SetFrame("leg", RPData.S8 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S8 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 8 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+21,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end			

		if RPData.S7 then
if BalatroJokers:IsLegendaryJoker(RPData.S7) then
JokerHUD:SetFrame("leg", RPData.S7 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S7- BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 7 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+24,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end			

		if RPData.S6 then
if BalatroJokers:IsLegendaryJoker(RPData.S6) then
JokerHUD:SetFrame("leg", RPData.S6 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S6 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 6 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+27,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end			

		if RPData.S5 then
if BalatroJokers:IsLegendaryJoker(RPData.S5) then
JokerHUD:SetFrame("leg", RPData.S5 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S5 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 5 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+30,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end			

		if RPData.S4 then
if BalatroJokers:IsLegendaryJoker(RPData.S4) then
JokerHUD:SetFrame("leg", RPData.S4 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S4- BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 4 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+33,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end		

		if RPData.S3 then
if BalatroJokers:IsLegendaryJoker(RPData.S3) then
JokerHUD:SetFrame("leg", RPData.S3 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S3 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 3 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+36,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end

		if RPData.S2 then
if BalatroJokers:IsLegendaryJoker(RPData.S2) then
JokerHUD:SetFrame("leg", RPData.S2 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S2 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 2 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+39,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end
		
			if RPData.S1 then
if BalatroJokers:IsLegendaryJoker(RPData.S1) then
JokerHUD:SetFrame("leg", RPData.S1 - BalatroJokers.Enums.Legendaries.PERKEO )
else
JokerHUD:SetFrame("1", RPData.S1 - BalatroJokers.Enums.Jokers.BJoker )
end
	  JokerHUD.Scale = Vector(0.5,0.5)
	  if (PersData.SellMechanic == true or PersData.SellMechanic == nil) and Input.IsActionPressed(ButtonAction.ACTION_DROP, player.ControllerIndex) and RPData.SellJokerSlot == 1 then
JokerHUD.Color=Color(1,1,0,1,0.5,0.5,0)
else
JokerHUD.Color=Color(1,1,1,1)
end
JokerHUD:Render(Vector(persx+42,persy + 12*playerNum), Vector.Zero, Vector.Zero)
		end

end
end
end	
BalatroJokers:AddCallback(ModCallbacks.MC_POST_RENDER, BalatroJokers.RenderCards)

function BalatroJokers:GulpBlankVoucher(player)
if player:HasTrinket(BalatroJokers.Enums.Trinkets.Blank, true) and not player:IsHoldingItem() then
local firsttrinket = 0
local secondtrinket = 0

firsttrinket = player:GetTrinket(0)
secondtrinket = player:GetTrinket(1)

if firsttrinket ~= 0 and firsttrinket ~= BalatroJokers.Enums.Trinkets.Blank then
player:TryRemoveTrinket(firsttrinket)
end

if secondtrinket ~= 0 and secondtrinket ~= BalatroJokers.Enums.Trinkets.Blank then
player:TryRemoveTrinket(secondtrinket)
end

player:UseActiveItem(CollectibleType.COLLECTIBLE_SMELTER, UseFlag.USE_NOANIM)

if firsttrinket ~= 0 and firsttrinket ~= BalatroJokers.Enums.Trinkets.Blank then
player:AddTrinket(firsttrinket, false)
firsttrinket = 0
end
if secondtrinket ~= 0 and secondtrinket ~= BalatroJokers.Enums.Trinkets.Blank  then
player:AddTrinket(secondtrinket, false)
secondtrinket = 0
end

if not BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed then
BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed = true
end

end
end
BalatroJokers:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, BalatroJokers.GulpBlankVoucher)

function BalatroJokers:RedeemedBlank(player)
return BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed
end

function BalatroJokers:GetIDFromSlotNum(player, oldslot) 
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

local replacevalue = nil

if oldslot == 1 then
replacevalue = RPData.S1
elseif oldslot == 2 then
replacevalue = RPData.S2
elseif oldslot == 3 then
replacevalue = RPData.S3
elseif oldslot == 4 then
replacevalue = RPData.S4
elseif oldslot == 5 then
replacevalue = RPData.S5
elseif oldslot == 6 then
replacevalue = RPData.S6
elseif oldslot == 7 then
replacevalue = RPData.S7
elseif oldslot == 8 then
replacevalue = RPData.S8
elseif oldslot == 9 then
replacevalue = RPData.S9
elseif oldslot == 10 then
replacevalue = RPData.S10
elseif oldslot == 11 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S11
elseif oldslot == 12 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S12
elseif oldslot == 13 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S13
elseif oldslot == 14 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S14
elseif oldslot == 15 and BalatroJokers.SaveShitNow.GetRunSave(player).BlankVoucherRedeemed  then
replacevalue = RPData.S15
end

return replacevalue

end