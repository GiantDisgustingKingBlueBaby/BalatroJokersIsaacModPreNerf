local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()

function mod:OpenBoosterPack(pickup, collider)

local sprite = pickup:GetSprite()
local player = collider:ToPlayer()


if (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.arcana_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.planet_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.planet_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.buffoon_packm)
or (pickup.Variant >= BalatroJokers.Enums.ExtraPacks.deck_pack and pickup.Variant <= BalatroJokers.Enums.ExtraPacks.fun_pack) 
or (pickup.Variant >= BalatroJokers.Enums.Boosters.spectral and pickup.Variant <= BalatroJokers.Enums.Boosters.spectral_big) then
	
	if player then
		if pickup:IsShopItem() == true and player:GetNumCoins() >= pickup.Price then --Shop Booster Pack
		pickup:GetData().WhatTheFuckDidIsaacJustFuckingBuyYouLittleBitchIllHaveYouKnowIGraduatedTopOfMyClassInTheNavySeals = "FUCK YOU"
			player:AddCoins(-1*(pickup.Price))
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			if pickup.OptionsPickupIndex ~= 0 then
		for i, entity in pairs(Isaac.GetRoomEntities()) do
if entity:ToPickup() and entity:ToPickup().OptionsPickupIndex == pickup.OptionsPickupIndex and entity:GetData().WhatTheFuckDidIsaacJustFuckingBuyYouLittleBitchIllHaveYouKnowIGraduatedTopOfMyClassInTheNavySeals ~= "FUCK YOU" then
		entity:Remove()
		local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, entity.Position, Vector.Zero, nil):ToEffect()
		end
end	
end	
player:AnimatePickup(sprite, HideShadow, AnimName)
			pickup:Remove()
			mod:BoosterPackUnboxing(pickup)
		elseif pickup:IsShopItem() == false then
		pickup:GetData().WhatTheFuckDidIsaacJustFuckingBuyYouLittleBitchIllHaveYouKnowIGraduatedTopOfMyClassInTheNavySeals = "FUCK YOU"
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			sprite:Play("Collect")
			if pickup.OptionsPickupIndex ~= 0 then
		for i, entity in pairs(Isaac.GetRoomEntities()) do
if entity:ToPickup() and entity:ToPickup().OptionsPickupIndex == pickup.OptionsPickupIndex and entity:GetData().WhatTheFuckDidIsaacJustFuckingBuyYouLittleBitchIllHaveYouKnowIGraduatedTopOfMyClassInTheNavySeals ~= "FUCK YOU" then
		entity:Remove()
		local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, entity.Position, Vector.Zero, nil):ToEffect()
		end
end	
end	
mod:BoosterPackUnboxing(pickup)

	if player:HasTrinket(BalatroJokers.Enums.Trinkets.seed_voucher) then
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, (BalatroJokers.Enums.SeedCoins[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.SeedCoins) ]), pickup.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	end
	--Seed Money voucher
	
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.overstock_voucher) then
		local ChosenPickupOverstock = (BalatroJokers.Enums.PickupTypes[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.PickupTypes) ])
		local ChosenPickupSubTypeOS = 0
		
		if ChosenPickupOverstock == 10 then
			if mod:RNGOneParam(2) == 1 then --only red or doublered
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 5
			end
		elseif ChosenPickupOverstock == 20 then
			if mod:RNGOneParam(2) == 1 then --only coin or doublecoin
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 4
			end
		elseif ChosenPickupOverstock == 30 then
			if mod:RNGOneParam(2) == 1 then --only key or doublekey
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 3
			end
		elseif ChosenPickupOverstock == 40 then --bomb or doublebomb
			ChosenPickupSubTypeOS = mod:RNGOneParam(2)
		else
			ChosenPickupSubTypeOS = 1
		end
		Isaac.Spawn(EntityType.ENTITY_PICKUP, ChosenPickupOverstock, ChosenPickupSubTypeOS, pickup.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	end
	--Overstock voucher
	
			pickup:Die()
		end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.OpenBoosterPack)

function mod:PlayDropSound(pickup)
if (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.arcana_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.planet_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.planet_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.buffoon_packm)
or (pickup.Variant >= BalatroJokers.Enums.ExtraPacks.deck_pack and pickup.Variant <= BalatroJokers.Enums.ExtraPacks.fun_pack)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.spectral and pickup.Variant <= BalatroJokers.Enums.Boosters.spectral_big) then
local sprite = pickup:GetSprite()

	if sprite:IsPlaying("Appear") == true and sprite:IsEventTriggered("DropSound") == true then
		SFXManager():Play (249, 1, 0, false, 1)--drop snd
	end
	
	if sprite:IsPlaying("Collect") == true then
		pickup.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
	end
	
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.PlayDropSound)

function mod:BoosterPackUnboxing(pickup)

local player = Isaac.GetPlayer()

local CommonA = BalatroJokers.Enums.CommonA
local CommonB = BalatroJokers.Enums.CommonB
local CommonC = BalatroJokers.Enums.CommonC

local JumboA = BalatroJokers.Enums.JumboA
local JumboB = BalatroJokers.Enums.JumboB
local JumboC = BalatroJokers.Enums.JumboC
local JumboD = BalatroJokers.Enums.JumboD

local MegaA = BalatroJokers.Enums.MegaA
local MegaB = BalatroJokers.Enums.MegaB
local MegaC = BalatroJokers.Enums.MegaC
local MegaD = BalatroJokers.Enums.MegaD
local MegaE = BalatroJokers.Enums.MegaE

if pickup:ToPickup() then

if (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SUIT, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SUIT, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SUIT, 8414740+Game():GetFrameCount())

if pickup.Variant >= BalatroJokers.Enums.Boosters.standard_packj then
mod:SpawnRandomCard(pickup.Position, (JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.RUNE, 8414740+Game():GetFrameCount())
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
end

if pickup.Variant == BalatroJokers.Enums.Boosters.standard_packm then
mod:SpawnRandomCard(pickup.Position, (MegaD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SOUL, 8414740+Game():GetFrameCount())
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
end
end
--Standard

if (pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.arcana_packm) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.TAROT, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.TAROT, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.TAROT, 8414740+Game():GetFrameCount())

if pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_packj then
mod:SpawnRandomCard(pickup.Position, (JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.TAROT_REVERSED, 8414740+Game():GetFrameCount())
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
end

if pickup.Variant == BalatroJokers.Enums.Boosters.arcana_packm then
mod:SpawnRandomCard(pickup.Position, (MegaD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SPECIAL, 8414740+Game():GetFrameCount())
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
end
end
--Arcana

if (pickup.Variant >= BalatroJokers.Enums.Boosters.planet_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.planet_packm) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.PLANET, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.PLANET, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.PLANET, 8414740+Game():GetFrameCount())

if pickup.Variant >= BalatroJokers.Enums.Boosters.planet_packj then
mod:SpawnRandomCard(pickup.Position, (JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.PLANET, 8414740+Game():GetFrameCount())
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
end

if pickup.Variant == BalatroJokers.Enums.Boosters.planet_packm then
mod:SpawnRandomCard(pickup.Position, (MegaD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.PLANET, 8414740+Game():GetFrameCount())
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
end
end
--Planet

if (pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.buffoon_packm) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())

if pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_packj then
mod:SpawnRandomCard(pickup.Position, (JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
end

if pickup.Variant == BalatroJokers.Enums.Boosters.buffoon_packm then
mod:SpawnRandomCard(pickup.Position, (MegaD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
end
end
--Buffoon

if (pickup.Variant == BalatroJokers.Enums.ExtraPacks.deck_pack) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.DECK, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.DECK, 8414740+Game():GetFrameCount())
end
--Deck Pack

--Fun Pack does nothing for some reason

if (pickup.Variant >= BalatroJokers.Enums.Boosters.spectral and pickup.Variant <= BalatroJokers.Enums.Boosters.spectral_big) then
mod:SpawnRandomCard(pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SPECTRAL, 8414740+Game():GetFrameCount())
mod:SpawnRandomCard(pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SPECTRAL, 8414740+Game():GetFrameCount())
if pickup.Variant >= BalatroJokers.Enums.Boosters.spectral_medium then
mod:SpawnRandomCard(pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SPECTRAL, 8414740+Game():GetFrameCount())
end
if pickup.Variant == BalatroJokers.Enums.Boosters.spectral_big then
mod:SpawnRandomCard(pickup.Position, (MegaD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, BalatroJokers.Enums.CardGroup.SPECTRAL, 8414740+Game():GetFrameCount())
end
end
end
end
