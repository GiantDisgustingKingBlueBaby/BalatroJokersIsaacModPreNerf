local mod = BalatroJokers

function mod:OnJimboItemPickup(player)
local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

if player.QueuedItem.Item and player.QueuedItem.Item.ID == BalatroJokers.Enums.Items.jimbos_collection and player.QueuedItem.Touched ~= true then
if not RPData.PickedUpJimbo then
RPData.PickedUpJimbo = true
end
end

if not player.QueuedItem.Item and RPData.PickedUpJimbo == true then
--local retard = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.FART, 0, player.Position, Vector.Zero, player):ToEffect()

SFXManager():Play(BalatroJokers.Enums.SFX.JimboSFX, 1, 0, false, 1)
		for i = 1, 2 do
		local AllVouchers = BalatroJokers.Enums.Vouchers
			Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TRINKET, (AllVouchers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllVouchers)]), player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		end
		local ChosenPickup = (BalatroJokers.Enums.PickupTypes[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.PickupTypes) ])
		local ChosenPickupSubType = 0

	if ChosenPickup == 10 then
			ChosenPickupSubType = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(13)
		elseif ChosenPickup == 20 then
			ChosenPickupSubType = mod:RNGOneParam(7)
		elseif ChosenPickup == 30 then
			ChosenPickupSubType = mod:RNGOneParam(4)
		elseif ChosenPickup == 40 then
			ChosenPickupSubType = mod:RNGOneParam(7)
		elseif ChosenPickup == 69 then
			ChosenPickupSubType = mod:RNGOneParam(2)
		else
			ChosenPickupSubType = 1
		end
		local AllBoosters = BalatroJokers.Enums.WeightedBoosters
		Isaac.Spawn(EntityType.ENTITY_PICKUP, ChosenPickup, ChosenPickupSubType, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		Isaac.Spawn(EntityType.ENTITY_PICKUP, (AllBoosters[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllBoosters)]), 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)		
		
RPData.PickedUpJimbo = nil
end
end
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, mod.OnJimboItemPickup)

function mod:CheckEnemyDeathWithJimbo(enemy)
local roomdata = BalatroJokers.SaveShitNow.GetRoomSave()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if player:HasCollectible(BalatroJokers.Enums.Items.jimbos_collection) and enemy:IsBoss() == true then
	
if not roomdata.BossBeaten then
	if mod:RNGOneParam(2) == 1 then
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, ( mod:IDRandomCard(BalatroJokers.Enums.CardGroup.JOKER) ), enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil) --:ToPickup().Timeout = SpawnedPickupTimeout
		Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
		SFXManager():Play (268, 0.6, 0, false, 1)
	else
	local JimboPacks = BalatroJokers.Enums.BigBoosters
		Isaac.Spawn(EntityType.ENTITY_PICKUP, (JimboPacks[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JimboPacks) ]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
		SFXManager():Play (268, 0.6, 0, false, 1)
	end
	roomdata.BossBeaten = true
end
	
end

if player:HasCollectible(BalatroJokers.Enums.Items.jimbos_collection) and enemy:IsChampion() == true then
	if mod:RNGOneParam(15) <= 1*player:GetCollectibleNum(BalatroJokers.Enums.Items.jimbos_collection) then
		if mod:RNGOneParam(3) > 1 then
		local JimboPacks = BalatroJokers.Enums.BigBoosters
			Isaac.Spawn(EntityType.ENTITY_PICKUP, (JimboPacks[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JimboPacks) ]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
			SFXManager():Play (268, 0.6, 0, false, 1)
		else
		local SPVouchers = BalatroJokers.Enums.SPVouchers
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 350, (SPVouchers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#SPVouchers) ]), enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
			SFXManager():Play (268, 0.6, 0, false, 1)
		end
	end
end

end
end
mod:AddCallback(ModCallbacks.MC_POST_NPC_DEATH, mod.CheckEnemyDeathWithJimbo)

function mod:MorphSoldCards(entity)
local Shouldmorph = false
for playerNum = 0, Game():GetNumPlayers() - 1 do
local player = Game():GetPlayer(playerNum)
if player:HasCollectible(BalatroJokers.Enums.Items.jimbos_collection) == true then
Shouldmorph = true
break
end
end

if Shouldmorph and entity:IsShopItem() ==  true then
local Weighted = BalatroJokers.Enums.WeightedBoosters
local RandomBooster = Weighted[ 1 + Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#Weighted) ]
entity:Morph(5, RandomBooster, 1, true, true, IgnoreModifiers)
end

end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.MorphSoldCards, 300)