local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()

function mod:UseMascotJoker(card, player, useflags) --Regular Jimbo
SFXManager():Play(BalatroJokers.Enums.SFX.BJokerSFX, 1, 0, false, 1)
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMascotJoker, BalatroJokers.Enums.Jokers.BJoker)

function mod:UseGreedyJoker(card, player, useflags) 
SFXManager():Play(BalatroJokers.Enums.SFX.GreedyJokerSFX, 1, 0, false, 1)
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseGreedyJoker, BalatroJokers.Enums.Jokers.GreedyJoker)

function mod:UseLustyJoker(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.LustyJokerSFX, 1, 0, false, 1)
RPData.UsedLustyCount = RPData.UsedLustyCount and RPData.UsedLustyCount+ 1 or 1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseLustyJoker, BalatroJokers.Enums.Jokers.LustyJoker)

function mod:UsePissedJoker(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.WrathfulJokerSFX, 1, 0, false, 1)
RPData.UsedWrathfulCount = RPData.UsedWrathfulCount and RPData.UsedWrathfulCount+ 1 or 1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UsePissedJoker, BalatroJokers.Enums.Jokers.WrathfulJoker)

function mod:UseFatJoker(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.GluttonousJokerSFX, 1, 0, false, 1)
RPData.UsedGluttonCount = RPData.UsedGluttonCount and RPData.UsedGluttonCount+ 1 or 1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseFatJoker, BalatroJokers.Enums.Jokers.GluttonousJoker)

function mod:PickupCounter(entity, collider)

local BJoker = Isaac.GetCardIdByName("Joker_Jimbo")
local GreedyJoker = Isaac.GetCardIdByName("Greedy Joker")
local LustyJoker = Isaac.GetCardIdByName("Lusty Joker")
local WrathfulJoker = Isaac.GetCardIdByName("Wrathful Joker")
local GluttonousJoker = Isaac.GetCardIdByName("Gluttonous Joker")


	local player = collider:ToPlayer()

	if player ~= nil then

	local RFData = BalatroJokers.SaveShitNow.GetFloorSave(player)
		if entity.Variant == 10 and mod:GetJokerCount(player, LustyJoker) > 0 then
			if entity.SubType == 5 and player:CanPickRedHearts() == true then
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RFData.HeartCounter = RFData.HeartCounter and RFData.HeartCounter+4 or 4 
				end
			elseif (entity.SubType == 1 and player:CanPickRedHearts() == true) or (entity.SubType == 3 and player:CanPickSoulHearts() == true) or (entity.SubType == 6 and player:CanPickBlackHearts() == true) or (entity.SubType == 9 and player:CanPickRedHearts() == true) or (entity.SubType == 10 and (player:CanPickRedHearts() == true or player:CanPickSoulHearts() == true)) then --if full red, full soul, full black, full scared or full blended
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RFData.HeartCounter = RFData.HeartCounter and RFData.HeartCounter+2 or 2 
				end
			elseif (entity.SubType == 7 and player:CanPickGoldenHearts() == true) or (entity.SubType == 11 and player:CanPickBoneHearts() == true) or (entity.SubType == 12 and player:CanPickRottenHearts() == true) then
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RFData.HeartCounter = RFData.HeartCounter and RFData.HeartCounter+1 or 1 
				end
			end
		elseif entity.Variant == 20 and mod:GetJokerCount(player, GreedyJoker) > 0 and entity.SubType ~= 6 then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				RFData.CoinCounter = RFData.CoinCounter and RFData.CoinCounter+entity:GetCoinValue() or entity:GetCoinValue() 
			end
		elseif entity.Variant == 30 and mod:GetJokerCount(player, WrathfulJoker) > 0 then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				if entity.SubType == 3 then
					RFData.KeyCounter = RFData.KeyCounter and RFData.KeyCounter+2 or 2 
				else
					RFData.KeyCounter = RFData.KeyCounter and RFData.KeyCounter+1 or 1 
				end
			end
		elseif entity.Variant == 40 and mod:GetJokerCount(player, GluttonousJoker) > 0 then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				if entity.SubType == 2 then
					RFData.BombCounter = RFData.BombCounter and RFData.BombCounter+2 or 2 
				else
					RFData.BombCounter = RFData.BombCounter and RFData.BombCounter+1 or 1 
				end
			end
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end

end

mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.PickupCounter)

function mod:UseMisprint(card, player, useflags)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
if RPData then
SFXManager():Play(BalatroJokers.Enums.SFX.MisprintSFX, 1, 0, false, 1)
RPData.UsedMisprint = RPData.UsedMisprint and RPData.UsedMisprint+ 1 or 1
RPData.MisprintMult = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(24)*0.1
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseMisprint, BalatroJokers.Enums.Jokers.Misprint)

function mod:RerollMult()

	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
		local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		
if RPData.UsedMisprint then
RPData.MisprintMult = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(24)*0.1 --0~2.3 range
player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
player:EvaluateItems()
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.RerollMult)