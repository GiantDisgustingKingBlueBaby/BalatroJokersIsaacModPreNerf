local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()

function mod:FirstEditionFunc()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.first_edition) and roomt == RoomType.ROOM_SECRET and room:IsFirstVisit() == true then
		for i = 1, 3*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.first_edition) do
		mod:SpawnRandomCard(Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(room:GetCenterPos(),8),0,true,false), Vector.Zero, BalatroJokers.Enums.CardGroup.JOKER, 8414740+Game():GetFrameCount())
		end
	end
	
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.double_stakes) == true and (roomt == RoomType.ROOM_ANGEL or roomt == RoomType.ROOM_DEVIL) then --DOUBLE STAKES FUNCTION
		for i = 1, player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.double_stakes) do
		
		local cardforsaletypeA = mod:RNGOneParam(5)
		local cardforsaletypeB = mod:RNGOneParam(5)
		local PCards = BalatroJokers.Enums.PCards
		
		if cardforsaletypeA == 1 then --JOKER
			cardforsaleA = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.JOKER)
		elseif cardforsaletypeA == 2 then --PLANET
			cardforsaleA = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.PLANET)
		elseif cardforsaletypeA == 3 then --PLAYING
			cardforsaleA = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.SUIT)
		elseif cardforsaletypeA == 4 then --TAROT
			cardforsaleA = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.TAROT)
		elseif cardforsaletypeA == 5 then --SPECIAL
			cardforsaleA = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.SPECIAL)
		end
		
		if cardforsaletypeB == 1 then --JOKER
			cardforsaleB = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.JOKER)
		elseif cardforsaletypeB == 2 then --PLANET
			cardforsaleB = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.PLANET)
		elseif cardforsaletypeB == 3 then --PLAYING
			cardforsaleB = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.SUIT)
		elseif cardforsaletypeB == 4 then --TAROT
			cardforsaleB = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.TAROT)
		elseif cardforsaletypeB == 5 then --SPECIAL
			cardforsaleB = mod:IDRandomCard(BalatroJokers.Enums.CardGroup.SPECIAL)
		end
		
			local DAfirstcard = Isaac.Spawn(5,150,1,Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(250,270),1)), Vector.Zero, nil):ToPickup():Morph(5, 300, cardforsaleA, true, true, IgnoreModifiers)
			local DAsecondcard = Isaac.Spawn(5,150,1,Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(390,270),1)), Vector.Zero, nil):ToPickup():Morph(5, 300, cardforsaleB, true, true, IgnoreModifiers)
		
		end
	end
	
	
end	
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.FirstEditionFunc)

function mod:NewFloorCSuit()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.cheap_suit) == true then
	for i = 1, player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.cheap_suit) do
local AllJokers = BalatroJokers.Enums.RiffRaffTable
		player:UseCard((AllJokers[1+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers)]), UseFlag.USE_OWNED)
	end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.NewFloorCSuit)

function mod:CheckGridRock(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

	if player:HasTrinket(BalatroJokers.Enums.Trinkets.stone_card) == true then
		for i = 1, Game():GetRoom():GetGridSize() do
			local tintedrock = Game():GetRoom():GetGridEntity(i)
			if tintedrock ~= nil and tintedrock:GetType() == 4 and tintedrock.State == 2 and not BalatroJokers.SaveShitNow.GetFloorSave().SCAlreadyspawned then --this only happens once but whatever, should be good enough
				local SCMult = player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.stone_card)*3
				local SCRoll = BalatroJokers:RNGOneParam(10)
				if SCRoll >= SCMult+1 and SCRoll <= SCMult+2 then
					Isaac.Spawn(EntityType.ENTITY_PICKUP, BalatroJokers.Enums.ExtraPacks.deck_pack, 1, tintedrock.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
				elseif SCRoll <= SCMult then
				local AllVouchers = BalatroJokers.Enums.Vouchers
					Isaac.Spawn(EntityType.ENTITY_PICKUP, 350, (AllVouchers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllVouchers)]), tintedrock.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
				end
				BalatroJokers.SaveShitNow.GetFloorSave().SCAlreadyspawned = true
			end
		end
	end
	
	if entity.Type == EntityType.ENTITY_PICKUP and entity.Variant == PickupVariant.PICKUP_TRINKET and entity.SubType == BalatroJokers.Enums.Trinkets.stone_card and entity.SpawnerType == EntityType.ENTITY_PLAYER and not entity:GetData().COLLIDED222 then
		--Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), nil):ToEffect().SpriteScale = Vector(0.8, 0.8)
		SFXManager():Play(137, 1, 0, false, 1.2)
		local PoofOut = Isaac.Spawn(EntityType.ENTITY_EFFECT,59, 0, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, player):ToEffect()
		PoofOut:SetTimeout(20)
		for i = 1, 6 do
		local SCrocksbig = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCK_PARTICLE , 0, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		SCrocksbig:ToEffect().Color = Color(0.6,0.6,0.6,0.8)
		SCrocksbig:ToEffect().SpriteScale = Vector(0.6, 0.6)
		end
	end
	
end
end
mod:AddCallback(ModCallbacks.MC_POST_ENTITY_REMOVE, mod.CheckGridRock)

function mod:DestroyTrinketPreq(entity)
if entity.SubType == BalatroJokers.Enums.Trinkets.stone_card and entity.SpawnerType == EntityType.ENTITY_PLAYER then
	entity:ToPickup().Timeout = 90
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.DestroyTrinketPreq, 350)

function mod:CardHouse(entity)
	for playerNum = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(playerNum)
if player:HasTrinket(BalatroJokers.Enums.Trinkets.card_house) == true and entity.SpawnerType ~= EntityType.ENTITY_PLAYER and not BalatroJokers:IsAnyJoker(entity.SubType) and ((entity:GetSprite():IsPlaying("Appear") or entity:GetSprite():IsPlaying("AppearFast")) and entity.Timeout == -1 and entity:GetSprite():GetFrame() == 1) then
	local chousechance = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5)
	if chousechance <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.card_house) then
local itemConfig = Isaac.GetItemConfig()
local cardgroup = {}
for i = 1, itemConfig:GetCards().Size - 1 do
    local item = itemConfig:GetCard(i)
    if item and mod:CardTypeBoolean(i, BalatroJokers.Enums.CardGroup.JOKER)	
	then
        table.insert(cardgroup, i)
    end
end
local randomcard = cardgroup[Isaac.GetPlayer():GetCollectibleRNG(678):RandomInt(#cardgroup) + 1]
	entity:Morph(EntityType.ENTITY_PICKUP, 300, randomcard, true)
end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.CardHouse, 300)

function mod:PlayDropSound2(pickup)
if pickup.SubType == BalatroJokers.Enums.Trinkets.stone_card then
local sprite = pickup:GetSprite()

	if sprite:IsPlaying("Appear") == true and sprite:IsEventTriggered("DropSound") == true then
	SFXManager():Play(249, 0)
	SFXManager():Play(SoundEffect.SOUND_STONE_IMPACT, 12, 0, false, 1)
	for i = 1, 4 do
	local SCrocks = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCK_PARTICLE , 0, pickup.Position, Vector.FromAngle(Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	SCrocks:ToEffect().Color = Color(0.6,0.6,0.6,0.6)
	SCrocks:ToEffect().SpriteScale = Vector(0.4, 0.4)
	end
end
end

if pickup.SubType == BalatroJokers.Enums.Trinkets.Blank + 2^15 then

pickup:Morph(5,350,BalatroJokers.Enums.Trinkets.Blank,true,false)

end

end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.PlayDropSound2, 350)

function mod:ExtraPack3(pickup, collider)
local player = collider:ToPlayer()
if player and player:IsHoldingItem() == false and pickup.SubType == BalatroJokers.Enums.Trinkets.stone_card then
pickup:GetData().COLLIDED222 = "FUCKING YES"
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.ExtraPack3, 350)