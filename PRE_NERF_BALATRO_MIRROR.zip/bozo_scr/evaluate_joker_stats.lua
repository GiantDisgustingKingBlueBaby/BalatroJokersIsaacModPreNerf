local mod = BalatroJokers
local Save = BalatroJokers.SaveShitNow
local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()

local BJoker = Isaac.GetCardIdByName("Joker_Jimbo")
local GreedyJoker = Isaac.GetCardIdByName("Greedy Joker")
local LustyJoker = Isaac.GetCardIdByName("Lusty Joker")
local WrathfulJoker = Isaac.GetCardIdByName("Wrathful Joker")
local GluttonousJoker = Isaac.GetCardIdByName("Gluttonous Joker")
local JollyJoker = Isaac.GetCardIdByName("Jolly Joker")
local WilyJoker = Isaac.GetCardIdByName("Wily Joker")
local HalfJoker = Isaac.GetCardIdByName("Half Joker")
local JokerStencil = Isaac.GetCardIdByName("Joker Stencil")
local Mime = Isaac.GetCardIdByName("Mime")
local MarbleJoker = Isaac.GetCardIdByName("Marble Joker")
local EightBall = Isaac.GetCardIdByName("8 Ball")
local Misprint = Isaac.GetCardIdByName("Misprint")
local RaisedFist = Isaac.GetCardIdByName("Raised Fist")
local Fibonacci = Isaac.GetCardIdByName("Fibonacci")
local ScaryFace = Isaac.GetCardIdByName("Scary Face")
local Hack = Isaac.GetCardIdByName("Hack")
local GrosMichel = Isaac.GetCardIdByName("Gros Michel")
local Supernova = Isaac.GetCardIdByName("Supernova")
local SpaceJoker = Isaac.GetCardIdByName("Space Joker")
local Egg = Isaac.GetCardIdByName("Egg")
local Blackboard = Isaac.GetCardIdByName("Blackboard")
local BlueJoker = Isaac.GetCardIdByName("Blue Joker")
local SquareJoker = Isaac.GetCardIdByName("Square Joker")
local RiffRaff = Isaac.GetCardIdByName("Riff-Raff")
local Vampire = Isaac.GetCardIdByName("Vampire")
local Vagabond = Isaac.GetCardIdByName("Vagabond")
local Rocket = Isaac.GetCardIdByName("Rocket")
local Hologram = Isaac.GetCardIdByName("Hologram")

function mod:EvaluateJokerDMG(player, flag)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local RmData = BalatroJokers.SaveShitNow.GetRoomSave(player)
local RFData = BalatroJokers.SaveShitNow.GetFloorSave(player)

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.BJoker) > 0  then
player.Damage = player.Damage + 0.7 * mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.BJoker)
end

if mod:GetJokerCount(player, GreedyJoker) > 0 and RFData.CoinCounter then
player.Damage = player.Damage + 0.35 * RFData.CoinCounter * mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GreedyJoker) 
end

if mod:GetJokerCount(player, LustyJoker) > 0 and  RPData.HeartCounter then
player.Damage = player.Damage + 0.35 * RFData.HeartCounter * mod:GetJokerCount(player, LustyJoker) 
end

if mod:GetJokerCount(player, WrathfulJoker) > 0 and RFData.KeyCounter then --Spade key
player.Damage = player.Damage + 0.525 * RFData.KeyCounter * mod:GetJokerCount(player, WrathfulJoker)
end

if mod:GetJokerCount(player, GluttonousJoker) > 0 and RFData.BombCounter then
player.Damage = player.Damage + 0.525 * RFData.BombCounter * mod:GetJokerCount(player, GluttonousJoker)
end

if mod:GetJokerCount(player, JollyJoker) > 0 and RmData.KillsInRoom then
player.Damage = player.Damage + 0.3 * math.floor(RmData.KillsInRoom/2) * mod:GetJokerCount(player, JollyJoker)
end

if mod:GetJokerCount(player, HalfJoker) > 0 and RmData.ShouldProcHalf == true then
player.Damage = player.Damage + 1.3 * mod:GetJokerCount(player, HalfJoker)
end

if mod:GetJokerCount(player, JokerStencil) > 0 and 
player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= 0 and
Isaac.GetItemConfig():GetCollectible(player:GetActiveItem(ActiveSlot.SLOT_PRIMARY)) ~= 1 and --Timed charges
player:NeedsCharge(ActiveSlot.SLOT_PRIMARY) then
player.Damage = player.Damage + 0.4 * (Isaac.GetItemConfig():GetCollectible(player:GetActiveItem(ActiveSlot.SLOT_PRIMARY)).MaxCharges - player:GetActiveCharge(ActiveSlot.SLOT_PRIMARY)) * mod:GetJokerCount(player, JokerStencil)
end

if mod:GetJokerCount(player, Misprint) > 0 and RPData.MisprintMult then
player.Damage = player.Damage + 0.5* RPData.MisprintMult * mod:GetJokerCount(player, Misprint)
end

if mod:GetJokerCount(player, RaisedFist) > 0 and RPData.RaisedFistBonus then
player.Damage = player.Damage +  RPData.RaisedFistBonus * mod:GetJokerCount(player, RaisedFist)
end

if mod:GetJokerCount(player, Fibonacci) > 0 then
			if ((player:GetNumBombs() >= 1 and player:GetNumBombs() <= 3) or player:GetNumBombs() == 5 or player:GetNumBombs() == 8) and 
			((player:GetNumKeys() >= 1 and player:GetNumKeys() <= 3) or player:GetNumKeys() == 5 or player:GetNumKeys() == 8) and 
			((player:GetNumCoins() >= 1 and player:GetNumCoins() <= 3) or player:GetNumCoins() == 5 or player:GetNumCoins() == 8) then
			player.Damage = player.Damage+(mod:GetJokerCount(player, Fibonacci)*2*RPData.FibProc)
			end
end

local GrosMichel = BalatroJokers.Enums.Jokers.GrosMichel

if mod:GetJokerCount(player, Blackboard) > 0 and RPData.ShouldProcBBoard then
 player.Damage = player.Damage * (1.4)^(mod:GetJokerCount(player, Blackboard)*RPData.ShouldProcBBoard)
end

if mod:GetJokerCount(player, Vampire) > 0 and RPData.KillsTotal then
player.Damage = player.Damage+player.Damage*(RPData.KillsTotal*0.005)*mod:GetJokerCount(player, Vampire)
end

if mod:GetJokerCount(player, Hologram) > 0 and RPData.HoloBonusArc then
player.Damage = player.Damage+player.Damage*(RPData.HoloBonusArc*0.04*mod:GetJokerCount(player, Hologram))
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.FortuneTeller) > 0 and RPData.Arcana then
player.Damage = player.Damage+(RPData.Arcana*0.07*mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.FortuneTeller))
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Baseball) > 0 and BalatroJokers:MaxValidSlot(player) then
player.Damage = player.Damage*(1.05^(BalatroJokers:MaxValidSlot(player)))
end

if RPData.PolychromeUseCount then
player.Damage = player.Damage*(1.5)^RPData.PolychromeUseCount
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Madness) > 0  then
player.Damage = player.Damage*(1.5)^mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Madness) 
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GrosMichel) > 0 then
player.Damage = player.Damage + 3 * mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.GrosMichel) 
end

if mod:GetJokerCount(player, BalatroJokers.Enums.Jokers.Abstract) > 0 and BalatroJokers:MaxValidSlot(player) then
player.Damage = player.Damage+(0.3*(BalatroJokers:MaxValidSlot(player)))
end

end
mod:AddPriorityCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
    CallbackPriority.EARLY- 999999, --Reason: Soymilk
    mod.EvaluateJokerDMG,
	CacheFlag.CACHE_DAMAGE
)

--Flat amount * Picked up count * ( 2 ^ (-1 + Used joker count) ) for suit jokers

function mod:EvaluateJokerFireRate(player, flag)

local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
local RmData = BalatroJokers.SaveShitNow.GetRoomSave(player)


if mod:GetJokerCount(player, WilyJoker) > 0 then
 if RmData.KillsInRoom then
player.MaxFireDelay = mod:CalculateNewFireDelay(player.MaxFireDelay, 0.2 * math.floor(RmData.KillsInRoom/3) * mod:GetJokerCount(player, WilyJoker))
else
player.MaxFireDelay = mod:CalculateNewFireDelay(player.MaxFireDelay, 0.2 * 0 * mod:GetJokerCount(player, WilyJoker))
end
end

if mod:GetJokerCount(player, ScaryFace) > 0 and RPData.KillsTotalC then
player.MaxFireDelay = mod:CalculateNewFireDelay(player.MaxFireDelay, math.min(5, 0.03 * RPData.KillsTotalC * mod:GetJokerCount(player, ScaryFace)) )
end

if RPData.BlueAmount then --Blacklisted; Don't use GetJokerCount
player.MaxFireDelay = mod:CalculateNewFireDelay(player.MaxFireDelay, RPData.BlueAmount * 0.15 )
end

if mod:GetJokerCount(player, SquareJoker) > 0 and RmData.ShouldProcSquare == true then
player.MaxFireDelay = mod:CalculateNewFireDelay(player.MaxFireDelay, 4 * mod:GetJokerCount(player, SquareJoker))
end

end

mod:AddPriorityCallback(
    ModCallbacks.MC_EVALUATE_CACHE,
   CallbackPriority.EARLY - 999999, --Reason: Poly
    mod.EvaluateJokerFireRate,
	CacheFlag.CACHE_FIREDELAY
)

