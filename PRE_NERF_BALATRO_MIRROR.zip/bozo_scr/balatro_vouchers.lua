local mod = BalatroJokers

function mod:PreReward(rng)
	BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer = 5
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.PreReward)

function mod:ReEvaluateTimer()
 if BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer then
 BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer = BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer -1
 if BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer < 0 then
 BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer = nil
 end
 end
end
mod:AddCallback(ModCallbacks.MC_POST_UPDATE, mod.ReEvaluateTimer)

function mod:VoucherReward(pickup)
local VoucherMult = 0
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
		local VoucherAmount = (player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.torn_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.seed_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.overstock_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.magic_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.clearance_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.reroll_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hieroglyph_voucher))
		
		VoucherMult = VoucherMult + VoucherAmount
end
if VoucherMult > 0 and BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer and BalatroJokers.SaveShitNow.GetRoomSave().RoomClearTimer == 3 and pickup.FrameCount <= 2 then
--print(VoucherMult)
local PackReplaceChance = mod:RNGOneParam(10)
		if PackReplaceChance <= 1 * VoucherMult then --10% base chance, increased with trinket amount and boosters
			if pickup.Variant == 10 or pickup.Variant == 20 or pickup.Variant == 30 or pickup.Variant == 40 or pickup.Variant == 70 or pickup.Variant == 90 or pickup.Variant == 300 then
local AllPacksWeighted = BalatroJokers.Enums.WeightedBoosters
			pickup:ToPickup():Morph(EntityType.ENTITY_PICKUP, (AllPacksWeighted[1 + Isaac.GetPlayer():GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllPacksWeighted) ]), 1, true)
			end
end
end
end	
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.VoucherReward)

function mod:ExtraPack(entity, collider)
local VoucherMult = 0
local sprite = entity:GetSprite()
local AllVouchers = BalatroJokers.Enums.Vouchers
local player = collider:ToPlayer()
	if entity.SubType == ChestSubType.CHEST_OPENED and sprite:GetFrame() == 1 and player then
		
local VoucherAmount = (player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.torn_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.seed_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.overstock_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.magic_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.clearance_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.reroll_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hieroglyph_voucher))
		
		local VoucherExtraPackChance = BalatroJokers:RNGOneParam(7)
		
		if VoucherAmount > 0  and VoucherExtraPackChance <= 1+VoucherAmount then --33% base chance, increased with trinket amount and boosters
			
			local AllPacksWeighted = BalatroJokers.Enums.WeightedBoosters
			Isaac.Spawn(EntityType.ENTITY_PICKUP,  (AllPacksWeighted[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllPacksWeighted) ]), 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)

		end
	
	end
	
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.ExtraPack, 50)

function mod:ExtraPack2(pickup, collider)
if pickup:GetData().ChooseIndex then
local player = collider:ToPlayer()
if player and not player:IsHoldingItem() then
pickup:GetData().COLLIDED = "FUCKING YES"

if pickup:GetData().COLLIDED == "FUCKING YES" then
for i, entity in ipairs(Isaac.GetRoomEntities()) do
local ChanceToConvertHigh = BalatroJokers:RNGOneParam(3)
local ChanceToConvertLow = BalatroJokers:RNGOneParam(10)
if entity:GetData().COLLIDED ~= "FUCKING YES" and entity:GetData().ChooseIndex == pickup:GetData().ChooseIndex and entity.Type == 5 then
if player:HasTrinket(BalatroJokers.Enums.Trinkets.wasteful_voucher) and ChanceToConvertHigh <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher) then
		local coin = Isaac.Spawn(5, 20, 1, entity.Position, entity.Velocity, nil)
end
--낭비벽 바우처

if player:HasTrinket(BalatroJokers.Enums.Trinkets.tarot_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher) then
		mod:SpawnRandomCard(entity.Position, entity.Velocity, BalatroJokers.Enums.CardGroup.TAROT)
end
--타로 상인 바우처

if player:HasTrinket(BalatroJokers.Enums.Trinkets.planet_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher) then
		mod:SpawnRandomCard(entity.Position, entity.Velocity, BalatroJokers.Enums.CardGroup.PLANET)
end
--행성 상인 바우처

if player:HasTrinket(BalatroJokers.Enums.Trinkets.directors_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher) then
		local shard = Isaac.Spawn(5, 300, 49, entity.Position, entity.Velocity, nil)
end
--감독판 바우처
local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, 15, 0, entity.Position, Vector.Zero, nil):ToEffect()
entity:Remove()


--연마, 백지, 종잣돈, 과잉 공급, 마술, 대방출 세일, 새로고침 잉여, 상형문자, 찢긴 바우처는 제외

end
end
pickup:GetData().COLLIDED = nil
end	

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.ExtraPack2)

function mod:CheckShopItem(entity, collider)
local player = collider:ToPlayer()
if player then
if player:HasTrinket(BalatroJokers.Enums.Trinkets.magic_voucher) and entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price and player:IsHoldingItem() == false then
	local SpawnExtraMagic = 0
	if mod:RNGOneParam(4) == 1 then
		if entity.Variant == 10 and (entity.SubType == 1 or entity.SubType == 5) and player:CanPickRedHearts() == true then --if red heart
			SpawnExtraMagic = 1
		elseif entity.Variant == 10 and entity.SubType == 3 and player:CanPickSoulHearts() == true then --if blue heart
			SpawnExtraMagic = 1
		elseif entity.Variant == 90 and player:NeedsCharge() == true then
			SpawnExtraMagic = 1
		elseif entity.Variant ~= 10 and entity.Variant ~= 90 then
			SpawnExtraMagic = 1
		end
	end
	if SpawnExtraMagic == 1 then
		local randomdeckcard = (BalatroJokers.Enums.Decks[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.Decks) ])
		Isaac.Spawn(EntityType.ENTITY_PICKUP, BalatroJokers.Enums.ExtraPacks.deck_pack, 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	SpawnExtraMagic = 0
	end
end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.CheckShopItem)

function BalatroJokers:IsThisABooster(pickup)

local valid = false

for _, value in ipairs(BalatroJokers.Enums.WeightedBoosters) do
    if value == pickup.Variant then
        valid = true --Man I miss TSIL
        break
    end
end

if valid then
return true

else
return false
end

end

function mod:CSale(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
		if player:HasTrinket(BalatroJokers.Enums.Trinkets.clearance_voucher) == true then
		--for i, entity in pairs(Isaac.GetRoomEntities()) do
		if entity:IsShopItem() == true and BalatroJokers:IsThisABooster(entity) then
		entity:ToPickup().Price = math.ceil( entity:ToPickup().Price / 2 )
		end
		end
		--end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.CSale)

--l Isaac.Spawn(5,69401,1,Isaac.GetPlayer().Position, Vector.Zero, nil):ToPickup().ShopItemId = -1

function mod:CheckDonationMachine()
local room = Game():GetRoom()
local roomt = Game():GetRoom():GetType()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.reroll_voucher) and roomt == RoomType.ROOM_SHOP then
		if room:IsFirstVisit() == true and Isaac.CountEntities(nil, 6, 10, -1) == 0 then
			Isaac.Spawn(EntityType.ENTITY_SLOT, 10, 1, Vector(135,160), Vector(0,0), nil)
		end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.CheckDonationMachine)

function mod:CheckBossDeathHoneVoucher(enemy)
local roomdata = BalatroJokers.SaveShitNow.GetRoomSave()
for i = 0, Game():GetNumPlayers() - 1 do
local player = Game():GetPlayer(i)
if enemy:IsBoss() == true and not roomdata.BossBeaten == true then
if player:HasTrinket(BalatroJokers.Enums.Trinkets.hone_voucher) then
if mod:RNGOneParam(4) <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher) then
Isaac.Spawn(EntityType.ENTITY_PICKUP, (BalatroJokers.Enums.BigBoosters[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.BigBoosters) ]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
end
roomdata.BossBeaten = true
--Partially taken from K&G's severed head random drop function
end
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NPC_DEATH, mod.CheckBossDeathHoneVoucher)

function mod:KillBossHiero()
local roomdata = BalatroJokers.SaveShitNow.GetRoomSave()
local roomt = Game():GetRoom():GetType()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.hieroglyph_voucher) and roomt == RoomType.ROOM_BOSS and not roomdata.HieroActivated then
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity:IsBoss() == true and entity.Type ~= EntityType.ENTITY_DOGMA and entity.Type ~= EntityType.ENTITY_BEAST and entity.Type ~= EntityType.ENTITY_MOTHER and entity.Type ~= EntityType.ENTITY_DELIRIUM and entity.Type ~= EntityType.ENTITY_HUSH and entity.Type ~= EntityType.ENTITY_ULTRA_GREED and Game():GetLevel():GetStage() ~= LevelStage.STAGE6 then --EntityType.ENTITY_MEGA_SATAN == false and EntityType.ENTITY_MEGA_SATAN_2 == false
				roomdata.HieroActivated = true
				player:AnimateTrinket(BalatroJokers.Enums.Trinkets.hieroglyph_voucher, "Pickup", "PlayerPickupSparkle")
				Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, player.Position, Vector(0, 0), player)
				entity:Kill()
				player:TryRemoveTrinket(BalatroJokers.Enums.Trinkets.hieroglyph_voucher)
			end
		end
	end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.KillBossHiero)

function mod:RemoveBossItem(pickup, collider)
local roomdata = BalatroJokers.SaveShitNow.GetRoomSave()
local roomt = Game():GetRoom():GetType()
local player = collider:ToPlayer()
if player then
if roomt == RoomType.ROOM_BOSS and roomdata.HieroActivated then
if Isaac.GetItemConfig():GetCollectible(pickup.SubType):HasTags(ItemConfig.TAG_QUEST) ~= true then
pickup:Remove()
player:AnimateSad()
Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Nope_Effect , 0, pickup.Position, Vector(0, 0), player).DepthOffset = 10000
SFXManager():Play(BalatroJokers.Enums.SFX.NopeSFX)
end
end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.RemoveBossItem, 100)

--[[
function mod:ReplacePickup(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
local AllVouchers = BalatroJokers.Enums.Vouchers
local RoomClearTimer = BalatroJokers.SaveShitNow.GetRunSave().RoomClearTimer
if (player:GetTrinket(0) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(0) <= BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1)
or (player:GetTrinket(1) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(1) <= BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1) then

	if RoomClearTimer == 5 and RoomClearTimer > 0 then
	RoomClearTimer = RoomClearTimer - 1
	end
	
	if entity.FrameCount <= 5 and RoomClearTimer ~= 0 then
		RoomClearTimer = 0
		local PackReplaceChance = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11)
		local VoucherAmount = (player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.torn_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.seed_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.overstock_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.magic_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.clearance_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.reroll_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hieroglyph_voucher))
		
		--print(player:GetTrinketRNG(torn_voucher):RandomInt(9))
		if PackReplaceChance <= 1*VoucherAmount then --10% base chance, increased with trinket amount and boosters
			if entity.Variant == 10 or entity.Variant == 20 or entity.Variant == 30 or entity.Variant == 40 or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300 then
			Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player)
local AllPacksWeighted = BalatroJokers.Enums.WeightedBoosters
			entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, (AllPacksWeighted[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllPacksWeighted) ]), 1, true)
			
			end
		end
	end
	
end
	
end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.ReplacePickup)
]]