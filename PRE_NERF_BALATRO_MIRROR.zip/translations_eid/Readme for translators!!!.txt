Since you are now officially part of the dev team, you can now add translations yourselves! However, due to the innate problem of Steam workshop, I HEAVILY recommend that you:

>Push updates AFTER a content update.
>Preserve your translation files.
>Just send the new ones via Steam as raw text.

(Use "eid_kr.lua" as an example to see how the descriptions should look like!)