BalatroJokers = RegisterMod("Balatro Jokers", 1)
local mod = BalatroJokers --Added global modref
local defaultsChanged = false
--local SaveState = {}
--json = require("json")
--require ("helper")
--We're using Catinsurance's Savemanager for easier save file management
include("hamburger_helper.helper")
--Oops! All global variables! Dont' worry, I fixed it now. -BB
BalatroJokers.SaveShitNow = include("hamburger_helper.save_manager") -- the path to the save manager, with different directories/folders separated by dots
BalatroJokers.SaveShitNow.Init(BalatroJokers)
BalatroJokers.HideShitNow = include("hamburger_helper.hidden_item_manager"):Init(BalatroJokers)

local SpawnedPickupTimeout = BalatroJokers.Enums.Constants.SpawnedPickupTimeout

function BalatroJokers:PreSave(data)
	BalatroJokers.SaveShitNow.DEFAULT_SAVE.HIDDEN_ITEM_DATA = BalatroJokers.HideShitNow:GetSaveData()
end
BalatroJokers.SaveShitNow.AddCallback(BalatroJokers.SaveShitNow.Utility.CustomCallback.PRE_DATA_SAVE, BalatroJokers.PreSave)

function BalatroJokers:PostLoad(data)
	BalatroJokers.HideShitNow:LoadData(BalatroJokers.SaveShitNow.DEFAULT_SAVE.HIDDEN_ITEM_DATA)
end
BalatroJokers.SaveShitNow.AddCallback(BalatroJokers.SaveShitNow.Utility.CustomCallback.POST_DATA_LOAD, BalatroJokers.PostLoad)

local FirstJoker = BalatroJokers.Enums.Jokers.BJoker
local LastJoker = BalatroJokers.Enums.Jokers.Hologram
--Change lastjoker if we add more jokers -GDKBB

--TODO
--Try OptionsPickupIndex for pickup disappear logic from packs

----------------------------------------- DEATH CERTIFICATE CRASH FIX

--[[
local inDeathCert = false
function mod:useItemDC(item, _, player)
  if item == CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE then
    inDeathCert = true
  end
end
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.useItemDC)

function mod:onNewRoomDC()
  if inDeathCert then
	if Game():GetRoom():IsClear() == false then
		inDeathCert = false
	end
  end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.onNewRoomDC)

function mod:PreSpawnDC()

if inDeathCert then
	for i, entity in pairs(Isaac.GetRoomEntities()) do
			entity:GetSprite():Play("Idle", true)
			entity:GetSprite():Update()
		end
	end
end

end
mod:AddCallback(ModCallbacks.MC_PRE_ENTITY_SPAWN, mod.PreSpawnDC)
--]]


--Define these first, then overwrite if necessary, probably useless but i'll keep em here

local RunData = BalatroJokers.SaveShitNow.GetRunSave()
local FloorData = BalatroJokers.SaveShitNow.GetFloorSave()
local RoomData = BalatroJokers.SaveShitNow.GetRoomSave()
--Data management


--[[
JokerVars = {
["BJokerAmount"] = 0,
["HeartCount"] = nil,
["CoinCount"] = nil,
["KeyCount"] = nil,
["BombCount"] = nil,
["RoomKC_Jolly"] = nil,
["RoomKC_Wily"] = nil,
["HalfJokerAmount"] = nil,
["StencilActive"] = nil,
["MarbleEnabled"] = false,
["MisprintMult"] = nil,
["RaisedFistBonus"] = nil,
["FibonacciActive"] = nil,
["ChampKC_Scary"] = nil,
["HackAmount"] = nil,
["GrosActive"] = false,
["BlackboardBonus"] = nil,
["BlueAmount"] = nil,
["SquareEnabled"] = nil,
["VampireAmount"] = nil,
["HoloBonus"] = nil,
}
]]

--JIMBO FUCKING CHRIST USE A MOTHERFUCKING SAVE MANAGER FOR FUCKS SAKE -GDKBB
----------------------------------------- SET VALUES

function mod:InitShitLater(player)
    if BalatroJokers.SaveShitNow then
        if BalatroJokers.SaveShitNow.GetRunSave(player).InitShitLater == nil then
            BalatroJokers.SaveShitNow.GetRunSave(player).InitShitLater = "NotQuite"
        end
        if BalatroJokers.SaveShitNow.GetRunSave(player).InitShitLater == "NotQuite" then

		BalatroJokers.SaveShitNow.GetRunSave(player).UsedJokerAmount = 0
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos1 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos2 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos3 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos4 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos5 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos6 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos7 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos8 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos9 = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CardPos10 = nil
		--tracks joker slots (i think)
		
		BalatroJokers.SaveShitNow.GetRunSave(player).BJokerAmount = 0
		BalatroJokers.SaveShitNow.GetRunSave(player).HeartCount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).CoinCount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).KeyCount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).BombCount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Jolly = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Wily = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).HalfJokerAmount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).StencilActive = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).MarbleEnabled = false
		BalatroJokers.SaveShitNow.GetRunSave(player).MisprintMult = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).RaisedFistBonus = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).FibonacciActive = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).ChampKC_Scary = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).HackAmount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).GrosActive = false
		BalatroJokers.SaveShitNow.GetRunSave(player).BlackboardBonus = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).BlueAmount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).SquareEnabled = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).VampireAmount = nil
		BalatroJokers.SaveShitNow.GetRunSave(player).HoloBonus = nil
		--Tracks joker effects

       BalatroJokers.SaveShitNow.GetRunSave(player).InitShitLater = true
        end
    end
end
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, mod.InitShitLater)
--Initiates things later after SM is loaded; Now we can initiate all player datas safely.

function mod:Restart(IsContinued)

	JokerHUD = Sprite()
	JokerHUD:Load("gfx/ui/cardfronts.anm2", true)

	--SpawnFromBoss = 0 --jimbo packs/jokers from bosses is reset after new room/game
	
	if IsContinued == false then --if new game
	if RunData and RoomData then
	RoomData.SpawnFromBoss = 0
		BalatroJokers.SaveShitNow.GetRunSave(player).JimboCount = 0
		--This thing lets you save entity data, such as familiars, and players.
		BalatroJokers.SaveShitNow.GetRunSave().RoomClearTimer = 0
		BalatroJokers.SaveShitNow.GetRunSave().RoomChestCount = 0
		BalatroJokers.SaveShitNow.GetRoomSave().ValidPackCards = 0
		BalatroJokers.SaveShitNow.GetRunSave().HieroActivated = 0
		BalatroJokers.SaveShitNow.GetRunSave().RedDeckActive = 0
		BalatroJokers.SaveShitNow.GetRunSave().GreenDeckActive = 0
		BalatroJokers.SaveShitNow.GetRunSave().RocketBonus = 1
		BalatroJokers.SaveShitNow.GetRoomSave().BoughtPickupVar = 0 --this value is not saved, reset on new game and new room
		
		if not BalatroJokers.SaveShitNow.GetRunSave().SCAllowSpawn then
		BalatroJokers.SaveShitNow.GetRunSave().SCAllowSpawn = true
		end

	end
	end
end
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, mod.Restart)

if RunData then
local SCAllowSpawn = BalatroJokers.SaveShitNow.GetRunSave().SCAllowSpawn
end

function mod:NewRoom()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if RoomData and RunData then
	RoomData.SpawnFromBoss = 0 --jimbo packs/jokers from bosses is reset after new room/game
	
	RoomData.RoomChestCount = 0
	RoomData.ValidPackCards = 0
	
	if BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Jolly ~= nil then
		BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Jolly = 0
	end
	if BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Wily ~= nil then
		BalatroJokers.SaveShitNow.GetRunSave(player).RoomKC_Wily = 0
	end
	
	if BalatroJokers.SaveShitNow.GetRunSave(player).MisprintMult ~= nil then
		BalatroJokers.SaveShitNow.GetRunSave(player).MisprintMult = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(15)*0.1 --RNG value seeded; Uses Jimbo's ID (dynamic) as seed
	end
	
	if BalatroJokers.SaveShitNow.GetRunSave(player).RaisedFistBonus ~= nil then
            BalatroJokers.SaveShitNow.GetRunSave(player).RaisedFistBonus = math.min(player:GetNumCoins(), player:GetNumBombs(), player:GetNumKeys())*0.1 --Work smart, not hard
	end
	
	if BalatroJokers.SaveShitNow.GetRunSave(player).BlackboardBonus ~= nil then
		if player:GetNumKeys() == player:GetNumBombs() and player:GetNumKeys() == player:GetNumCoins() and 
		player:GetNumBombs() == player:GetNumKeys() and player:GetNumBombs() == player:GetNumCoins() and 
		player:GetNumCoins() == player:GetNumKeys() and player:GetNumCoins() == player:GetNumBombs() then
			BalatroJokers.SaveShitNow.GetRunSave(player).BlackboardBonus = 1.4
		else
			BalatroJokers.SaveShitNow.GetRunSave(player).BlackboardBonus = 0
		end
	end
	
	local roomt = Game():GetRoom():GetType()
	
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.double_stakes) == true and (roomt == RoomType.ROOM_ANGEL or roomt == RoomType.ROOM_DEVIL) then --DOUBLE STAKES FUNCTION
		for i = 1, player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.double_stakes) do
		
		local cardforsaletypeA = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(6)
		local cardforsaletypeB = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(6)
		local PCards = BalatroJokers.Enums.PCards
		
		if cardforsaletypeA == 1 then --JOKER
			cardforsaleA = FirstJoker + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(LastJoker - FirstJoker)
		elseif cardforsaletypeA == 2 then --PLANET
			cardforsaleA = BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto)
		elseif cardforsaletypeA == 3 then --PLAYING
			cardforsaleA = (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ])
		elseif cardforsaletypeA == 4 then --TAROT
			cardforsaleA = 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22)
		elseif cardforsaletypeA == 5 then --SPECIAL
			cardforsaleA = 42 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(13)
		end
		
		if cardforsaletypeB == 1 then --JOKER
			cardforsaleB = FirstJoker + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(LastJoker - FirstJoker)
		elseif cardforsaletypeB == 2 then --PLANET
			cardforsaleB = BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto)
		elseif cardforsaletypeB == 3 then --PLAYING
			cardforsaleB = (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ])
		elseif cardforsaletypeB == 4 then --TAROT
			cardforsaleB = 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22)
		elseif cardforsaletypeB == 5 then --SPECIAL
			cardforsaleB = 42 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(13)
		end
		
		if player:HasTrinket(BalatroJokers.Enums.Trinkets.clearance_voucher) == true then
			local DAfirstcard = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, cardforsaleA, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(260,270),1),0,true,false), Vector(0,0), nil)
			local DAsecondcard = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, cardforsaleB, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(380,270),1),0,true,false), Vector(0,0), nil)
			
			DAfirstcard:ToPickup().AutoUpdatePrice = false
			DAsecondcard:ToPickup().AutoUpdatePrice = false
			DAfirstcard:ToPickup().Price = 3
			DAsecondcard:ToPickup().Price = 3
		else
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, cardforsaleA, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(250,250),1),0,true,false), Vector(0,0), nil):ToPickup().Price = 5
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, cardforsaleB, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(Vector(390,250),1),0,true,false), Vector(0,0), nil):ToPickup().Price = 5
		end
		
		end
	end
	
	RoomData.BoughtPickupVar = 0 --this value is not saved, reset on new game and new room
	SCAllowSpawn = true
	
	player:AddCacheFlags(CacheFlag.CACHE_ALL)
	player:EvaluateItems()
	
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.NewRoom)

function mod:NewFloor()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	if FloorData then
	FloorData.HieroActivated = 0
	FloorData.RedDeckActive = 0
	FloorData.GreenDeckActive = 0
	
	--[[
	UsedJokerAmount = 0
	CardPos1 = nil
	CardPos2 = nil
	CardPos3 = nil
	CardPos4 = nil
	CardPos5 = nil
	
	-- JOKER STATS
	
	JokerVars = {
	--["BJokerAmount"] = 0,
	--["HeartCount"] = nil,
	--["CoinCount"] = nil,
	--["KeyCount"] = nil,
	--["BombCount"] = nil,
	--["RoomKC_Jolly"] = nil,
	--["RoomKC_Wily"] = nil,
	--["HalfJokerAmount"] = nil,
	--["StencilActive"] = nil,
	--["MarbleEnabled"] = false,
	--["MisprintMult"] = nil,
	--["RaisedFistBonus"] = nil,
	--["FibonacciActive"] = nil,
	--["ChampKC_Scary"] = nil,
	--["HackAmount"] = nil,
	--["GrosActive"] = false,
	--["BlackboardBonus"] = nil,
	--["BlueAmount"] = nil,
	--["SquareEnabled"] = nil,
	--["VampireAmount"] = nil,
	--["HoloBonus"] = nil,
	}
	--]]
	
	player:AddCacheFlags(CacheFlag.CACHE_ALL)
	player:EvaluateItems()
	--[[
	if player:GetCard(0) == Egg then --DESTROY THE GODDAMN EGG
		player:SetCard(0, 0)
		player:AnimateSad()
	elseif player:GetCard(1) == Egg then
		player:SetCard(1, 0)
		player:AnimateSad()
	end
	--]]
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.cheap_suit) == true then --CHEAP SUIT FUNCTION
	for i = 1, player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.cheap_suit) do
		player:UseCard(FirstJoker + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(LastJoker - FirstJoker), UseFlag.USE_MIMIC)
	end
		
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.NewFloor)

----------------------------------------- JIMBO ITEM

--REMOVED THE EFFECT OF TRINKETS BEING REPLACED WITH VOUCHERS WITH JIMBO EQUIPPED

--[[

function mod:ManageVoucherSpawns(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	if player:HasCollectible(jimbos_collection) == true then
		
		TurnIntoVoucher = math.random(20)
		
		if TurnIntoVoucher == 10 then
		entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 350, (AllVouchers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllVouchers)]), true)
		end
		
	else
	
	--REMOVED THE EFFECT OF VOUCHERS ONLY BEING ABLE TO SPAWN WITH JIMBO EQUIPPED
	
		if (entity.SubType >= torn_voucher and entity.SubType <= torn_voucher+(#AllVouchers)-1) then

			entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 350, math.random(189), true)
		end
	
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.ManageVoucherSpawns, 350)

--]]

function mod:JimboShopPacks(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if player:HasCollectible(BalatroJokers.Enums.Items.jimbos_collection) and entity:IsShopItem() == true then
	
	local JimboPacks = BalatroJokers.Enums.BigBoosters
	local AllJokers = BalatroJokers.Enums.Jokers
	
	entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, (JimboPacks[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JimboPacks) ]), 1, true)
	
end

if player:HasTrinket(BalatroJokers.Enums.Trinkets.clearance_voucher) == true and entity:IsShopItem() == true then --CLEARANCE VOUCHER FUNCTION
	entity:ToPickup().AutoUpdatePrice = false
	entity:ToPickup().Price = 3
end
	
if player:HasTrinket(BalatroJokers.Enums.Trinkets.card_house) == true and entity.SpawnerType ~= EntityType.ENTITY_PLAYER and entity.SubType <= 97 then --CARD HOUSE FUNCTION
	local chousechance = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5)
	if chousechance <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.card_house) then
	entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, (AllJokers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), true)
	end
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.JimboShopPacks, 300)

function mod:CheckGridRock(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

	if player:HasTrinket(BalatroJokers.Enums.Trinkets.stone_card) == true then
		for i = 1, Game():GetRoom():GetGridSize() do
			local tintedrock = Game():GetRoom():GetGridEntity(i)
			if tintedrock ~= nil and tintedrock:GetType() == 4 and tintedrock.State == 2 and SCAllowSpawn == true then --this only happens once but whatever, should be good enough
				SCAllowSpawn = false
				SCMult = player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.stone_card)*3
				SCRoll = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(10)
				if SCRoll >= SCMult+1 and SCRoll <= SCMult+2 then
					Isaac.Spawn(EntityType.ENTITY_PICKUP, deck_pack, 1, tintedrock.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
				elseif SCRoll <= SCMult then
				local AllVouchers = BalatroJokers.Enums.Vouchers
					Isaac.Spawn(EntityType.ENTITY_PICKUP, 350, (AllVouchers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllVouchers)]), tintedrock.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
				end
			end
		end
	end
	
	if entity.Type == EntityType.ENTITY_PICKUP and entity.Variant == PickupVariant.PICKUP_TRINKET and entity.SubType == stone_card and entity.SpawnerType == EntityType.ENTITY_PLAYER then
		Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), nil):ToEffect().SpriteScale = Vector(0.8, 0.8)
		SFXManager():Play(137, 1, 0, false, 1.2)
		for i = 1, 6 do
		local SCrocksbig = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCK_PARTICLE , 0, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		SCrocksbig:ToEffect().Color = Color(0.6,0.6,0.6,0.8)
		SCrocksbig:ToEffect().SpriteScale = Vector(0.6, 0.6)
		end
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_POST_ENTITY_REMOVE, mod.CheckGridRock)

function mod:DestroyTrinket(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if entity.SubType == BalatroJokers.Enums.Trinkets.stone_card and entity.SpawnerType == EntityType.ENTITY_PLAYER then
	--entity:Remove()
	entity:ToPickup().Timeout = 90
	--entity.Color = Color(1,1,1,0.8)
	SFXManager():Play(137, 0.8, 0, false, 1)
	for i = 1, 4 do
	local SCrocks = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCK_PARTICLE , 0, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	SCrocks:ToEffect().Color = Color(0.6,0.6,0.6,0.6)
	SCrocks:ToEffect().SpriteScale = Vector(0.4, 0.4)
	end
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.DestroyTrinket, 350)

----------------------------------------- VOUCHER REPLACE

function mod:PreReward(rng)
if RunData then
	BalatroJokers.SaveShitNow.GetRunSave().RoomClearTimer = 5
end	
end

mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.PreReward)

function mod:ReplacePickup(entity)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if RunData then
local AllVouchers = BalatroJokers.Enums.Vouchers
local RoomClearTimer = BalatroJokers.SaveShitNow.GetRunSave().RoomClearTimer
if (player:GetTrinket(0) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(0) <= BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1)
or (player:GetTrinket(1) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(1) <= BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1) then

	if RoomClearTimer == 5 and RoomClearTimer > 0 then
	RoomClearTimer = RoomClearTimer - 1
	end
	
	if entity.FrameCount <= 5 and RoomClearTimer ~= 0 then
		RoomClearTimer = 0
		local PackReplaceChance = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11)
		local VoucherAmount = (player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.torn_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.seed_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.overstock_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.magic_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.clearance_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.reroll_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hieroglyph_voucher))
		
		--print(player:GetTrinketRNG(torn_voucher):RandomInt(9))
		if PackReplaceChance <= 1*VoucherAmount then --10% base chance, increased with trinket amount and boosters
			if entity.Variant == 10 or entity.Variant == 20 or entity.Variant == 30 or entity.Variant == 40 or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300 then
			Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player)
local AllPacksWeighted = BalatroJokers.Enums.WeightedBoosters
			entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, (AllPacksWeighted[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllPacksWeighted) ]), 1, true)
			
			end
		end
	end
	
end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.ReplacePickup)

----------------------------------------- EXTRA SPAWNS FROM CHESTS
 
function mod:CountChests(entity)
	if RunData then
	if RunData.RoomChestCount == nil then --for some reason this needs to be set here also
		RunData.RoomChestCount = 0
	end
	
	if entity.SubType == ChestSubType.CHEST_CLOSED then
			RunData.RoomChestCount = RunData.RoomChestCount + 1
			--print(RoomChestCount)
		else
			RunData.RoomChestCount = 0
		end
end
end
mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.CountChests, 50)

function mod:ExtraPack(entity, collider)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
local AllVouchers = BalatroJokers.Enums.Vouchers
if (player:GetTrinket(0) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(0) <=BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1) or (player:GetTrinket(1) >= BalatroJokers.Enums.Trinkets.torn_voucher and player:GetTrinket(1) <= BalatroJokers.Enums.Trinkets.torn_voucher+(#AllVouchers)-1) then
	
	if RunData then
	local RoomChestCount = RunData.RoomChestCount
	local sprite = entity:GetSprite()
	
	if entity.SubType == ChestSubType.CHEST_OPENED and RoomChestCount > 0 and sprite:GetFrame() == 1 and collider:ToPlayer() ~= nil then
		
		local VoucherAmount = (player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.torn_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.seed_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hone_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.overstock_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.magic_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.clearance_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.reroll_voucher)
		+player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.hieroglyph_voucher))
		
		local VoucherExtraPackChance = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(7)
		
		if VoucherExtraPackChance <= 1+VoucherAmount then --33% base chance, increased with trinket amount and boosters
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP,  (AllPacksWeighted[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllPacksWeighted) ]), 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			
			RoomChestCount = RoomChestCount-1
			--print(RoomChestCount)
		end
	
	end
	
end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.ExtraPack, 50)

----------------------------------------- MAGIC VOUCHER

function mod:CheckShopItem(entity, collider)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if player:HasTrinket(BalatroJokers.Enums.Trinkets.magic_voucher) and entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price and collider:ToPlayer() ~= nil and player:IsHoldingItem() == false then
	
	local SpawnExtraMagic = 0
	
	if math.random(3) == 1 then
		if entity.Variant == 10 and (entity.SubType == 1 or entity.SubType == 5) and player:CanPickRedHearts() == true then --if red heart
			SpawnExtraMagic = 1
		elseif entity.Variant == 10 and entity.SubType == 3 and player:CanPickSoulHearts() == true then --if blue heart
			SpawnExtraMagic = 1
		elseif entity.Variant == 90 and player:NeedsCharge() == true then
			SpawnExtraMagic = 1
		elseif entity.Variant ~= 10 and entity.Variant ~= 90 then
			SpawnExtraMagic = 1
		end
	end
	
	if SpawnExtraMagic == 1 then
		local randomdeckcard = (BalatroJokers.Enums.Decks[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.Decks) ])
		--Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, randomdeckcard, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		Isaac.Spawn(EntityType.ENTITY_PICKUP, BalatroJokers.Enums.ExtraPacks.deck_pack, 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		
		SpawnExtraMagic = 0
	end
	
end

end
end

mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.CheckShopItem)

----------------------------------------- PLANET CARDS FUNC

function mod:PlanetSFX()
	--SFXManager():Play(545, 1, 0, false, 0.1*math.random(15,20))
	--disabled for now, custom voicelines overlap with this sfx
end

function mod:UsePlanetCard(card)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	local ChancePlanetariumItem = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11)
	
	if card == BalatroJokers.Enums.Planets.Pluto then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_PLUTO, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_PLUTO, player.Position, false) --:ToFamiliar():SetColor(Color(0,1,1,0.3,0,1,1,0.3),0,0,false,false)
		end
		mod:PlanetSFX()
		SFXManager():Play(PlutoSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Mercury then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_MERCURIUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_MERCURIUS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(MercurySFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Uranus then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_URANUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_URANUS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(UranusSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Venus then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_VENUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_VENUS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(VenusSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Saturn then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_SATURNUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_SATURNUS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(SaturnSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Jupiter then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_JUPITER, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_JUPITER, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(JupiterSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Earth then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_TERRA, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_TERRA, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(EarthSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Mars then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_MARS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_MARS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(MarsSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Planets.Neptune then
		if ChancePlanetariumItem == 5 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_NEPTUNUS, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		else
			player:AddItemWisp(CollectibleType.COLLECTIBLE_NEPTUNUS, player.Position, false)
		end
		mod:PlanetSFX()
		SFXManager():Play(NeptuneSFX, 1, 0, false, 1)
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UsePlanetCard)

--[[ REVEAL SECRET ROOMS
 for i = 0, level:GetRoomCount() - 1 do
        local room = level:GetRooms():Get(i)
        local roomType = room.Data.Type

        if roomType == RoomType.ROOM_SECRET or roomType == RoomType.ROOM_SUPERSECRET or roomType == RoomType.ROOM_ULTRASECRET then
            local roomIndex = level:QueryRoomTypeIndex(roomType, true, RNG(), true)
            local secretRoom = level:GetRoomByIdx(roomIndex)

            secretRoom.DisplayFlags = 100
            level:UpdateVisibility(true)
            revealed = true
        end
    end
--]]

----------------------------------------- DECK CARDS FUNC

function mod:UseDeckCard(card)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
if RunData then
	if card == BalatroJokers.Enums.Decks.RedDeck then
		RunData.RedDeckActive = RunData.RedDeckActive+1
		SFXManager():Play(RedCardSFX, 1, 0, false, 1)
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
				Game():GetLevel():RemoveCurses(LevelCurse.CURSE_OF_DARKNESS | LevelCurse.CURSE_OF_THE_LOST | LevelCurse.CURSE_OF_THE_UNKNOWN | LevelCurse.CURSE_OF_MAZE | LevelCurse.CURSE_OF_BLIND)
				SFXManager():Play(268, 0.6, 0, false, 1)
				player:AnimateHappy()
			end
	elseif card == BalatroJokers.Enums.Decks.BlueDeck then
		player:GetEffects():AddCollectibleEffect(CollectibleType.COLLECTIBLE_20_20, false, 1)
		SFXManager():Play(BlueCardSFX, 1, 0, false, 1)
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_DIPLOPIA, false, false, true, false, -1, 0)
			SFXManager():Play(268, 0.6, 0, false, 1)
			player:AnimateHappy()
		end
	elseif card == BalatroJokers.Enums.Decks.YellowDeck then
		SFXManager():Play(YellowCardSFX, 1, 0, false, 1)
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
		local YellowDeckItems = BalatroJokers.Enums.YellowDeckItems 
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, (YellowDeckItems[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#YellowDeckItems) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
			SFXManager():Play(268, 0.6, 0, false, 1)
			player:AnimateHappy()
		end
		for i = 1, 10 do
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
	elseif card == BalatroJokers.Enums.Decks.GreenDeck then
		GreenDeckActive = GreenDeckActive+1
		SFXManager():Play(GreenCardSFX, 1, 0, false, 1)
	elseif card == BalatroJokers.Enums.Decks.BlackDeck then
		SFXManager():Play(BlackCardSFX, 1, 0, false, 1)
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity.Type == EntityType.ENTITY_PICKUP and ((entity.Variant >= 10 and entity.Variant <= 40) or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300) then
				if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
					entity:ToPickup().Timeout = -1
					local AllJokers = BalatroJokers.Enums.Jokers
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, (AllJokers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), true)
					Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
					player:AnimateHappy()
				else
					entity:Remove()
					Isaac.Spawn(EntityType.ENTITY_EFFECT, BalatroJokers.Enums.Effects.Nope_Effect , 0, entity.Position, Vector(0, 0), player)
					--player:AnimateSad()
				end
			end
		end
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseDeckCard)

function mod:RedDeckFunc(enemy)
if RunData then
local RedDeckActive = RunData.RedDeckActive
	if RedDeckActive ~= nil then --i'm checking for this case because for some reason despite setting it to 0 at game start, it still returns nil... bruh
		if RedDeckActive >= 1 and Isaac.CountEnemies() <= RedDeckActive and Isaac.CountBosses() == 0 then
			if enemy:IsVulnerableEnemy() then
				enemy:Die()
				Isaac.Spawn(EntityType.ENTITY_EFFECT, Jimbo_Effect , 0, enemy.Position, Vector(0, 0), nil)
				--SFXManager():Play(169, 0.8, 0, false, 0.8)
				SFXManager():Play(BalatroJokers.Enums.SFX.JimboSFX, 0.8, 0, false, player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5)*0.1 + 0.9)
			end
		end
	end
end	
end
mod:AddCallback(ModCallbacks.MC_NPC_UPDATE, mod.RedDeckFunc)

function mod:GreenDeckFunc()
local roomt = Game():GetRoom():GetType()
if RunData then
local GreenDeckActive = RunData.GreenDeckActive
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

	if GreenDeckActive >= 1 then
		for i = 1, GreenDeckActive do
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
		if roomt == RoomType.ROOM_BOSS then
			if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
				for i = 1, (player:GetNumCoins()-1)*GreenDeckActive do
					Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,300),0,true,false), Vector(0,0), nil)
					SFXManager():Play (268, 0.6, 0, false, 1)
					player:AnimateHappy()
				end
				GreenDeckActive = 0
			end
		end
	end
end	
end
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.GreenDeckFunc)

-------------------------- JOKER CARD FUNC

function mod:UseJokerCard(card, player, useflags) --BRUH
if RunData then

	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	if card == BalatroJokers.Enums.Jokers.BJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.BJokerSFX, 1, 0, false, 1)
		RPData.BJokerAmount = RPData.BJokerAmount + 1
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.GreedyJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.GreedyJokerSFX, 1, 0, false, 1)
		if RPData.CoinCount == nil then
			RPData.CoinCount = 0
		else
			RPData.CoinCount = RPData.CoinCount*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.LustyJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.LustyJokerSFX, 1, 0, false, 1)
		if RPData.HeartCount == nil then
			RPData.HeartCount = 0
		else
			RPData.HeartCount = RPData.HeartCount*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.WrathfulJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.WrathfulJokerSFX, 1, 0, false, 1)
		if RPData.KeyCount == nil then
			RPData.KeyCount = 0
		else
			RPData.KeyCount = RPData.KeyCount*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.GluttonousJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.GluttonousJokerSFX, 1, 0, false, 1)
		if RPData.BombCount == nil then
			RPData.BombCount = 0
		else
			RPData.BombCount = RPData.BombCount*2
		end
	elseif card == BalatroJokers.Enums.Jokers.JollyJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.JollyJokerSFX, 1, 0, false, 1)
		if RPData.RoomKC_Jolly == nil then
			RPData.RoomKC_Jolly = 0
		elseif RPData.RoomKC_Jolly >= 0 then
			RPData.RoomKC_Jolly = RPData.RoomKC_Jolly*2
		end
	elseif card == BalatroJokers.Enums.Jokers.WilyJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.WilyJokerSFX, 1, 0, false, 1)
		if RPData.RoomKC_Wily == nil then
			RPData.RoomKC_Wily = 0
		elseif RPData.RoomKC_Wily >= 0 then
			RPData.RoomKC_Wily = RPData.RoomKC_Wily*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.HalfJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.HalfJokerSFX, 1, 0, false, 1)
		if RPData.HalfJokerAmount == nil then
			RPData.HalfJokerAmount = 0
		elseif RPData.HalfJokerAmount > 0 then
			RPData.HalfJokerAmount = RPData.HalfJokerAmount*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.JokerStencil then
		SFXManager():Play(BalatroJokers.Enums.SFX.JokerStencilSFX, 1, 0, false, 1)
		if RPData.StencilActive == nil then
			RPData.StencilActive = 1
		elseif RPData.StencilActive >= 1 then
			RPData.StencilActive = RPData.StencilActive*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.Mime then
		SFXManager():Play(BalatroJokers.Enums.SFX.MimeSFX, 1, 0, false, 1)
		if player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= 0 and player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= CollectibleType.COLLECTIBLE_BLANK_CARD then
			player:UseActiveItem(player:GetActiveItem(ActiveSlot.SLOT_PRIMARY), false, false, true, false, -1, 0)
		--elseif player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= 0 and player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) == CollectibleType.COLLECTIBLE_BLANK_CARD then
			--Game():ChangeRoom(Game():GetLevel():GetRandomRoomIndex(true, 0), -1)
			--Game():MoveToRandomRoom(true, 0, player)
		end
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(2) == 1 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, Mime, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
	elseif card == BalatroJokers.Enums.Jokers.MarbleJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.MarbleJokerSFX, 1, 0, false, 1)
		if RPData.MarbleEnabled ~= true then
			RPData.MarbleEnabled = true
		end
			local entities = Isaac.GetRoomEntities()
			for i, entity in ipairs(entities) do
				if entity:IsVulnerableEnemy() then
				entity:AddFreeze(EntityRef(player), 30)
				--entity:SetColor(Color(0.45,0.48,0.45,1),120,1,false,false)
				end
			end
	elseif card == BalatroJokers.Enums.Jokers.EightBall then
		SFXManager():Play(BalatroJokers.Enums.SFX.EightBallSFX, 1, 0, false, 1)
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(3) == 1 then
			for i = 1, 8 do
				Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22)+1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
			end
		end
		if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(3) == 1 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 100, CollectibleType.COLLECTIBLE_TAROT_CLOTH, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
	elseif card == BalatroJokers.Enums.Jokers.Misprint then
		SFXManager():Play(BalatroJokers.Enums.SFX.MisprintSFX, 1, 0, false, 1)
		if RPData.MisprintMult == nil then
			RPData.MisprintMult = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(24)*0.1
		elseif RPData.MisprintMult >= 1 then
			RPData.MisprintMult = RPData.MisprintMult*2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.RaisedFist then
		SFXManager():Play(BalatroJokers.Enums.SFX.RaisedFistSFX, 1, 0, false, 1)
		if RPData.RaisedFistBonus == nil then
			if player:GetNumKeys() <= player:GetNumBombs() and player:GetNumKeys() <= player:GetNumCoins() then
				RPData.RaisedFistBonus  = player:GetNumKeys()*0.1
			elseif player:GetNumBombs() <= player:GetNumKeys() and player:GetNumBombs() <= player:GetNumCoins() then
				RPData.RaisedFistBonus = player:GetNumBombs()*0.1
			elseif player:GetNumCoins() <= player:GetNumBombs() and player:GetNumCoins() <= player:GetNumKeys() then
				RPData.RaisedFistBonus  = player:GetNumCoins()*0.1
			end
		elseif RPData.RaisedFistBonus  >= 0.1 then
			RPData.RaisedFistBonus  = RPData.RaisedFistBonus *2
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.Fibonacci then
		SFXManager():Play(BalatroJokers.Enums.SFX.FibonacciSFX, 1, 0, false, 1)
		if RPData.FibonacciActive == nil then
			RPData.FibonacciActive = 1
		elseif RPData.FibonacciActive ~= nil then
			RPData.FibonacciActive = RPData.FibonacciActive*2
		end
	elseif card == BalatroJokers.Enums.Jokers.ScaryFace then
		SFXManager():Play(BalatroJokers.Enums.SFX.ScaryFaceSFX, 1, 0, false, 1)
		if RPData.ChampKC_Scary == nil then
			RPData.ChampKC_Scary = 0
		elseif RPData.ChampKC_Scary >= 0 then
			RPData.ChampKC_Scary = RPData.ChampKC_Scary*2
		end
	elseif card == BalatroJokers.Enums.Jokers.Hack then
		SFXManager():Play(BalatroJokers.Enums.SFX.HackSFX, 1, 0, false, 1)
		if RPData.HackAmount == nil then
			RPData.HackAmount = 0
		elseif RPData.HackAmount >= 0 then
			RPData.HackAmount = RPData.HackAmount*2
		end
	elseif card == BalatroJokers.Enums.Jokers.GrosMichel then
		SFXManager():Play(BalatroJokers.Enums.SFX.GrosMichelSFX, 1, 0, false, 1)
		Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.BLOOD_SPLAT, 0, player.Position, Vector(0, 0), player):ToEffect():SetColor(Color(0.85,0.75,0.05,0.35,0.85,0.75,0.05,0.25),0,1,false,false)
	elseif card == BalatroJokers.Enums.Jokers.Supernova then
		SFXManager():Play(BalatroJokers.Enums.SFX.SupernovaSFX, 1, 0, false, 1)
		for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, -1, -1, false, false)) do
			if Isaac.GetItemConfig():GetCollectible(entity.SubType):HasTags(ItemConfig.TAG_QUEST) ~= true and entity.Variant == PickupVariant.PICKUP_COLLECTIBLE then
					local ItemQual = Isaac.GetItemConfig():GetCollectible(entity.SubType).Quality
				if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11) <= math.ceil(ItemQual*2.5) then
				--math.random(588,598) should be now changed to include all planetarium items. Treat modded Planetarium items as Planet X lmao perhaps :troll:
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 100, 588+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11), true)
					Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
					player:AnimateHappy()
				else
					for i = 1, ItemQual do
						Isaac.Spawn(EntityType.ENTITY_PICKUP, (BalatroJokers.Enums.PlanetPacks[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.PlanetPacks) ]), 1, entity.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
					end
					entity:Remove()
					player:AnimateHappy()
				end
			elseif entity.Variant == 10 or entity.Variant == 20 or entity.Variant == 30 or entity.Variant == 40 or entity.Variant == 70 or entity.Variant == 90 or entity.Variant == 300 then
				entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), true)
				player:AnimateHappy()
			end
		end
	elseif card == BalatroJokers.Enums.Jokers.SpaceJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.SpaceJokerSFX, 1, 0, false, 1)
		local HeldTrinketA = player:GetTrinket(0)
		local HeldTrinketB = player:GetTrinket(1)
		for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, 350, -1, false, false)) do
			if entity.SubType < TrinketType.TRINKET_GOLDEN_FLAG then
				entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 350, entity.SubType + TrinketType.TRINKET_GOLDEN_FLAG, true, true)
				player:AnimateHappy()
			end
		end
		if HeldTrinketA ~= 0 and player:GetTrinket(0) < TrinketType.TRINKET_GOLDEN_FLAG then
			player:TryRemoveTrinket(HeldTrinketA)
			player:AddTrinket(HeldTrinketA | TrinketType.TRINKET_GOLDEN_FLAG)
			player:AnimateHappy()
		end
		if HeldTrinketB ~= 0 and player:GetTrinket(0) < TrinketType.TRINKET_GOLDEN_FLAG then
			player:TryRemoveTrinket(HeldTrinketB)
			player:AddTrinket(HeldTrinketB | TrinketType.TRINKET_GOLDEN_FLAG)
			player:AnimateHappy()
		end
	elseif card == BalatroJokers.Enums.Jokers.Egg then
		SFXManager():Play(BalatroJokers.Enums.SFX.EggSFX, 1, 0, false, 1)
		for i = 1, 3 do
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, (BalatroJokers.Enums.SeedCoins[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.SeedCoins) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
	elseif card == BalatroJokers.Enums.Jokers.Blackboard then
		SFXManager():Play(BalatroJokers.Enums.SFX.BlackboardSFX, 1, 0, false, 1)
		if RPData.BlackboardBonus == nil then
			if player:GetNumKeys() == player:GetNumBombs() and player:GetNumKeys() == player:GetNumCoins() and 
			player:GetNumBombs() == player:GetNumKeys() and player:GetNumBombs() == player:GetNumCoins() and 
			player:GetNumCoins() == player:GetNumKeys() and player:GetNumCoins() == player:GetNumBombs() then
				RPData.BlackboardBonus = 1.5
			else
				RPData.BlackboardBonus = 0
			end
		elseif RPData.BlackboardBonus >= 1 then
				RPData.BlackboardBonus = RPData.BlackboardBonus*2
		end
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.BlueJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.BlueJokerSFX, 1, 0, false, 1)
		if RPData.BlueAmount == nil then
			RPData.BlueAmount = 0
		end
		if RPData.BlueAmount >= 0 then
			for i, entity in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, 300, -1, false, false)) do
				Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
				entity:Remove()
				RPData.BlueAmount = RPData.BlueAmount + 1
				player:AnimateHappy()
			end
		end
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	elseif card == BalatroJokers.Enums.Jokers.SquareJoker then
		SFXManager():Play(BalatroJokers.Enums.SFX.SquareJokerSFX, 1, 0, false, 1)
		if RPData.SquareEnabled == nil then
			RPData.SquareEnabled = 0
		end
	elseif card == BalatroJokers.Enums.Jokers.RiffRaff then
		SFXManager():Play(BalatroJokers.Enums.SFX.RiffRaffSFX, 1, 0, false, 1)
		if Game():GetRoom():GetType() == RoomType.ROOM_BOSS or Game():GetRoom():GetType() == RoomType.ROOM_MINIBOSS or Game():GetRoom():GetType() == RoomType.ROOM_BOSSRUSH then
			for i = 1, 2 do
			local AllJokers = BalatroJokers.Enums.Jokers
				Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (AllJokers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
			end
		end
	elseif card == BalatroJokers.Enums.Jokers.Vampire then
		SFXManager():Play(BalatroJokers.Enums.SFX.VampireSFX, 1, 0, false, 1)
		if RPData.VampireAmount == nil then
			RPData.VampireAmount = 0
		end
	elseif card == BalatroJokers.Enums.Jokers.Vagabond then
		SFXManager():Play(BalatroJokers.Enums.SFX.VagabondSFX, 1, 0, false, 1)
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 5, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
	elseif card == BalatroJokers.Enums.Jokers.Rocket then
		SFXManager():Play(BalatroJokers.Enums.SFX.RocketSFX, 1, 0, false, 1)
		for i = 1, RunData.RocketBonus do
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, 1, Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,48),0,true,false), Vector(0,0), nil)
		end
		RunData.RocketBonus = 1
	elseif card == BalatroJokers.Enums.Jokers.Hologram then
		SFXManager():Play(BalatroJokers.Enums.SFX.HologramSFX, 1, 0, false, 1)
		if RPData.HoloBonus == nil then
			RPData.HoloBonus = 0
		elseif RPData.HoloBonus ~= nil then
			RPData.HoloBonus = RPData.HoloBonus*2
		end
	
	
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseJokerCard)

function mod:PickupCounter(entity, collider)

	local player = collider:ToPlayer()

	if player ~= nil then
	if RunData then
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
		if entity.Variant == 10 and RPData.HeartCount ~= nil then
			if entity.SubType == 5 and player:CanPickRedHearts() == true then
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RPData.HeartCount = RPData.HeartCount+4
				end
			elseif (entity.SubType == 1 and player:CanPickRedHearts() == true) or (entity.SubType == 3 and player:CanPickSoulHearts() == true) or (entity.SubType == 6 and player:CanPickBlackHearts() == true) or (entity.SubType == 9 and player:CanPickRedHearts() == true) or (entity.SubType == 10 and (player:CanPickRedHearts() == true or player:CanPickSoulHearts() == true)) then --if full red, full soul, full black, full scared or full blended
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RPData.HeartCount = RPData.HeartCount+2
				end
			elseif (entity.SubType == 7 and player:CanPickGoldenHearts() == true) or (entity.SubType == 11 and player:CanPickBoneHearts() == true) or (entity.SubType == 12 and player:CanPickRottenHearts() == true) then
				if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
					RPData.HeartCount = RPData.HeartCount+1
				end
			end
		elseif entity.Variant == 20 and RPData.CoinCount ~= nil and entity.SubType ~= 6 then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				RPData.CoinCount = RPData.CoinCount+entity:GetCoinValue()
			end
		elseif entity.Variant == 30 and RPData.KeyCount ~= nil then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				if entity.SubType == 3 then
					RPData.KeyCount = RPData.KeyCount+2
				else
					RPData.KeyCount = RPData.KeyCount+1
				end
			end
		elseif entity.Variant == 40 and RPData.BombCount ~= nil then
			if (entity:IsShopItem() == true and player:GetNumCoins() >= entity.Price) or entity:IsShopItem() == false then
				if entity.SubType == 2 then
					RPData.BombCount  = RPData.BombCount +2
				else
					RPData.BombCount = RPData.BombCount +1
				end
			end
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end

end
end


mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.PickupCounter)

function mod:CountKills(enemy)
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if RunData then
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	if RPData.RoomKC_Jolly ~= nil then
		if enemy:IsEnemy() == true then
			RPData.RoomKC_Jolly = RPData.RoomKC_Jolly+1
			
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:EvaluateItems()
		end
	end
	
	if RPData.RoomKC_Wily ~= nil then
		if enemy:IsEnemy() == true then
			RPData.RoomKC_Wily = RPData.RoomKC_Wily+1
			
			if RPData.RoomKC_Wily%3 == 0 and RPData.RoomKC_Wily~= 0 then
				player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
				player:EvaluateItems()
			end
			
		end
	end
	
	if RPData.ChampKC_Scary~= nil then
		if enemy:IsEnemy() == true and enemy:IsChampion() == true then
			RPData.ChampKC_Scary = RPData.ChampKC_Scary+1
			player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
			player:EvaluateItems()
		end
	end
	
	if RPData.VampireAmount ~= nil then
		if enemy:IsEnemy() == true then
			RPData.VampireAmount= RPData.VampireAmount+1
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:EvaluateItems()
		end
	end
	
end
end
end

mod:AddCallback(ModCallbacks.MC_POST_NPC_DEATH, mod.CountKills)

function mod:NPCCheck() --edge cases such as new spawns won't update the counter until an enemy is killed
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if RunData then
	 local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	if RPData.HalfJokerAmount ~= nil then
		if Isaac.CountEnemies() <= 4 and Isaac.CountEnemies() >= 1 then
			RPData.HalfJokerAmount = 1
			
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:EvaluateItems()
		elseif Isaac.CountEnemies() > 3 or Isaac.CountEnemies() == 0 then
			RPData.HalfJokerAmount = 0
			
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:EvaluateItems()
		end
	end
	
	if RPData.HackAmount ~= nil then
		if Isaac.CountEnemies() >= 2 and Isaac.CountEnemies() <= 5 then
			RPData.HackAmount = 1
		elseif Isaac.CountEnemies() < 2 or Isaac.CountEnemies() > 5 then
			RPData.HackAmount = 0
		end
	end
	end
end
end
mod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, mod.NPCCheck)
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.NPCCheck)

function mod:CheckTearsModif() --DON'T UNDERSTAND HOW TEARS UP WORKS SO I USE THIS TOTALLY UNNECESSARY FUNCTION
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	if player:HasCollectible(CollectibleType.COLLECTIBLE_SOY_MILK) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_ALMOND_MILK) == true then
		return 0.125
	elseif player:HasCollectible(CollectibleType.COLLECTIBLE_INNER_EYE) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_DR_FETUS) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_2) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_POLYPHEMUS) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_EVES_MASCARA) == true then --0.4-0.6 tears mult items
		return 1.33
	elseif player:HasCollectible(CollectibleType.COLLECTIBLE_BRIMSTONE) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_IPECAC) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_MONSTROS_LUNG) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_HAEMOLACRIA) == true then --0.2-0.4 tears mult items
		return 1.66
	elseif player:HasCollectible(CollectibleType.COLLECTIBLE_ANTI_GRAVITY) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_CRICKETS_BODY) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_MOMS_PERFUME) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_CAPRICORN) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_PISCES) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_EPIPHORA) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_TRACTOR_BEAM) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_PURITY) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_MILK) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_KIDNEY_STONE) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_DARK_PRINCES_CROWN) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_CAMO_UNDIES) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_BRITTLE_BONES) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_IT_HURTS) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_PASCHAL_CANDLE) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_WAVY_CAP) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_LUNA) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_EYE_DROPS) == true or 
	player:HasCollectible(CollectibleType.COLLECTIBLE_BLOODY_GUST) == true or player:HasCollectible(CollectibleType.COLLECTIBLE_BERSERK) == true or 
	player:HasTrinket(TrinketType.TRINKET_CANCER) == true then -- +0.5-1 fire rate
		return 0.55
	else
		return false
	end

end
end

function mod:CountDownNPC()
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	if RunData then
    local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	if RPData.SquareEnabled ~= nil then
	if Isaac.CountEnemies() == 0 and RPData.SquareEnabled ~= 0 then
		RPData.SquareEnabled = 0
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	elseif Isaac.CountEnemies() == 4 then
		if mod:CheckTearsModif() ~= false then
			RPData.SquareEnabled = 6.54*(mod:CheckTearsModif())
		else
			RPData.SquareEnabled = 6.54
		end
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	elseif Isaac.CountEnemies() ~= 4 and RPData.SquareEnabled >= 0.01 then
		--if player:HasCollectible(CollectibleType.COLLECTIBLE_SOY_MILK) == true then
		--	RPData.SquareEnabled = RPData.SquareEnabled-0.005
		--else
			RPData.SquareEnabled = RPData.SquareEnabled-0.01
		--end
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	end
	end
end
end
end

mod:AddCallback(ModCallbacks.MC_NPC_UPDATE, mod.CountDownNPC)

function mod:NPCHurtCheck(enemy, amount, DamageFlags, ref, CountdownFrames)
if RunData then

	
	
	    if enemy.Type ~= EntityType.ENTITY_PLAYER
    then
        local player = nil
        if
            (source ~= nil
            and source.Entity ~= nil
            and source.Entity.SpawnerEntity ~= nil
            and source.Entity.SpawnerEntity.Type == EntityType.ENTITY_PLAYER )
        then
            player = source.Entity.SpawnerEntity:ToPlayer()
        elseif
            (source ~= nil
            and source.Type == EntityType.ENTITY_PLAYER)
        then
            player = source.Entity:ToPlayer()
        end
        if player and BalatroJokers.SaveShitNow.GetRunSave(player).HackAmount and BalatroJokers.SaveShitNow.GetRunSave(player).HackAmount > 0 then
	
	if enemy:IsVulnerableEnemy() then
	local HackDmg = player.Damage* BalatroJokers.SaveShitNow.GetRunSave(player).HackAmount
	
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity:IsVulnerableEnemy() and DamageFlags & DamageFlag.DAMAGE_CLONES == 0 then
			entity:TakeDamage(HackDmg,DamageFlag.DAMAGE_CLONES,EntityRef(player),0)
			end
		end
	
	end
	
end
end
end
end
mod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, mod.NPCHurtCheck)

function mod:RoomClearReset()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	if BalatroJokers.SaveShitNow.GetRunSave(player).HalfJokerAmount~= nil then
		BalatroJokers.SaveShitNow.GetRunSave(player).HalfJokerAmount = 0
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.RoomClearReset)

function mod:GetCharge()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	if RPData.StencilActive ~= nil then
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.GetCharge)
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.GetCharge)
mod:AddCallback(ModCallbacks.MC_USE_ITEM, mod.GetCharge)

function mod:NewRoomJoker()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	local GrosMichel = BalatroJokers.Enums.Jokers.GrosMichel
	local Egg = BalatroJokers.Enums.Jokers.Egg

	if RPData.MarbleEnabled == true then
	local entities = Isaac.GetRoomEntities()

	for i, entity in ipairs(entities) do
		if entity:IsVulnerableEnemy() then
		entity:AddFreeze(EntityRef(player), 30)
		--entity:SetColor(Color(0.45,0.48,0.45,1),120,1,false,false)
		end
	end

	end
	
	if player:GetCard(0) == GrosMichel or player:GetCard(1) == GrosMichel then
		
		local groschance = 0
		
		if player:HasCollectible(CollectibleType.COLLECTIBLE_TAROT_CLOTH) == true then
			groschance =  player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(21)
		else
			groschance =  player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11)
		end
		
		if groschance == 5 and room:IsFirstVisit() == true then
			RPData.GrosActive = false
			player:UseCard(GrosMichel, UseFlag.USE_NOANIM)
			if player:GetCard(0) == GrosMichel then
				player:SetCard(0, 0)
			elseif player:GetCard(1) == GrosMichel then
				player:SetCard(1, 0)
			end
		else
			RPData.GrosActive = true
		end
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	
	if (player:GetCard(0) == Egg or player:GetCard(1) == Egg) and roomt == RoomType.ROOM_SHOP then --DESTROY THE GODDAMN EGG
		if player:GetCard(0) == Egg then
			player:SetCard(0, 0)
		elseif player:GetCard(1) == Egg then
			player:SetCard(1, 0)
		end
			player:AnimateSad()
	elseif (player:GetCard(0) == Egg or player:GetCard(1) == Egg) and room:IsFirstVisit() == true and (roomt ~= RoomType.ROOM_SHOP and roomt ~= RoomType.ROOM_DEFAULT and roomt ~= RoomType.ROOM_DUNGEON and roomt ~= RoomType.ROOM_GREED_EXIT and roomt ~= RoomType.ROOM_SECRET_EXIT) then
		for i = 1, 3 do
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, (BalatroJokers.Enums.SeedCoins[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.SeedCoins) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(player.Position,24),0,true,false), Vector(0,0), nil)
		end
	
	end
	
	if player:HasTrinket(BalatroJokers.Enums.Trinkets.first_edition) and roomt == RoomType.ROOM_SECRET and room:IsFirstVisit() == true then
		for i = 1, 3*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.first_edition) do
		local AllJokers = BalatroJokers.Enums.Jokers
			local spawnsecretjoker = Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (AllJokers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), Game():GetRoom():FindFreePickupSpawnPosition(Isaac.GetFreeNearPosition(room:GetCenterPos(),8),0,true,false), Vector(0,0), nil)
			spawnsecretjoker:ToPickup().Timeout = SpawnedPickupTimeout
			--local spritesecret = spawnsecretjoker:GetSprite()
			--spritesecret:Play("Appear", true)
			--spritesecret:Update()
		end
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.NewRoomJoker)

function mod:EnemyCheck()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	if Isaac.CountEnemies() ~= 4 and RPData.SquareEnabled ~= nil then
		RPData.SquareEnabled = 0
		player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		player:EvaluateItems()
	end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.EnemyCheck)
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.EnemyCheck)

function mod:VagabondUse()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	local Vagabond = BalatroJokers.Enums.Jokers.Vagabond
	
	if (player:GetCard(0) == Vagabond or player:GetCard(1) == Vagabond) and Isaac.CountEnemies() >= 1 and roomt ~= RoomType.ROOM_TREASURE and roomt ~= RoomType.ROOM_ERROR and roomt ~= RoomType.ROOM_SHOP and roomt ~= RoomType.ROOM_SECRET and roomt ~= RoomType.ROOM_SECRET_EXIT and roomt ~= RoomType.ROOM_LIBRARY and roomt ~= RoomType.ROOM_BLACK_MARKET and roomt ~= RoomType.ROOM_ULTRASECRET and roomt ~= RoomType.ROOM_DEVIL and roomt ~= RoomType.ROOM_ANGEL and roomt ~= RoomType.ROOM_DUNGEON then
		if player:GetNumCoins() <= 3 and room:IsFirstVisit() == true then
			player:UseCard(1+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22), 0)
		end
	end
	
end
end
end
--mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.VagabondUse)
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.VagabondUse)

function mod:RocketUp()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local room = Game():GetRoom()
	local roomt = Game():GetRoom():GetType()
	local Rocket = BalatroJokers.Enums.Jokers.Rocket
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	local RocketBonus = RunData.RocketBonus 
	
	if (player:GetCard(0) == Rocket or player:GetCard(1) == Rocket) and roomt == RoomType.ROOM_BOSS then
		RocketBonus = RocketBonus+2
		player:AddCoins(RocketBonus)
		SFXManager():Play(274, 1, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
	elseif player:GetCard(0) == Rocket or player:GetCard(1) == Rocket then --room:IsFirstVisit() == true
		player:AddCoins(RocketBonus)
		SFXManager():Play(234, 0.6, 0, false, (8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(5))*0.1)
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, mod.RocketUp)

function mod:UseCardBonus()
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)
	
	if RPData.HoloBonus ~= nil then
		RPData.HoloBonus = RPData.HoloBonus+1
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.UseCardBonus)

----------------------------------------- RENDER JOKERS

--[[
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! We'll be temporarily forgoing Joker renders in favor of Co-op support

function mod:RenderPos(card)
	
--TO TRIGGER, CARD HAS TO CHANGE A VARIABLE AND HAS TO BE ONE OF THE CARDS THAT CAN CHANGE THOSE VARIABLES, CHECKED IN TWO GROUPS
if ( RPData.BJokerAmount ~= 0 or RPData.HeartCount ~= nil or RPData.CoinCount ~= nil or RPData.KeyCount ~= nil or RPData.BombCount ~= nil or RPData.RoomKC_Jolly ~= nil or 
RPData.RoomKC_Wily ~= nil or   RPData.HalfJokerAmount ~= nil or RPData.StencilActive ~= nil or JokerVars["MarbleEnabled"] ~= false or RPData.MisprintMult ~= nil or RPData.RaisedFistBonus ~= nil or 
RPData.FibonacciActive ~= nil or RPData.ChampKC_Scary ~= nil or JokerVars["HackAmount"] ~= nil or RPData.BlackboardBonus ~= nil or RPData.BlueAmount ~= nil or RPData.SquareEnabled ~= nil or 
RPData.VampireAmount ~= nil or RPData.HoloBonus ~= nil or RedDeckActive ~= 0 or GreenDeckActive ~= 0 ) and 
( (card >= BJoker and card <= JokerStencil) or card == MarbleJoker or (card >= Misprint and card <= Hack) or (card >= Blackboard and card <= SquareJoker) or card == Vampire or card == Hologram or card == RedDeck or card == GreenDeck ) then
	UsedJokerAmount = UsedJokerAmount + 1
end

if ( (card >= BJoker and card <= JokerStencil) or card == MarbleJoker or (card >= Misprint and card <= Hack) or (card >= Blackboard and card <= SquareJoker) or card == Vampire or card == Hologram or card == RedDeck or card == GreenDeck ) then
	if UsedJokerAmount == 1 then
		--CardPos1 = Isaac.GetItemConfig():GetCard(card).HudAnim
		if card == RedDeck then
			CardPos1 = 29
		elseif card == GreenDeck then
			CardPos1 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos1 = card-112
		end
	elseif UsedJokerAmount == 2 then
		if card == RedDeck then
			CardPos2 = 29
		elseif card == GreenDeck then
			CardPos2 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos2 = card-112
		end
	elseif UsedJokerAmount == 3 then
		if card == RedDeck then
			CardPos3 = 29
		elseif card == GreenDeck then
			CardPos3 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos3 = card-112
		end
	elseif UsedJokerAmount == 4 then
		if card == RedDeck then
			CardPos4 = 29
		elseif card == GreenDeck then
			CardPos4 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos4 = card-112
		end
	elseif UsedJokerAmount == 5 then
		if card == RedDeck then
			CardPos5 = 29
		elseif card == GreenDeck then
			CardPos5 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos5 = card-112
		end
	elseif UsedJokerAmount == 6 then
		if card == RedDeck then
			CardPos6 = 29
		elseif card == GreenDeck then
			CardPos6 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos6 = card-112
		end
	elseif UsedJokerAmount == 7 then
		if card == RedDeck then
			CardPos7 = 29
		elseif card == GreenDeck then
			CardPos7 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos7 = card-112
		end
	elseif UsedJokerAmount == 8 then
		if card == RedDeck then
			CardPos8 = 29
		elseif card == GreenDeck then
			CardPos8 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos8 = card-112
		end
	elseif UsedJokerAmount == 9 then
		if card == RedDeck then
			CardPos9 = 29
		elseif card == GreenDeck then
			CardPos9 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos9 = card-112
		end
	elseif UsedJokerAmount == 10 then
		if card == RedDeck then
			CardPos10 = 29
		elseif card == GreenDeck then
			CardPos10 = 30
		elseif card >= BJoker and card <= Hologram then
			CardPos10 = card-112
		end
	
	end
end
	
end

mod:AddCallback(ModCallbacks.MC_USE_CARD, mod.RenderPos)

function mod:Render()
	
	if JokerHUD == nil then
		JokerHUD = Sprite()
		JokerHUD:Load("gfx/ui/cardfronts.anm2", true)
	end
	
	if UsedJokerAmount ~= 0 and UsedJokerAmount ~= nil then
	--CUTTED
	if Game():GetRoom():GetFrameCount()%60 <= 4 and Game():GetRoom():GetFrameCount() >= 4 then
			--JokerHUD.Scale = Vector(1.05, 1.05)
			--JokerHUD.Color = Color(0.35,0.35,0.35,1)
			--JokerHUD.Scale = JokerHUD.Scale+JokerHUD.Scale*0.01 --this shit keeps growing if you open the console at the exact time it's growing
			JokerHUD.Scale = Vector(1.04, 1.04)
			JokerHUD.Color = Color(0.31,0.31,0.31,1)
		else
			--Pos1Y = UIPos.POS1.Y
			JokerHUD.Scale = Vector(1, 1)
			JokerHUD.Color = Color(0.3,0.3,0.3,1)
	end
	--CUTTED
	
	JokerHUD.Scale = Vector(0.5, 0.5)
	
	if UsedJokerAmount == 1 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	elseif 
	== 2 then
		--JokerHUD:SetFrame('"' .. CardPos1 .. '"', 1) --this doesn't work...
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	elseif UsedJokerAmount == 3 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	elseif UsedJokerAmount == 4 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	elseif UsedJokerAmount == 5 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	elseif UsedJokerAmount == 6 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
	elseif UsedJokerAmount == 7 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
		JokerHUD:SetFrame("1", CardPos7)
		JokerHUD:RenderLayer(0, UIPos.POS7)
	elseif UsedJokerAmount == 8 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
		JokerHUD:SetFrame("1", CardPos7)
		JokerHUD:RenderLayer(0, UIPos.POS7)
		JokerHUD:SetFrame("1", CardPos8)
		JokerHUD:RenderLayer(0, UIPos.POS8)
	elseif UsedJokerAmount == 9 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
		JokerHUD:SetFrame("1", CardPos7)
		JokerHUD:RenderLayer(0, UIPos.POS7)
		JokerHUD:SetFrame("1", CardPos8)
		JokerHUD:RenderLayer(0, UIPos.POS8)
		JokerHUD:SetFrame("1", CardPos9)
		JokerHUD:RenderLayer(0, UIPos.POS9)
	elseif UsedJokerAmount == 10 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
		JokerHUD:SetFrame("1", CardPos7)
		JokerHUD:RenderLayer(0, UIPos.POS7)
		JokerHUD:SetFrame("1", CardPos8)
		JokerHUD:RenderLayer(0, UIPos.POS8)
		JokerHUD:SetFrame("1", CardPos9)
		JokerHUD:RenderLayer(0, UIPos.POS9)
		JokerHUD:SetFrame("1", CardPos10)
		JokerHUD:RenderLayer(0, UIPos.POS10)
	elseif UsedJokerAmount > 10 then
		JokerHUD:SetFrame("1", CardPos1)
		JokerHUD:RenderLayer(0, UIPos.POS1)
		JokerHUD:SetFrame("1", CardPos2)
		JokerHUD:RenderLayer(0, UIPos.POS2)
		JokerHUD:SetFrame("1", CardPos3)
		JokerHUD:RenderLayer(0, UIPos.POS3)
		JokerHUD:SetFrame("1", CardPos4)
		JokerHUD:RenderLayer(0, UIPos.POS4)
		JokerHUD:SetFrame("1", CardPos5)
		JokerHUD:RenderLayer(0, UIPos.POS5)
		JokerHUD:SetFrame("1", CardPos6)
		JokerHUD:RenderLayer(0, UIPos.POS6)
		JokerHUD:SetFrame("1", CardPos7)
		JokerHUD:RenderLayer(0, UIPos.POS7)
		JokerHUD:SetFrame("1", CardPos8)
		JokerHUD:RenderLayer(0, UIPos.POS8)
		JokerHUD:SetFrame("1", CardPos9)
		JokerHUD:RenderLayer(0, UIPos.POS9)
		JokerHUD:SetFrame("1", CardPos10)
		JokerHUD:RenderLayer(0, UIPos.POS10)
		
		JokerHUD:SetFrame("Plus", 1)
		JokerHUD:RenderLayer(0, UIPos.POS11)
		JokerHUD.Color = Color(0.5,0.5,0.5,1)
	end
	
	end
	
end

mod:AddCallback(ModCallbacks.MC_POST_RENDER, mod.Render)

]]

----------------------------------------- SET JOKER STATS

function mod:EvaluateForCards(player, cacheFlag)
if RunData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	local RPData = BalatroJokers.SaveShitNow.GetRunSave(player)

	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		
		if RPData.BJokerAmount ~= nil and RPData.BJokerAmount >= 1 then
			player.Damage = player.Damage + (RPData.BJokerAmount)*0.7 --player.Damage*(0.4*BJokerAmount)
			--player.MaxFireDelay = player.MaxFireDelay - 1
		end
		if RPData.HeartCount ~= nil then
			player.Damage = player.Damage + (0.03*RPData.HeartCount)
		end
		if RPData.CoinCount ~= nil then
			player.Damage = player.Damage + (0.03*RPData.CoinCount)
		end
		if RPData.KeyCount ~= nil then
			player.Damage = player.Damage + (0.05*RPData.KeyCount)
		end
		if RPData.BombCount ~= nil then
			player.Damage = player.Damage + (0.05*RPData.BombCount)
		end
		if RPData.RoomKC_Jolly ~= nil then
			player.Damage = player.Damage + (0.4*math.floor(RPData.RoomKC_Jolly/2))
		end
		if   RPData.HalfJokerAmount ~= nil then
			player.Damage = player.Damage +   RPData.HalfJokerAmount*1.5
		end
		if RPData.StencilActive ~= nil then
		local currentcharge = 0
			if player:NeedsCharge(ActiveSlot.SLOT_PRIMARY) == true and currentcharge <= 12 then --player:GetActiveItem(ActiveSlot.SLOT_PRIMARY) ~= 0 and 
				currentcharge = player:GetActiveCharge(ActiveSlot.SLOT_PRIMARY)
			elseif player:NeedsCharge(ActiveSlot.SLOT_PRIMARY) == true and currentcharge > 12 then
				currentcharge = 1
			else
				currentcharge = 0
			end
			player.Damage = player.Damage + currentcharge*0.4
		end
		if RPData.MisprintMult ~= nil then
			player.Damage = player.Damage+RPData.MisprintMult
		end
		if RPData.RaisedFistBonus ~= nil then
			player.Damage = player.Damage+RPData.RaisedFistBonus
		end
		if RPData.FibonacciActive ~= nil then
			if ((player:GetNumBombs() >= 1 and player:GetNumBombs() <= 3) or player:GetNumBombs() == 5 or player:GetNumBombs() == 8) and 
			((player:GetNumKeys() >= 1 and player:GetNumKeys() <= 3) or player:GetNumKeys() == 5 or player:GetNumKeys() == 8) and 
			((player:GetNumCoins() >= 1 and player:GetNumCoins() <= 3) or player:GetNumCoins() == 5 or player:GetNumCoins() == 8) then
				player.Damage = player.Damage+(RPData.FibonacciActive*2)
			end
		end
		if RPData.GrosActive == true then
			player.Damage = player.Damage+3
		end
		if RPData.BlackboardBonus ~= nil then
			if RPData.BlackboardBonus >= 1 then
				player.Damage = player.Damage*RPData.BlackboardBonus
			else
				player.Damage = player.Damage
			end
		end
		if RPData.VampireAmount ~= nil then
			player.Damage = player.Damage+player.Damage*(RPData.VampireAmount*0.005)
		end
		
		--Multipliers
		if RPData.HoloBonus ~= nil then
			player.Damage = player.Damage+player.Damage*(RPData.HoloBonus*0.08)
		end
		
	elseif cacheFlag == CacheFlag.CACHE_FIREDELAY then
			RPData.tearscap = 0
			RPData.wbonus = 0
			RPData.cbonus = 0
			RPData.bbonus = 0
			
			local tearscap = RPData.tearscap
			local wbonus = RPData.wbonus
			local cbonus = RPData.cbonus
			local bbonus = RPData.bbonus
			
		if player:HasCollectible(CollectibleType.COLLECTIBLE_SOY_MILK) == true then
			tearscap = 0.091
			wbonus=0.25*0.18
			cbonus=0.94/8*0.18
			bbonus=1.15/2*0.18
		elseif player:HasCollectible(CollectibleType.COLLECTIBLE_ALMOND_MILK) == true then
			tearscap = 0.5
			wbonus=0.25*0.25
			cbonus=0.94/8*0.25
			bbonus=1.15/2*0.25
		else
			tearscap = 5
			wbonus=0.25
			cbonus=0.94/8
			bbonus=1.15/2
		end
		
		if RPData.RoomKC_Wily ~= nil then
			--player.MaxFireDelay = player.MaxFireDelay*(1-bruh)
			if player.MaxFireDelay - RPData.RoomKC_Wily*wbonus < tearscap then
				player.MaxFireDelay = tearscap
			else
				player.MaxFireDelay = player.MaxFireDelay - RPData.RoomKC_Wily*wbonus
			end
		end
		if RPData.ChampKC_Scary ~= nil then
			if player.MaxFireDelay - RPData.ChampKC_Scary*cbonus < tearscap then
				player.MaxFireDelay = tearscap
			else
				player.MaxFireDelay = player.MaxFireDelay - RPData.ChampKC_Scary*cbonus
			end
		end
		if RPData.BlueAmount ~= nil then
			if player.MaxFireDelay - RPData.BlueAmount*bbonus < tearscap then
				player.MaxFireDelay = tearscap
			else
				player.MaxFireDelay = player.MaxFireDelay - RPData.BlueAmount*bbonus
			end
		end
		if RPData.SquareEnabled ~= nil then
			player.MaxFireDelay = player.MaxFireDelay-RPData.SquareEnabled
		end
	
	--print(player.MaxFireDelay)
	
	elseif cacheFlag == CacheFlag.CACHE_TEARCOLOR then
		
		--JIMBO ITEM
		
		if player:HasCollectible(BalatroJokers.Enums.Jokers.jimbos_collection) and RPData.JimboCount == player:GetCollectibleNum(BalatroJokers.Enums.Jokers.jimbos_collection)-1 then
		
		SFXManager():Play(BalatroJokers.Enums.SFX.JimboSFX, 0.8, 0, false, 1)
		--JimboCount = player:GetCollectibleNum(jimbos_collection)
		
		local ChosenPickup = (BalatroJokers.Enums.PickupTypes[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.PickupTypes) ])
		local ChosenPickupSubType = 0
		
	--[[	if ChosenPickup == 10 then
			ChosenPickupSubType = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(13)
		elseif ChosenPickup == 20 then
			ChosenPickupSubType = math.random(7)
		elseif ChosenPickup == 30 then
			ChosenPickupSubType = math.random(4)
		elseif ChosenPickup == 40 then
			ChosenPickupSubType = math.random(7)
		elseif ChosenPickup == 69 then
			ChosenPickupSubType = math.random(2)
		else
			ChosenPickupSubType = 1
		end
		]]
		--서브타입 0 쓰면 알아서 랜덤 되잖아 병신아 -GDKBB
		
		Isaac.Spawn(EntityType.ENTITY_PICKUP, ChosenPickup, ChosenPickupSubType, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		Isaac.Spawn(EntityType.ENTITY_PICKUP, (BalatroJokers.Enums.Boosters[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.Boosters)]), 1, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		
		for i = 1, 2 do
		local AllVouchers = BalatroJokers.Enums.Vouchers
			Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TRINKET, (AllVouchers[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllVouchers)]), player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		end
		end
		
		RPData.JimboCount = math.max(RPData.JimboCount, player:GetCollectibleNum(jimbos_collection))
		
	end
	
end
end
end
mod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, mod.EvaluateForCards)

-------------------------- DESPAWN OTHERS

function mod:DespawnOthers(pickup, collider)
if RoomData then
local sprite = pickup:GetSprite()

local player = collider:ToPlayer()
if not player then return end

if pickup.Variant == 300 and collider:ToPlayer() ~= nil and pickup.FrameCount >= 20 and player:IsHoldingItem() == false and pickup:ToPickup().Timeout > 100 then
	
	for i, entity in pairs(Isaac.GetRoomEntities()) do
		if entity.Type == EntityType.ENTITY_PICKUP and entity:ToPickup().Timeout > 100 then
			
			local ChanceToConvertHigh = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4)
			local ChanceToConvertLow = player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(11)
			
			if (entity.Position - player.Position):Length() >= 22 then --sometimes this check can fail if the pickups are too close
				if player:HasTrinket(BalatroJokers.Enums.Trinkets.wasteful_voucher) and ChanceToConvertHigh <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.wasteful_voucher) then
					entity:ToPickup().Timeout = -1
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 20, 1, true)
				elseif player:HasTrinket(BalatroJokers.Enums.Trinkets.tarot_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.tarot_voucher) then
					entity:ToPickup().Timeout = -1
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, 1+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(22), true)
				elseif player:HasTrinket(BalatroJokers.Enums.Trinkets.planet_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.planet_voucher) then
					entity:ToPickup().Timeout = -1
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), true)
				elseif player:HasTrinket(BalatroJokers.Enums.Trinkets.directors_voucher) and ChanceToConvertLow <= 1*player:GetTrinketMultiplier(BalatroJokers.Enums.Trinkets.directors_voucher) then
					entity:ToPickup().Timeout = -1
					entity:ToPickup():Morph(EntityType.ENTITY_PICKUP, 300, 49, true)
				else
					entity:Remove()
					--print(collider.Type == EntityType.ENTITY_PLAYER)
				end
			end
			
			local distance = (entity.Position - player.Position):Length()
			if  distance >24 then
			Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, entity.Position, Vector(0, 0), player):ToEffect().SpriteScale = Vector(0.8, 0.8)
			end
			RoomData.ValidPackCards = 0
		end
	end

end

end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.DespawnOthers)

----------------------------------------- Booster PackS

function mod:OpenBoosterPack(pickup, collider)
if RoomData then
local sprite = pickup:GetSprite()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm) or (pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.arcana_packm) or (pickup.Variant >= BalatroJokers.Enums.Boosters.planet_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.planet_packm) or (pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.buffoon_packm) or (pickup.Variant >= BalatroJokers.Enums.ExtraPacks.deck_pack and pickup.Variant <= BalatroJokers.Enums.ExtraPacks.fun_pack) then
	
	--local bruhspawn = Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_KEY, 1, player.Position, Vector(0,0), player)
	--bruhspawn:ToPickup().Timeout = (100)

	--if pickup.Timeout == -1 then

	if pickup.FrameCount >= 20 and collider:ToPlayer() ~= nil and RoomData.ValidPackCards == 0 then
		if pickup:IsShopItem() == true and player:GetNumCoins() >= pickup.Price then --Shop Booster Pack
			player:AddCoins(-1*(pickup.Price))
			pickup:Remove()
			--Isaac.Spawn(EntityType.ENTITY_PICKUP, pickup.Variant, 1, pickup.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			--SFXManager():Play (249, 1, 0, false, 1)
			RoomData.BoughtPickupVar = pickup.Variant
		elseif pickup:IsShopItem() == false then
			sprite:Play("Collect")
		end
	end
	
end

end
end
end
mod:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, mod.OpenBoosterPack)

local CommonA = BalatroJokers.Enums.CommonA
local CommonB = BalatroJokers.Enums.CommonB
local CommonC = BalatroJokers.Enums.CommonC

local JumboA = BalatroJokers.Enums.JumboA
local JumboB = BalatroJokers.Enums.JumboB
local JumboC = BalatroJokers.Enums.JumboC

local MegaA = BalatroJokers.Enums.MegaA
local MegaB = BalatroJokers.Enums.MegaB
local MegaC = BalatroJokers.Enums.MegaC
local MegaD = BalatroJokers.Enums.MegaD
local MegaE = BalatroJokers.Enums.MegaE

function mod:RemovePack(pickup)
if RoomData then
local sprite = pickup:GetSprite()


	local player = Game():GetPlayer(0)
	local BoughtPickupVar = RoomData.BoughtPickupVar
	local PCards = BalatroJokers.Enums.PCards

if BoughtPickupVar ~= 0 or (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.arcana_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.arcana_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.planet_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.planet_packm)
or (pickup.Variant >= BalatroJokers.Enums.Boosters.buffoon_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.buffoon_packm) 
or (pickup.Variant >= BalatroJokers.Enums.ExtraPacks.deck_pack and pickup.Variant <= BalatroJokers.Enums.ExtraPacks.fun_pack) then;

	if BoughtPickupVar ~= 0 or (sprite:IsPlaying("Collect") == true and sprite:GetFrame() == 1) then
		
		--SFXManager():Play (21, 1, 0, false, 1.2)
		--SFXManager():Play (35, 1, 0, false, 1)
		--[[
		
		--]]
		
		if pickup.Variant == BalatroJokers.Enums.Boosters.standard_pack or BoughtPickupVar == BalatroJokers.Enums.Boosters.standard_pack then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (CommonA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (CommonB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (CommonC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#CommonC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			
			BoughtPickupVar = 0
		elseif pickup.Variant == BalatroJokers.Enums.Boosters.standard_packj or BoughtPickupVar == BalatroJokers.Enums.Boosters.standard_packj then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (JumboA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (JumboB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (JumboC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			--
			if player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4) <= 2 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(32,41), pickup.Position,(JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout--runes 66%
			else
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, 55, pickup.Position, (JumboD[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#JumboD) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --rune shard 33%
			end
			
			SFXManager():Play (17, 1, 0, false, 2.5)--paperin
			SFXManager():Play (18, 1, 0, false, 2)--paperout
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
			
			BoughtPickupVar = 0
		elseif pickup.Variant == BalatroJokers.Enums.Boosters.standard_packm or BoughtPickupVar == BalatroJokers.Enums.Boosters.standard_packm then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position,(MegaA[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaA) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (MegaB[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaB) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (PCards[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#PCards) ]), pickup.Position, (MegaC[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#MegaC) ])*(8+player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(4))*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			--
			if math.random(3) <= 2 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(32,41), pickup.Position, (MegaD[math.random(#MegaD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --runes 66%
			else
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, 55, pickup.Position, (MegaD[math.random(#MegaD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --rune shard 33%
			end
			--
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(81,97), pickup.Position, (MegaE[math.random(#MegaE)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 2)--paperin
			SFXManager():Play (18, 1, 0, false, 1.5)--paperout
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
			
			BoughtPickupVar = 0
		elseif pickup.Variant == arcana_pack or BoughtPickupVar == arcana_pack then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (CommonA[math.random(#CommonA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (CommonB[math.random(#CommonB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (CommonC[math.random(#CommonC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			
			BoughtPickupVar = 0
		elseif pickup.Variant == arcana_packj or BoughtPickupVar == arcana_packj then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (JumboA[math.random(#JumboA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (JumboB[math.random(#JumboB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (JumboC[math.random(#JumboC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			--
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(56,77), pickup.Position, (JumboD[math.random(#JumboD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --reverse
			
			SFXManager():Play (17, 1, 0, false, 2.5)--paperin
			SFXManager():Play (18, 1, 0, false, 2)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			SFXManager():Play (276, 1, 0, false, 0.1*math.random(10,12))--angellaser
			
			BoughtPickupVar = 0
		elseif pickup.Variant == arcana_packm or BoughtPickupVar == arcana_packm then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (MegaA[math.random(#MegaA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (MegaB[math.random(#MegaB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(1,22), pickup.Position, (MegaC[math.random(#MegaC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			--
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(56,77), pickup.Position, (MegaD[math.random(#MegaD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --reverse
			--
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(42,54), pickup.Position, (MegaE[math.random(#MegaE)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout --special
			
			--Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, 80, player.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil) --wild card
			
			SFXManager():Play (17, 1, 0, false, 2)--paperin
			SFXManager():Play (18, 1, 0, false, 1.5)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			SFXManager():Play (276, 1, 0, false, 0.1*math.random(5,8))--angellaser
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
		
			BoughtPickupVar = 0
		elseif pickup.Variant == planet_pack or BoughtPickupVar == planet_pack then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (CommonA[math.random(#CommonA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (CommonB[math.random(#CommonB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (CommonC[math.random(#CommonC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			
			BoughtPickupVar = 0
		elseif pickup.Variant == planet_packj or BoughtPickupVar == planet_packj then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (JumboA[math.random(#JumboA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (JumboB[math.random(#JumboB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (JumboC[math.random(#JumboC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (JumboD[math.random(#JumboD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 2.5)--paperin
			SFXManager():Play (18, 1, 0, false, 2)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			SFXManager():Play(583, 0.8, 0, false, 0.1*math.random(8,12))
			SFXManager():Play(545, 0.8, 0, false, 2.2)
			
			BoughtPickupVar = 0
		elseif pickup.Variant == planet_packm or BoughtPickupVar == planet_packm then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (MegaA[math.random(#MegaA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (MegaB[math.random(#MegaB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (MegaC[math.random(#MegaC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (MegaD[math.random(#MegaD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, BalatroJokers.Enums.Planets.Pluto + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(BalatroJokers.Enums.Planets.Neptune - BalatroJokers.Enums.Planets.Pluto), pickup.Position, (MegaE[math.random(#MegaE)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 2)--paperin
			SFXManager():Play (18, 1, 0, false, 1.5)--paperout
			SFXManager():Play (284, 1, 0, false, 1.5)--noteshort
			SFXManager():Play(583, 0.8, 0, false, 0.1*math.random(8,12))
			SFXManager():Play(545, 0.8, 0, false, 2.2)
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
			
			BoughtPickupVar = 0
		
		elseif pickup.Variant == buffoon_pack or BoughtPickupVar == buffoon_pack then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (CommonA[math.random(#CommonA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (CommonB[math.random(#CommonB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (CommonC[math.random(#CommonC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			
			BoughtPickupVar = 0
			
		elseif pickup.Variant == buffoon_packj or BoughtPickupVar == buffoon_packj then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (JumboA[math.random(#JumboA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (JumboB[math.random(#JumboB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (JumboC[math.random(#JumboC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (JumboD[math.random(#JumboD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 2.5)--paperin
			SFXManager():Play (18, 1, 0, false, 2)--paperout
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
			
			BoughtPickupVar = 0
		
		elseif pickup.Variant == buffoon_packm or BoughtPickupVar == buffoon_packm then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (MegaA[math.random(#MegaA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (MegaB[math.random(#MegaB)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (MegaC[math.random(#MegaC)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (MegaD[math.random(#MegaD)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, math.random(BJoker,Hologram), pickup.Position, (MegaE[math.random(#MegaE)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 2)--paperin
			SFXManager():Play (18, 1, 0, false, 1.5)--paperout
			SFXManager():Play (284, 1, 0, false, 0.5)--noteshort
			SFXManager():Play (268, 0.5, 0, false, 1.5)--thumbup
			
			BoughtPickupVar = 0
		
		elseif pickup.Variant == deck_pack then
			
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (DeckCards[math.random(#DeckCards)]), pickup.Position, (CommonA[math.random(#CommonA)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (DeckCards[math.random(#DeckCards)]), pickup.Position, (MegaE[math.random(#MegaE)])*math.random(8,12)*0.1, nil):ToPickup().Timeout = SpawnedPickupTimeout
			
			SFXManager():Play (17, 1, 0, false, 3)--paperin
			SFXManager():Play (18, 1, 0, false, 2.5)--paperout
			
		end
		
		if pickup:IsShopItem() == false then
			pickup:ToPickup().Timeout = 40
		end
		
		--SFXManager():Play (609, 0.3, 0, false, 0.1*math.random(8,12))--mirrorreverse planet card
		--SFXManager():Play (609, 0.3, 0, false, 0.1*math.random(8,12))--mirrorreverse2 planet card
	
	ValidPackCards = 1
	
	if player:HasTrinket(seed_voucher) then --SEED VOUCHER FUNCTION
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 20, (BalatroJokers.Enums.SeedCoins[1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#BalatroJokers.Enums.SeedCoins) ]), pickup.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	end
	
	if player:HasTrinket(overstock_voucher) then --OVERSTOCK VOUCHER FUNCTION
		
		local ChosenPickupOverstock = (PickupTypes[math.random(#PickupTypes-1)])
		
		if ChosenPickupOverstock == 10 then
			if math.random(2) == 1 then --only red or doublered
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 5
			end
		elseif ChosenPickupOverstock == 20 then
			if math.random(2) == 1 then --only coin or doublecoin
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 4
			end
		elseif ChosenPickupOverstock == 30 then
			if math.random(2) == 1 then --only key or doublekey
			ChosenPickupSubTypeOS = 1
			else
			ChosenPickupSubTypeOS = 3
			end
		elseif ChosenPickupOverstock == 40 then --bomb or doublebomb
			ChosenPickupSubTypeOS = math.random(2)
		else
			ChosenPickupSubTypeOS = 1
		end
		
		Isaac.Spawn(EntityType.ENTITY_PICKUP, ChosenPickupOverstock, ChosenPickupSubTypeOS, pickup.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	end
	
	if sprite:IsFinished("Collect") == true then
		pickup:Remove()
	end
	
	end
end

--[[

	if pickup.Variant == 300 and pickup.Timeout ~= -1 then --SET COLOR
	local CardDistance = (pickup.Position - player.Position):Length()
		if CardDistance >40 then
		pickup:SetColor(Color(1,1,1,0.5),0,0,false,false)
		else
		pickup:SetColor(Color(1,1,1,1),0,0,false,false)
		end
	end
	
]]	

end
end


mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.RemovePack)

----------------------------------------- BOSS AND ELITE CHECK (HONE VOUCHER/JIMBO)

function mod:CheckEnemy(enemy)
if RoomData then
for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if player:HasTrinket(hone_voucher) and enemy:IsBoss() == true then
	
	if math.random(4) <= 1*player:GetTrinketMultiplier(hone_voucher) then
	Isaac.Spawn(EntityType.ENTITY_PICKUP, (JimboPacks[math.random(#JimboPacks)]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
	end
end

if player:HasCollectible(jimbos_collection) and enemy:IsBoss() == true then
	
	if math.random(3) <= 2 and RoomData.SpawnFromBoss < 1 then
		Isaac.Spawn(EntityType.ENTITY_PICKUP, 300, (AllJokers[ 1 + player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(#AllJokers) ]), enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil) --:ToPickup().Timeout = SpawnedPickupTimeout
		Isaac.Spawn(EntityType.ENTITY_EFFECT, Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
		SFXManager():Play (268, 0.6, 0, false, 1)
		RoomData.SpawnFromBoss = RoomData.SpawnFromBoss + 1
	elseif RoomData.SpawnFromBoss < 1 then
		Isaac.Spawn(EntityType.ENTITY_PICKUP, (JimboPacks[math.random(#JimboPacks)]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
		Isaac.Spawn(EntityType.ENTITY_EFFECT, Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
		SFXManager():Play (268, 0.6, 0, false, 1)
		RoomData.SpawnFromBoss = RoomData.SpawnFromBoss + 1
	end
	
end

if player:HasCollectible(jimbos_collection) and enemy:IsChampion() == true then
	
	if math.random(15) <= 1*player:GetCollectibleNum(jimbos_collection) then
		if math.random(3) > 1 then
			Isaac.Spawn(EntityType.ENTITY_PICKUP, (JimboPacks[math.random(#JimboPacks)]), 1, enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			Isaac.Spawn(EntityType.ENTITY_EFFECT, Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
			SFXManager():Play (268, 0.6, 0, false, 1)
		else
			Isaac.Spawn(EntityType.ENTITY_PICKUP, 350, (SPVouchers[math.random(#SPVouchers)]), enemy.Position, Vector.FromAngle(player:GetCollectibleRNG(BalatroJokers.Enums.Items.jimbos_collection):RandomInt(361)) * 3, nil)
			Isaac.Spawn(EntityType.ENTITY_EFFECT, Jimbo_Effect , 0, enemy.Position, Vector(0, 0), player)
			SFXManager():Play (268, 0.6, 0, false, 1)
		end
	end
end

end
end
end
mod:AddCallback(ModCallbacks.MC_POST_NPC_DEATH, mod.CheckEnemy)

----------------------------------------- REROLL VOUCHER FUNCTION

function mod:CheckDonationMachine()
local room = Game():GetRoom()
local roomt = Game():GetRoom():GetType()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

--donation machine is type 6 variant 8
--reroll machine is type 6 variant 10

	if player:HasTrinket(reroll_voucher) and roomt == RoomType.ROOM_SHOP then
		if room:IsFirstVisit() == true and Isaac.CountEntities(nil, 6, 10, -1) == 0 then
			Isaac.Spawn(EntityType.ENTITY_SLOT, 10, 1, Vector(135,160), Vector(0,0), nil)
		end
	end
	
end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.CheckDonationMachine)

----------------------------------------- HIEROGLYPH VOUCHER FUNCTION

function mod:KillBoss()
local roomt = Game():GetRoom():GetType()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

	if player:HasTrinket(hieroglyph_voucher) and roomt == RoomType.ROOM_BOSS and HieroActivated == 0 then
		for i, entity in pairs(Isaac.GetRoomEntities()) do
			if entity:IsBoss() == true and entity.Type ~= EntityType.ENTITY_DOGMA and entity.Type ~= EntityType.ENTITY_BEAST and entity.Type ~= EntityType.ENTITY_MOTHER and entity.Type ~= EntityType.ENTITY_DELIRIUM and entity.Type ~= EntityType.ENTITY_HUSH and entity.Type ~= EntityType.ENTITY_ULTRA_GREED and Game():GetLevel():GetStage() ~= LevelStage.STAGE6 then --EntityType.ENTITY_MEGA_SATAN == false and EntityType.ENTITY_MEGA_SATAN_2 == false
				HieroActivated = 1
				player:AnimateTrinket(hieroglyph_voucher, "Pickup", "PlayerPickupSparkle")
				Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, player.Position, Vector(0, 0), player)
				entity:Kill()
				player:TryRemoveTrinket(hieroglyph_voucher)
			end
		end
	end
end
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, mod.KillBoss)

function mod:RemoveBossItem(entity)
local roomt = Game():GetRoom():GetType()

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)
	
	if roomt == RoomType.ROOM_BOSS and HieroActivated == 1 then
		
		for i, pickup in pairs(Isaac.FindInRadius(player.Position, 60, EntityPartition.PICKUP)) do
			if Isaac.GetItemConfig():GetCollectible(pickup.SubType):HasTags(ItemConfig.TAG_QUEST) ~= true and pickup.Type == EntityType.ENTITY_PICKUP and pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE then
			pickup:Remove()
			--Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01 , 0, pickup.Position, Vector(0, 0), player)
			player:AnimateSad()
			HieroActivated = 0
			Isaac.Spawn(EntityType.ENTITY_EFFECT, Nope_Effect , 0, pickup.Position, Vector(0, 0), player)
			end
		end
		
	end

end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.RemoveBossItem)

----------------------------------------- CARD SPRITE REPLACE (thanks potato pack for the base template)

function mod:ReplacePlanetBacks(entity)
local sprite = entity:GetSprite()

	if entity.SubType >= Pluto and entity.SubType <= Neptune then
		if sprite:GetFilename() ~= "gfx/cardback_planet.anm2" then
			sprite:Load ("gfx/cardback_planet.anm2", true)
		end
	elseif entity.SubType >= BJoker and entity.SubType <= Hologram and entity.SubType ~= HalfJoker and entity.SubType ~= SquareJoker then
		if sprite:GetFilename() ~= "gfx/cardback.anm2" then
			sprite:Load ("gfx/cardback.anm2", true)
		end
	
	elseif entity.SubType == HalfJoker then
		if sprite:GetFilename() ~= "gfx/cardback-torn.anm2" then
			sprite:Load ("gfx/cardback-torn.anm2", true)
		end
	elseif entity.SubType == SquareJoker then
		if sprite:GetFilename() ~= "gfx/cardback-square.anm2" then
			sprite:Load ("gfx/cardback-square.anm2", true)
		end
	elseif entity.SubType >= RedDeck and entity.SubType <= BlackDeck then
		if entity.SubType == RedDeck and sprite:GetFilename() ~= "gfx/cardback-reddeck.anm2" then
			sprite:Load ("gfx/cardback-reddeck.anm2", true)
		elseif entity.SubType == BlueDeck and sprite:GetFilename() ~= "gfx/cardback-bluedeck.anm2" then
			sprite:Load ("gfx/cardback-bluedeck.anm2", true)
		elseif entity.SubType == YellowDeck and sprite:GetFilename() ~= "gfx/cardback-yellowdeck.anm2" then
			sprite:Load ("gfx/cardback-yellowdeck.anm2", true)
		elseif entity.SubType == GreenDeck and sprite:GetFilename() ~= "gfx/cardback-greendeck.anm2" then
			sprite:Load ("gfx/cardback-greendeck.anm2", true)
		elseif entity.SubType == BlackDeck and sprite:GetFilename() ~= "gfx/cardback-blackdeck.anm2" then
			sprite:Load ("gfx/cardback-blackdeck.anm2", true)
		end
	end
	
	if sprite:IsPlaying("Appear") == false then
			if Game():GetLevel():GetCurrentRoom():GetFrameCount() >= 3 then --most probably spawned as a reward if frame count is bigger than this
				sprite:Play("Appear", true)
			elseif Game():GetRoom():IsFirstVisit() == true then
				sprite:Play("Appear", true)
				sprite:SetLastFrame()
			else
				sprite:Play("Idle", true)
			end
		end
	
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, mod.ReplacePlanetBacks, 300)

----------------------------------------- PLAY DROP SND

function mod:PlayDropSound(pickup)

for i = 0, Game():GetNumPlayers() - 1 do
	local player = Game():GetPlayer(i)

if (pickup.Variant >= BalatroJokers.Enums.Boosters.standard_pack and pickup.Variant <= BalatroJokers.Enums.Boosters.standard_packm) or (pickup.Variant >= arcana_pack and pickup.Variant <= arcana_packm) or (pickup.Variant >= planet_pack and pickup.Variant <= planet_packm) or (pickup.Variant >= deck_pack and pickup.Variant <= fun_pack) then
local sprite = pickup:GetSprite()

	if sprite:IsPlaying("Appear") == true and sprite:IsEventTriggered("DropSound") == true then
		SFXManager():Play (249, 1, 0, false, 1)--drop snd
	end
end

end
end

mod:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE, mod.PlayDropSound)

----------------------------------------- SPRITE REPLACE

--player:AnimateCard ()

--Booster Packs throw out 3,4 or 5 cards (9999 fading ticks to each), check for fading, 
--if fading is not nil destroy the fading cards after one card is collected (to collect check for frametime of card for no accidental pickup on pack opening) and play poof vfx

--if replaces sack or card, play drop snd
--SFXManager():Play (35, 1, 0, false, 1)

--planet cards = planetarium item wisp or effect --AddItemWisp ()

----------------------------------------- SAVE

--[[

function mod:SaveGame()
	SaveState.JimboState = {}
	SaveState.RoomClearState = {}
	SaveState.RoomChestCountState = {}
	SaveState.ValidPackCardsState = {}
	SaveState.HieroActivatedState = {}
	SaveState.RedDeckActiveState = {}
	SaveState.GreenDeckActiveState = {}
	SaveState.RocketBonusState = {}
	SaveState.UsedJokerAmountState = {}
	SaveState.CardPos1State = {}
	SaveState.CardPos2State = {}
	SaveState.CardPos3State = {}
	SaveState.CardPos4State = {}
	SaveState.CardPos5State = {}
	SaveState.CardPos6State = {}
	SaveState.CardPos7State = {}
	SaveState.CardPos8State = {}
	SaveState.CardPos9State = {}
	SaveState.CardPos10State = {}
	
	SaveState.JSettings = {}
	
	for i, v in pairs(JokerVars) do
		SaveState.JSettings[tostring(i)] = JokerVars[i]
	end
	
	SaveState.JimboState = tostring(JimboCount)
	SaveState.RoomClearState = tostring(RoomClearTimer)
	SaveState.RoomChestCountState = tostring(RoomChestCount)
	SaveState.ValidPackCardsState = tostring(ValidPackCards)
	SaveState.HieroActivatedState = tostring(HieroActivated)
	SaveState.RedDeckActiveState = tostring(RedDeckActive)
	SaveState.GreenDeckActiveState = tostring(GreenDeckActive)
	SaveState.RocketBonusState = tostring(RocketBonus)
	SaveState.UsedJokerAmountState = tostring(UsedJokerAmount)
	SaveState.CardPos1State = tostring(CardPos1)
	SaveState.CardPos2State = tostring(CardPos2)
	SaveState.CardPos3State = tostring(CardPos3)
	SaveState.CardPos4State = tostring(CardPos4)
	SaveState.CardPos5State = tostring(CardPos5)
	SaveState.CardPos6State = tostring(CardPos6)
	SaveState.CardPos7State = tostring(CardPos7)
	SaveState.CardPos8State = tostring(CardPos8)
	SaveState.CardPos9State = tostring(CardPos9)
	SaveState.CardPos10State = tostring(CardPos10)
	
    mod:SaveData(json.encode(SaveState))
end
mod:AddCallback(ModCallbacks.MC_PRE_GAME_EXIT, mod.SaveGame)

function mod:OnGameStart(isSave)

    if defaultsChanged then
        mod:SaveGame()
    end
	
    if mod:HasData() then
        SaveState = json.decode(mod:LoadData())
		
		if isSave == false then
			JimboCount = 0
			RoomClearTimer = 0
			RoomChestCount = 0
			ValidPackCards = 0
			HieroActivated = 0
			RedDeckActive = 0
			GreenDeckActive = 0
			RocketBonus = 1
			UsedJokerAmount = 0
			CardPos1 = nil
			CardPos2 = nil
			CardPos3 = nil
			CardPos4 = nil
			CardPos5 = nil
			CardPos6 = nil
			CardPos7 = nil
			CardPos8 = nil
			CardPos9 = nil
			CardPos10 = nil
		else
			JimboCount = tonumber(SaveState.JimboState)
			RoomClearTimer = tonumber(SaveState.RoomClearState)
			RoomChestCount = tonumber(SaveState.RoomChestCountState)
			ValidPackCards = tonumber(SaveState.ValidPackCardsState)
			HieroActivated = tonumber(SaveState.HieroActivatedState)
			RedDeckActive = tonumber(SaveState.RedDeckActiveState)
			GreenDeckActive = tonumber(SaveState.GreenDeckActiveState)
			RocketBonus = tonumber(SaveState.RocketBonusState)
			UsedJokerAmount = tonumber(SaveState.UsedJokerAmountState)
			CardPos1 = tonumber(SaveState.CardPos1State)
			CardPos2 = tonumber(SaveState.CardPos2State)
			CardPos3 = tonumber(SaveState.CardPos3State)
			CardPos4 = tonumber(SaveState.CardPos4State)
			CardPos5 = tonumber(SaveState.CardPos5State)
			CardPos6 = tonumber(SaveState.CardPos6State)
			CardPos7 = tonumber(SaveState.CardPos7State)
			CardPos8 = tonumber(SaveState.CardPos8State)
			CardPos9 = tonumber(SaveState.CardPos9State)
			CardPos10 = tonumber(SaveState.CardPos10State)
			
			for i, v in pairs(SaveState.JSettings) do
				JokerVars[tostring(i)] = SaveState.JSettings[i]
			end
			
		end
    end
	
	for i = 0, Game():GetNumPlayers() - 1 do
		local player = Game():GetPlayer(i)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:EvaluateItems()
	end
	
end
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, mod.OnGameStart)


]]